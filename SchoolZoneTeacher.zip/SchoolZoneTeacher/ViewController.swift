//
//  ViewController.swift
//  SchoolZoneTeacher
//
//  Created by Apple on 12/12/18.
//  Copyright © 2018 ClearWin Technologies. All rights reserved.
//

import UIKit
import Alamofire
import MaterialComponents
import iOSDropDown
import SCLAlertView

class ViewController: UIViewController, UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout, UIPopoverPresentationControllerDelegate {
    
    var dataCache = NSCache<NSString, AnyObject>()
    
    var sliderView:UIScrollView!
    var slideImages = [UIImage]()
    var slideObj = [Slide]()
    var clickActions = [String]()
    
    var imageView = UIImageView()
    var imageViewBack = UIImageView()
    var collectionViewHome: UICollectionView!
    //@IBOutlet weak var navButtonNews: UIButton!
    
    let defaultLocalizer = AMPLocalizeUtils.defaultLocalizer
    let activityIndicator = MDCActivityIndicator()
    var result:Result?
    var news:[News]?
    var slides:[Slide]?
    var response:Response?
    var badge:Badges?
    
    let cellIdentifier = "homeItemCell"
    var moduleNameArray = Array<String>()
    @objc public var selectedCell  : IndexPath = []
    var selectedIndex:Int = 0
    
    let appearance = SCLAlertView.SCLAppearance(
        kTitleFont: UIFont(name: "HelveticaNeue", size: 20)!,
        kTextFont: UIFont(name: "HelveticaNeue", size: 14)!,
        kButtonFont: UIFont(name: "HelveticaNeue-Bold", size: 14)!,
        showCloseButton: false
    )
    
    var ProfileImage: String!
    var School_id: String!
    var School_Name: String!
    var School_Logo: String!
    var TeacherID: String!
    
    var statusBarShouldBeHidden = false
    
    open override var childForStatusBarHidden: UIViewController? {
        return nil
    }
    
    open override var prefersStatusBarHidden: Bool{
        return statusBarShouldBeHidden
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        self.getBadge()
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        self.setNeedsStatusBarAppearanceUpdate()
        
        if(getLanguage().count > 0)
        {
            defaultLocalizer.setSelectedLanguage(lang: getLanguage())
        }
        else
        {
            defaultLocalizer.setSelectedLanguage(lang: "en")
        }
        
        self.ProfileImage = getProfileImage()
        self.School_id = getSchoolId()
        self.School_Name = getSchoolName()
        self.School_Logo = getSchoolLogo()
        self.TeacherID = getTeacherId()
        
        Reachability.isInternetAvailable(webSiteToPing: nil) { (isInternetAvailable) in
            guard isInternetAvailable else {
                //Get back to the main queue
                DispatchQueue.main.async {
                    // Inform user for example
                    let alertView = SCLAlertView(appearance: self.appearance)
                    alertView.addButton(self.defaultLocalizer.stringForKey(key: "actionSheetTitleOK")) {
                        alertView.dismiss(animated: true, completion: nil)
                    }
                    
                    alertView.showError("OurSchoolZone", subTitle: self.defaultLocalizer.stringForKey(key: "labelInternetOffline"), closeButtonTitle: self.defaultLocalizer.stringForKey(key: "actionSheetTitleOK"))
                }
                return
            }
            
            // Do some action if there is Internet
        }
        
        self.setNavigationBar()
        
        let width = UIScreen.main.bounds.width
        self.sliderView = UIScrollView(frame: CGRect(x: 10, y: self.calculateTopDistance() + 10, width: (width - 20), height: 130))
        self.sliderView.tag = 11
        self.sliderView.isPagingEnabled = true
        self.sliderView.isDirectionalLockEnabled = true
        self.sliderView.alwaysBounceVertical = false
        self.sliderView.alwaysBounceHorizontal = true
        self.sliderView.backgroundColor = UIColor.lightGray
        self.sliderView.layer.cornerRadius = 3
        
        self.view.addSubview(sliderView)
        
        self.activityIndicator.sizeToFit()
        self.activityIndicator.center = self.sliderView.center
        self.view.addSubview(self.activityIndicator)
        self.view.bringSubviewToFront(self.activityIndicator)
        
        //self.sliderView.delegate = self
        
        self.getSlides()
        NotificationCenter.default.addObserver(
            self,
            selector: #selector(self.getSlides),
            name: NSNotification.Name(rawValue: "UpdateSlider"),
            object: nil)
        
        Timer.scheduledTimer(timeInterval: 5,
                             target: self,
                             selector: #selector(self.updateTimer),
                             userInfo: nil,
                             repeats: true)
        
        self.setupHomeTabs()
    }
    
    @objc func updateTimer()
    {
        let width = UIScreen.main.bounds.width - 20
        
        // access the scroll view with the tag
        let scrMain:UIScrollView = self.view.viewWithTag(11) as! UIScrollView
        var contentOffset:CGFloat = scrMain.contentOffset.x;
        // calculate next page to display
        var nextPage:CGFloat = (CGFloat)(contentOffset/width) + 1 ;
        // if page is not 10, display it
        let maxPage:CGFloat = (CGFloat)(scrMain.subviews.count / 2);  // There is an imageView AND a Button for earch frame.
        if(nextPage != maxPage)
        {
            scrMain.scrollRectToVisible((CGRect.init(x: nextPage*width, y: 0, width: width, height: scrMain.frame.size.height)), animated: true)
        }
        else
        {
            scrMain.scrollRectToVisible((CGRect.init(x: 0, y: 0, width: width, height: scrMain.frame.size.height)), animated: false)
            // we just JUMPED to the first image wich is identical to the last....
            // Now we immediatly slide the second image into view, so that we never see the ScrollView scroll backwards...
            contentOffset = scrMain.contentOffset.x;
            nextPage = (CGFloat)(contentOffset/width) + 1;
            
            if (nextPage != maxPage)  // we check this just in case if there is ONLY ONE add....
            {
                scrMain.scrollRectToVisible((CGRect.init(x: nextPage*width, y: 0, width: width, height: scrMain.frame.size.height)), animated: true)
            }
        }
    }
    
    @objc func getSlides()
    {
        self.slideImages.removeAll()
        self.slideObj.removeAll()
        self.clickActions.removeAll()
        
        activityIndicator.startAnimating()
            
        if var urlComponents = URLComponents(string: kHostName + "getSlides") {
            urlComponents.query = ""
            // 3
            guard let url = urlComponents.url else { return }
            
            getData(from: url) { data, response, error in
                if error != nil {
                    print(error!.localizedDescription)
                }
                guard let data = data else { return }
                //Implement JSON decoding and parsing
                do {
                    //Decode retrived data with JSONDecoder and assing type of Article object
                    let slideData = try JSONDecoder().decode(Result.self, from: data)
                    
                    self.response = slideData.Response
                    if(self.response?.ResponseVal != 0)
                    {
                        self.slides = slideData.Slides
                        
                        for slideObject in self.slides! {
                            self.slideObj.append(slideObject as Slide)
                            self.clickActions.append(slideObject.click_action)
                        }
                        
                        for slideObject in self.slides! {
                            let image_url = slideObject.img_url.replacingOccurrences(of: "https:", with: "http:", options: .literal, range: nil)
                            
                            Alamofire.request(image_url, method: .get).response { (responseData) in
                                if let data = responseData.data {
                                    DispatchQueue.main.async {
                                        self.slideImages.append(UIImage(data: data)!)
                                        self.dataCache.setObject(UIImage(data: data) as AnyObject, forKey: slideObject.click_action as NSString)
                                        
                                        if(self.slideImages.count == self.slideObj.count){
                                            self.activityIndicator.stopAnimating()
                                            self.rebuildSlider()
                                        }
                                    }
                                }
                            }
                        }
                    }
                    
                } catch let jsonError {
                    print(jsonError)
                }
            }
        }
    }

    func rebuildSlider()
    {
        let width:CGFloat = UIScreen.main.bounds.width
        
        let textViewTop:CGFloat = 90
        let textViewHeight:CGFloat = 40
        
        for view in sliderView.subviews {
            view.removeFromSuperview()
        }
        // make the last image same as first, then schroll back to zero WITHOUT animating...
        // this gives the illusion that you are in a circular, coninuous scroll view....
        var arrayIndex:Int = 0
        var newCopyOfFirst:UIImage!
        
        var first:UIImage = UIImage()
        
        if let dataFromCache = self.dataCache.object(forKey: self.clickActions[0] as NSString) as? UIImage{
            first = dataFromCache
        }
        //UIGraphicsBeginImageContextWithOptions(first.size, true, 0)
        UIGraphicsBeginImageContext(first.size)
        
        first.draw(in: CGRect(x: 0, y: 0, width: first.size.width, height: first.size.height), blendMode: .normal, alpha: 1.0)
        newCopyOfFirst = UIGraphicsGetImageFromCurrentImageContext()!
        UIGraphicsEndImageContext()
        
        if(newCopyOfFirst.pngData() != nil){
            //print("UIImagePNGRepresentation(newCopyOfFirst) != nil")
            self.slideImages.append(newCopyOfFirst)
            self.clickActions.append("News")
            self.dataCache.setObject(newCopyOfFirst as AnyObject, forKey: self.clickActions[0] as NSString)
        }
        
        for image in self.slideImages {
            var theTag:Int = self.slideImages.index(of:image)!
            let xOrigin:CGFloat = CGFloat(theTag) * (width - 20)
            let imageView = UIImageView(frame: CGRect(x: xOrigin, y: 0, width: (width - 20), height: self.sliderView.frame.size.height))
            imageView.contentMode = .scaleAspectFill
            imageView.clipsToBounds = true
            if let dataFromCache = self.dataCache.object(forKey: self.clickActions[arrayIndex] as NSString) as? UIImage{
                
                imageView.image = dataFromCache
            }
            
            let textView = UIView()
            let textLabel = UILabel()
            
            let click_action =  self.clickActions[arrayIndex]
            
            if(click_action == "News")
            {
                textLabel.text = self.defaultLocalizer.stringForKey(key: "labelBreakingNews")
            }
            if(click_action == "Edubank")
            {
                textLabel.text = self.defaultLocalizer.stringForKey(key: "menuTitleEduBank")
            }
            if(click_action == "Eduforum")
            {
                textLabel.text = self.defaultLocalizer.stringForKey(key: "menuTitleEduForum")
            }
            
            textView.frame = CGRect.init(x: 0, y: textViewTop, width: imageView.bounds.size.width, height: textViewHeight)
            textView.backgroundColor = UIColor.black.withAlphaComponent(0.5)
            textLabel.frame = CGRect.init(x: 10, y: 0, width: textView.bounds.size.width - 20, height: textViewHeight)
            textLabel.textColor = UIColor.white
            textLabel.font = UIFont(name:"Helvetica Bold",size:16)
            textLabel.textAlignment = .center;
            
            let tapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(self.slideTap))
            textLabel.isUserInteractionEnabled = true
            textView.isUserInteractionEnabled = true
            textLabel.addGestureRecognizer(tapGestureRecognizer)
            textView.addGestureRecognizer(tapGestureRecognizer)
            
            textView.addSubview(textLabel)
            imageView.addSubview(textView)
            self.sliderView.addSubview(imageView)
            
            let button = UIButton(type: .custom)
            button.layer.borderColor = UIColor.clear.cgColor
            button.layer.backgroundColor = UIColor.clear.cgColor
            button.layer.borderWidth = 0
            
            let frame:CGRect = imageView.frame
            button.frame = frame
            
            if let dataFromCache = self.dataCache.object(forKey: self.clickActions[arrayIndex] as NSString) as? UIImage{
                
                let data1 = newCopyOfFirst.pngData()
                
                let data2 = dataFromCache.pngData()
                if (data1 == data2){
                    // last image is copy of first, should point to same ad....
                    //print("data1.isEqual(data2)")
                    theTag = 0
                }
            }
            
            button.tag = (7700 + theTag)
            button.addTarget(self, action: #selector(self.slideTap), for: UIControl.Event.touchUpInside)
            
            self.sliderView.addSubview(button)
            
            arrayIndex += 1
        }
        
        self.sliderView.contentSize = CGSize(width: CGFloat(self.slideImages.count) * (width - 20), height: self.view.frame.size.height)
    }
    
    @objc func slideTap(_sender: UIButton)
    {
        let tag:Int = _sender.tag - 7700
        
        if(tag == 0)
        {
            let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
            let vc = storyBoard.instantiateViewController(withIdentifier: "vcBreakingNews") as! BreakingNewsViewController
            vc.modalPresentationStyle = .fullScreen
            self.navigationController?.pushViewController(vc, animated: false)
        }
        
        if(tag == 1)
        {
            let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
            let vc = storyBoard.instantiateViewController(withIdentifier: "vcEduBank") as! EduBankViewController
            vc.modalPresentationStyle = .fullScreen
            self.navigationController?.pushViewController(vc, animated: false)
        }
        
        if(tag == 2)
        {
            let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
            let vc = storyBoard.instantiateViewController(withIdentifier: "vcTopics") as! TopicsViewController
            vc.modalPresentationStyle = .fullScreen
            self.navigationController?.pushViewController(vc, animated: false)
        }
    }
    
    @objc func flip() {
        let transitionOptions: UIView.AnimationOptions = [.transitionFlipFromRight, .repeat]
        
        UIView.transition(with: imageViewBack, duration: 3.0, options: transitionOptions, animations: {
            self.imageViewBack.isHidden = true
        })
        
        UIView.transition(with: imageView, duration: 3.0, options: transitionOptions, animations: {
            self.imageView.isHidden = false
        })
    }
    
    func setupHomeTabs()
    {
        let tabbarHeight = getTabbarHeight()
        let scroolHeight = self.view.frame.size.height - (self.calculateTopDistance() + tabbarHeight)
        
        let layout: UICollectionViewFlowLayout = UICollectionViewFlowLayout()
        layout.scrollDirection = .vertical
        
        self.collectionViewHome = UICollectionView(frame: CGRect(x: 10, y: self.calculateTopDistance() + 140, width: self.view.frame.width - 20, height: scroolHeight - 130), collectionViewLayout: layout)
        
        self.collectionViewHome.dataSource = self
        self.collectionViewHome.delegate = self
        self.collectionViewHome.register(UINib(nibName: "HomeCollectionViewCell", bundle: nil), forCellWithReuseIdentifier: cellIdentifier)
        self.collectionViewHome.backgroundColor = UIColor.white
        
        self.view.addSubview(self.collectionViewHome)
        
        self.getTabItems()
    }
    
    func etCellBackground(indexPathRightBound: Int)
    {
        let indexPath  : IndexPath = [0, indexPathRightBound]
        selectedCell = indexPath
        self.collectionViewHome.reloadData()
    }
    
    func getBadge()
    {
        // To make the activity indicator appear:
        
        if let viewWithTag = self.view.viewWithTag(7575) {
            viewWithTag.removeFromSuperview()
        }
        
        let schoolid = getSchoolId()
        let teacherid = getTeacherId()
        
        let currentDate = Date()
        let inputFormatter = DateFormatter()
        inputFormatter.dateFormat = "dd-MM-yyyy"
        let formatedCurrentDate = inputFormatter.string(from: currentDate)
        
        if var urlComponents = URLComponents(string: Constants.baseUrl + "GetTeacherModuleWithBadgeV2") {
            urlComponents.query = "schoolid=\(schoolid)&accessdate=\(formatedCurrentDate)&teacherid=\(teacherid)"
            // 3
            guard let url = urlComponents.url else { return }
            
            //print("\n\n\n\n\nurl: \(url)")
            
            getData(from: url) { data, response, error in
                if error != nil {
                    print(error!.localizedDescription)
                }
                guard let data = data else { return }
                //Implement JSON decoding and parsing
                do {
                    //Decode retrived data with JSONDecoder and assing type of Article object
                    let badgeData = try JSONDecoder().decode(BadgeResult.self, from: data)
                    
                    DispatchQueue.main.async {
                        self.badge = badgeData.Badges
                        setNoticeCount(noticeCount: (self.badge?.Notice)!)
                        setEventCount(eventCount: (self.badge?.Event)!)
                        self.collectionViewHome.reloadData()
                    }
                    
                } catch let jsonError {
                    print(jsonError)
                }
            }
        }
    }
    
    func getTabItems(){
        self.moduleNameArray.append("Events")
        self.moduleNameArray.append("Notice")
        self.moduleNameArray.append("Classroom")
        self.moduleNameArray.append("Schooldiary")
        self.moduleNameArray.append("Announcement")
        self.moduleNameArray.append("Examination")
        self.moduleNameArray.append("AbsentReport")
        self.moduleNameArray.append("Edubank")
        self.moduleNameArray.append("Eduforum")
        self.moduleNameArray.append("Help")
    }
    
    func removeSubView(tag: Int)
    {
        
        if let viewWithTag = self.view.viewWithTag(tag) {
            viewWithTag.removeFromSuperview()
        }
        
        if let viewWithTag = self.view.viewWithTag(tag) {
            viewWithTag.removeFromSuperview()
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
        return UIEdgeInsets(top: 10, left: 0, bottom: 10, right: 0)
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let collectionViewWidth = collectionView.bounds.width - 30
        return CGSize(width: collectionViewWidth/3, height: collectionViewWidth/3)
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return 0
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        let tabbarHeight = getTabbarHeight()
        let scroolHeight = self.view.frame.size.height - (self.calculateTopDistance() + tabbarHeight)
        
        let collectionViewWidth = collectionView.bounds.width - 30
        return ((scroolHeight - 145) - ((collectionViewWidth / 3) * 4)) / 4
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return self.moduleNameArray.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: cellIdentifier, for: indexPath) as! HomeCollectionViewCell
        cell.contentView.backgroundColor = .white
        
        let cellwidth = cell.frame.width;
        cell.tabLabel.frame.size = CGSize(width: cellwidth, height: 15)
        cell.tabLabel.textAlignment = .center
        
        cell.tabButton.tag = indexPath.item + 1
        
        cell.badgeView.frame = CGRect(x: cell.tabButton.bounds.maxX + 10, y: cell.tabButton.bounds.minY + 5, width: 20, height: 20)
        cell.badgeView.layer.cornerRadius = 10
        cell.badgeView.clipsToBounds = true
        cell.badgeView.isHidden = true
        cell.updateConstraints()
        cell.layoutIfNeeded()
        
        switch (self.moduleNameArray[indexPath.item]) {
            case "Events":
                removeSubView(tag: 5000)
                cell.tabButton.image = UIImage(named: "calendar")
                cell.tabLabel.text = self.defaultLocalizer.stringForKey(key: "menuTitleEvents")
                cell.tabButton.tintColor = colorWithHexString(hex: "#EC3136")
                cell.tabLabel.textColor = colorWithHexString(hex: "#EC3136")
                
                if(getEventCount() > 0){
                    cell.badgeView.isHidden = false
                    cell.badgeView.backgroundColor = colorWithHexString(hex: "#EC3136")
                    let eventBadgeLabel = UILabel(frame: CGRect(x: 5, y: 2.5, width: 15, height: 15))
                    eventBadgeLabel.tag = 5000
                    eventBadgeLabel.textColor = colorWithHexString(hex: "#FFFFFF")
                    eventBadgeLabel.text = String(getEventCount())
                    eventBadgeLabel.font = UIFont(name: "HelveticaNeue-Bold", size: 14)
                    cell.badgeView.addSubview(eventBadgeLabel)
                }
                else
                {
                    cell.badgeView.isHidden = true
                }
                break
            case "Notice":
                removeSubView(tag: 5001)
                cell.tabButton.image = UIImage(named: "notice")
                cell.tabLabel.text = self.defaultLocalizer.stringForKey(key: "navBarTitleNews")
                cell.tabButton.tintColor = colorWithHexString(hex: "#344A9B")
                cell.tabLabel.textColor = colorWithHexString(hex: "#344A9B")
                
                if(getNoticeCount() > 0){
                    cell.badgeView.isHidden = false
                    cell.badgeView.backgroundColor = colorWithHexString(hex: "#EC3136")
                    let noticeBadgeLabel = UILabel(frame: CGRect(x: 5, y: 2.5, width: 15, height: 15))
                    noticeBadgeLabel.tag = 5001
                    noticeBadgeLabel.textColor = colorWithHexString(hex: "#FFFFFF")
                    noticeBadgeLabel.text = String(getNoticeCount())
                    noticeBadgeLabel.font = UIFont(name: "HelveticaNeue-Bold", size: 14)
                    cell.badgeView.addSubview(noticeBadgeLabel)
                }
                else
                {
                    cell.badgeView.isHidden = true
                }
                break
            case "Classroom":
                cell.tabButton.image = UIImage(named: "classroom-tab")
                cell.tabLabel.text = self.defaultLocalizer.stringForKey(key: "navBarTitleClassroom")
                cell.tabButton.tintColor = colorWithHexString(hex: "#f16136")
                cell.tabLabel.textColor = colorWithHexString(hex: "#f16136")
                
                cell.badgeView.isHidden = true
                break
            case "Schooldiary":
                cell.tabButton.image = UIImage(named: "schooldiary")
                cell.tabLabel.text = self.defaultLocalizer.stringForKey(key: "navBarTitleSchoolDiary")
                cell.tabButton.tintColor = colorWithHexString(hex: "#51A8B1")
                cell.tabLabel.textColor = colorWithHexString(hex: "#51A8B1")
                
                cell.badgeView.isHidden = true
                break
            case "Announcement":
                cell.tabButton.image = UIImage(named: "bell")
                cell.tabLabel.text = self.defaultLocalizer.stringForKey(key: "navBarTitleAnnouncements")
                cell.tabButton.tintColor = colorWithHexString(hex: "#EB258E")
                cell.tabLabel.textColor = colorWithHexString(hex: "#EB258E")
                
                let dummyBadgeView = UIView(frame: CGRect(x: 47.5, y: -2.5, width: 20, height: 20))
                dummyBadgeView.backgroundColor = UIColor.clear
                cell.tabButton.addSubview(dummyBadgeView)
                break
            case "Examination":
                cell.tabButton.image = UIImage(named: "exam")
                cell.tabLabel.text = self.defaultLocalizer.stringForKey(key: "navBarTitleExam")
                cell.tabButton.tintColor = colorWithHexString(hex: "#00AD57")
                cell.tabLabel.textColor = colorWithHexString(hex: "#00AD57")
                
                cell.badgeView.isHidden = true
                break
            case "AbsentReport":
                cell.tabButton.image = UIImage(named: "absentreport")
                cell.tabLabel.text = self.defaultLocalizer.stringForKey(key: "navBarTitleAbsentReport")
                cell.tabButton.tintColor = colorWithHexString(hex: "#7C3A93")
                cell.tabLabel.textColor = colorWithHexString(hex: "#7C3A93")
                
                cell.badgeView.isHidden = true
                break
            case "Edubank":
                cell.tabButton.image = UIImage(named: "edubank")
                cell.tabLabel.text = self.defaultLocalizer.stringForKey(key: "menuTitleEduBank")
                cell.tabButton.tintColor = colorWithHexString(hex: "#26BEBE")
                cell.tabLabel.textColor = colorWithHexString(hex: "#26BEBE")
                
                cell.badgeView.isHidden = true
                break
            case "Eduforum":
                cell.tabButton.image = UIImage(named: "eduforum")
                cell.tabLabel.text = self.defaultLocalizer.stringForKey(key: "menuTitleEduForum")
                cell.tabButton.tintColor = colorWithHexString(hex: "#0078bf")
                cell.tabLabel.textColor = colorWithHexString(hex: "#0078bf")
                
                cell.badgeView.isHidden = true
                break
            case "Query":
                cell.tabButton.image = UIImage(named: "query-home")
                cell.tabLabel.text = self.defaultLocalizer.stringForKey(key: "menuTitleQuery")
                cell.tabButton.tintColor = colorWithHexString(hex: "#0078bf")
                cell.tabLabel.textColor = colorWithHexString(hex: "#0078bf")
                
                cell.badgeView.isHidden = true
                break
            case "Help":
                cell.tabButton.image = UIImage(named: "help")
                cell.tabLabel.text = self.defaultLocalizer.stringForKey(key: "menuTitleHelp")
                cell.tabButton.tintColor = colorWithHexString(hex: "#7d3b94")
                cell.tabLabel.textColor = colorWithHexString(hex: "#7d3b94")
                
                cell.badgeView.isHidden = true
                break
            default:
                break
        }
        
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        selectedCell = indexPath
        self.collectionViewHome.reloadData()
        
        self.onCellSelect(itemIndex: indexPath.item)
    }
    
    @objc func didTapTabBarButton(sender: UIButton)
    {
        if(sender.tag == 0)
        {
            selectedCell = []
            
            self.collectionViewHome.reloadData()
            let vc = self.storyboard?.instantiateViewController(withIdentifier: "vcLandingPage") as! ViewController
            vc.modalPresentationStyle = .fullScreen
            self.navigationController?.pushViewController(vc, animated: false)
        }
        else
        {
            switch (self.moduleNameArray[(sender.tag - 1)]) {
                case "Events":
                    //setCellBackground(indexPathRightBound: (sender.tag - 1))
                    let vc = self.storyboard?.instantiateViewController(withIdentifier: "vcEvents") as! EventsViewController
                    vc.modalPresentationStyle = .fullScreen
                    self.navigationController?.pushViewController(vc, animated: false)
                    break
                case "Notice":
                    //setCellBackground(indexPathRightBound: (sender.tag - 1))
                    let vc = self.storyboard?.instantiateViewController(withIdentifier: "vcNews") as! NewsViewController
                    vc.modalPresentationStyle = .fullScreen
                    self.navigationController?.pushViewController(vc, animated: false)
                    break
                case "Classroom":
                    //setCellBackground(indexPathRightBound: (sender.tag - 1))
                    let vc = self.storyboard?.instantiateViewController(withIdentifier: "vcClassroom") as! ClassroomViewController
                    vc.modalPresentationStyle = .fullScreen
                    self.navigationController?.pushViewController(vc, animated: false)
                    break
                case "Announcement":
                    //setCellBackground(indexPathRightBound: (sender.tag - 1))
                    let vc = self.storyboard?.instantiateViewController(withIdentifier: "vcAnnouncement") as! AnnouncementViewController
                    vc.modalPresentationStyle = .fullScreen
                    self.navigationController?.pushViewController(vc, animated: false)
                    break
                case "Schooldiary":
                    //setCellBackground(indexPathRightBound: (sender.tag - 1))
                    let vc = self.storyboard?.instantiateViewController(withIdentifier: "dcSchoolDiary") as! SchoolDiaryViewController
                    vc.modalPresentationStyle = .fullScreen
                    self.navigationController?.pushViewController(vc, animated: false)
                    break
                case "AbsentReport":
                    //setCellBackground(indexPathRightBound: (sender.tag - 1))
                    let vc = self.storyboard?.instantiateViewController(withIdentifier: "vcAR") as! AbsentReportViewController
                    vc.modalPresentationStyle = .fullScreen
                    self.navigationController?.pushViewController(vc, animated: false)
                    break
                case "Examination":
                    //setCellBackground(indexPathRightBound: (sender.tag - 1))
                    let vc = self.storyboard?.instantiateViewController(withIdentifier: "vcExam") as! ExamViewController
                    vc.modalPresentationStyle = .fullScreen
                    self.navigationController?.pushViewController(vc, animated: false)
                    break
                case "Edubank":
                    //setCellBackground(indexPathRightBound: (sender.tag - 1))
                    let vc = self.storyboard?.instantiateViewController(withIdentifier: "vcEduBank") as! EduBankViewController
                    vc.modalPresentationStyle = .fullScreen
                    self.navigationController?.pushViewController(vc, animated: false)
                    break
                case "Eduforum":
                    //setCellBackground(indexPathRightBound: (sender.tag - 1))
                    let vc = self.storyboard?.instantiateViewController(withIdentifier: "vcTopics") as! TopicsViewController
                    vc.modalPresentationStyle = .fullScreen
                    self.navigationController?.pushViewController(vc, animated: false)
                    break
                case "Query":
                    //setCellBackground(indexPathRightBound: (sender.tag - 1))
                    let vc = self.storyboard?.instantiateViewController(withIdentifier: "vcQuery") as! QueryViewController
                    vc.modalPresentationStyle = .fullScreen
                    self.navigationController?.pushViewController(vc, animated: false)
                    break
                case "Help":
                    //setCellBackground(indexPathRightBound: (sender.tag - 1))
                    let vc = self.storyboard?.instantiateViewController(withIdentifier: "vcHelp") as! HelpViewController
                    vc.modalPresentationStyle = .fullScreen
                    self.navigationController?.pushViewController(vc, animated: false)
                    break
                default:
                    break
            }
        }
    }
    
    func onCellSelect(itemIndex: Int)
    {
        
        switch (self.moduleNameArray[itemIndex]) {
            case "Events":
                //setCellBackground(indexPathRightBound: itemIndex)
                let vc = self.storyboard?.instantiateViewController(withIdentifier: "vcEvents") as! EventsViewController
                vc.modalPresentationStyle = .fullScreen
                self.navigationController?.pushViewController(vc, animated: false)
                break
            case "Notice":
                //setCellBackground(indexPathRightBound: itemIndex)
                let vc = self.storyboard?.instantiateViewController(withIdentifier: "vcNews") as! NewsViewController
                vc.modalPresentationStyle = .fullScreen
                self.navigationController?.pushViewController(vc, animated: false)
                break
            case "Classroom":
                //setCellBackground(indexPathRightBound: itemIndex)
                let vc = self.storyboard?.instantiateViewController(withIdentifier: "vcClassroom") as! ClassroomViewController
                vc.modalPresentationStyle = .fullScreen
                self.navigationController?.pushViewController(vc, animated: false)
                break
            case "Schooldiary":
                //setCellBackground(indexPathRightBound: itemIndex)
                let vc = self.storyboard?.instantiateViewController(withIdentifier: "dcSchoolDiary") as! SchoolDiaryViewController
                vc.modalPresentationStyle = .fullScreen
                self.navigationController?.pushViewController(vc, animated: false)
                break
            case "Announcement":
                //setCellBackground(indexPathRightBound: itemIndex)
                let vc = self.storyboard?.instantiateViewController(withIdentifier: "vcAnnouncement") as! AnnouncementViewController
                vc.modalPresentationStyle = .fullScreen
                self.navigationController?.pushViewController(vc, animated: false)
                break
            case "Examination":
                //setCellBackground(indexPathRightBound: itemIndex)
                let vc = self.storyboard?.instantiateViewController(withIdentifier: "vcExam") as! ExamViewController
                vc.modalPresentationStyle = .fullScreen
                self.navigationController?.pushViewController(vc, animated: false)
                break
            case "AbsentReport":
                //setCellBackground(indexPathRightBound: itemIndex)
                let vc = self.storyboard?.instantiateViewController(withIdentifier: "vcAR") as! AbsentReportViewController
                vc.modalPresentationStyle = .fullScreen
                self.navigationController?.pushViewController(vc, animated: false)
                break
            case "Edubank":
                //setCellBackground(indexPathRightBound: itemIndex)
                let vc = self.storyboard?.instantiateViewController(withIdentifier: "vcEduBank") as! EduBankViewController
                vc.modalPresentationStyle = .fullScreen
                self.navigationController?.pushViewController(vc, animated: false)
                break
            case "Eduforum":
                //setCellBackground(indexPathRightBound: itemIndex)
                let vc = self.storyboard?.instantiateViewController(withIdentifier: "vcTopics") as! TopicsViewController
                vc.modalPresentationStyle = .fullScreen
                self.navigationController?.pushViewController(vc, animated: false)
                break
            case "Query":
                //setCellBackground(indexPathRightBound: itemIndex)
                let vc = self.storyboard?.instantiateViewController(withIdentifier: "vcQuery") as! QueryViewController
                vc.modalPresentationStyle = .fullScreen
                self.navigationController?.pushViewController(vc, animated: false)
                break
            case "Help":
                //setCellBackground(indexPathRightBound: itemIndex)
                let vc = self.storyboard?.instantiateViewController(withIdentifier: "vcHelp") as! HelpViewController
                vc.modalPresentationStyle = .fullScreen
                self.navigationController?.pushViewController(vc, animated: false)
                break
            default:
                break
        }
    }
    
    /*@objc func getNews()
    {
        let schoolid = getSchoolId()
        var newsSearch:Bool = true
        let objArray: [NewsBadge]
        let date = Date()
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy-MM-dd"
        //let formatedDate = formatter.string(from: date)
        
        if(isKeyPresentInUserDefaults(key: "NewsBadgeDetails"))
        {
            objArray = getNewsBadgeDetails()
            
            //dump(objArray)
            let filtered = objArray.filter({
                return $0.schoolId == schoolid
            })
            
            if(filtered.count > 0)
            {
                let formatedNewsBadgeCheckDate = formatter.date(from: filtered[0].badgeCheckDate)
                
                let difference =  date.timeIntervalSince(formatedNewsBadgeCheckDate!)
                let differenceInDays = Int(difference/(60 * 60 * 24 ))
                newsSearch = differenceInDays == 0 ? false : true
            }
        }
        
        if(newsSearch == true)
        {
            if var urlComponents = URLComponents(string: Constants.baseUrl + "getNews") {
                urlComponents.query = "schoolid=" + schoolid
                // 3
                guard let url = urlComponents.url else { return }
                
                getData(from: url) { data, response, error in
                    if error != nil {
                        print(error!.localizedDescription)
                    }
                    guard let data = data else { return }
                    //Implement JSON decoding and parsing
                    do {
                        //Decode retrived data with JSONDecoder and assing type of Article object
                        let newsData = try JSONDecoder().decode(Result.self, from: data)
                        
                        self.response = newsData.Response
                        if(self.response?.ResponseVal == 1)
                        {
                            //Get back to the main queue
                            DispatchQueue.main.async {
                                self.news?.removeAll()
                                self.news = newsData.News
                                var badgeCount:Int = 0
                                
                                for newsObject in self.news! {
                                    let inputFormatter = DateFormatter()
                                    inputFormatter.dateFormat = "yyyy-MM-dd"
                                    let newDate = formateDateFromString(dateString: newsObject.NewsStartDate, withFormat: "yyyy-MM-dd")!
                                    
                                    let formatedNewsDate = inputFormatter.date(from: newDate)
                                    
                                    let currentDate = Date()
                                    
                                    let difference =  currentDate.timeIntervalSince(formatedNewsDate!)
                                    let differenceInDays = Int(difference/(60 * 60 * 24 ))
                                    
                                    if(differenceInDays == 0)
                                    {
                                        badgeCount += 1
                                    }
                                }
                                
                                if(badgeCount > 0){
                                    // Initialize Badge
                                    let badge = CAShapeLayer()
                                    badge.path = UIBezierPath(roundedRect: CGRect(x: self.navButtonNews.frame.width/2, y: 0, width: (self.navButtonNews.frame.width/2) + 2, height: (self.navButtonNews.frame.height/2) + 2), cornerRadius: (self.navButtonNews.frame.width/2) + 1).cgPath
                                    badge.fillColor = UIColor.red.cgColor
                                    //you can change the stroke color
                                    badge.strokeColor = UIColor.white.cgColor
                                    //you can change the line width
                                    badge.lineWidth = 1.0
                                    badge.name = "badgeLayer"
                                    self.navButtonNews.layer.addSublayer(badge)
                                    
                                    // Initialiaze Badge's label
                                    let label = CATextLayer()
                                    label.string = "\(badgeCount)"
                                    label.alignmentMode = .center
                                    label.fontSize = 11
                                    label.frame = CGRect(origin: CGPoint(x: (self.navButtonNews.frame.width/2) + 1, y: 0), size: CGSize(width: self.navButtonNews.frame.width/2, height: self.navButtonNews.frame.height/2))
                                    label.foregroundColor = UIColor.white.cgColor
                                    label.backgroundColor = UIColor.clear.cgColor
                                    label.contentsScale = UIScreen.main.scale
                                    badge.addSublayer(label)
                                }
                            }
                        }
                        
                    } catch let jsonError {
                        print(jsonError)
                    }
                }
            }
        }
    }
    
    @objc func navBarButtonNewsTap()
    {
        var objArray: [NewsBadge] = []
        let date = Date()
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy-MM-dd"
        let formatedDate = formatter.string(from: date)
        
        //set schoolwise badge check
        if(isKeyPresentInUserDefaults(key: "NewsBadgeDetails"))
        {
            objArray = getNewsBadgeDetails()
            if(objArray.count == 0)
            {
                objArray = [NewsBadge(schoolId: getSchoolId(), badgeCheckDate: formatedDate)]
            }
            else
            {
                let filtered = objArray.filter({
                    return $0.schoolId == getSchoolId()
                })
                
                //print(filtered.count)
                if(filtered.count > 0)
                {
                    //print("Before Remove: \(objArray.count)")
                    for i in 0..<filtered.count
                    {
                        let index = objArray.firstIndex(of: filtered[i])
                        objArray.remove(at: index!)
                    }
                    //print("After Remove: \(objArray.count)")
                    objArray.append(NewsBadge(schoolId: getSchoolId(), badgeCheckDate: formatedDate))
                }
                else
                {
                    objArray.append(NewsBadge(schoolId: getSchoolId(), badgeCheckDate: formatedDate))
                }
            }
        }
        else
        {
            objArray.append(NewsBadge(schoolId: getSchoolId(), badgeCheckDate: formatedDate))
        }
        
        setNewsBadgeDetails(NewsBadgeDetails: objArray)
        
        let vcCW = self.storyboard?.instantiateViewController(withIdentifier: "vcNews") as! NewsViewController
        
        present(vcCW, animated: false, completion: nil)
    }*/
    
    func setNavigationBar() {
        
        if(self.School_Logo.count > 0){
            if let url = URL(string: self.School_Logo) {
                getImageData(from: url) { data, response, error in
                    //let responseMessage = String(describing: response)
                    //print(responseMessage)
                    if error != nil {
                        print(error!.localizedDescription)
                    }
                    
                    guard let data = data else { return}
                    
                    DispatchQueue.main.async() {
                        
                        let containerView = UIView(frame: CGRect(x: 0, y: 0, width: 40, height: 40))
                        let imageview = UIImageView(frame: CGRect(x: 0, y: 0, width: 40, height: 40))
                        let sourceImage = UIImage(data: data)
                        //let shadowImage = sourceImage!.addShadow()
                        imageview.image = sourceImage
                        imageview.contentMode = .scaleAspectFit
                        containerView.layer.cornerRadius = 20
                        containerView.layer.masksToBounds = true
                        containerView.addSubview(imageview)
                        let leftBarButton = UIBarButtonItem(customView: containerView)
                        self.navigationItem.leftBarButtonItem = leftBarButton
                    }
                }
            }
        }
        
        let titleParameters = [NSAttributedString.Key.foregroundColor : UIColor.white,
                               NSAttributedString.Key.font : UIFont.boldSystemFont(ofSize: getSchoolTitleFontSize()), NSAttributedString.Key.shadow: setNavBarTitleShadow()] as [NSAttributedString.Key : Any]
        let subTitleParameters = [NSAttributedString.Key.foregroundColor : UIColor.white,
                                  NSAttributedString.Key.font : UIFont(name:"Helvetica", size: 14.0)!, NSAttributedString.Key.shadow: setNavBarTitleShadow()] as [NSAttributedString.Key : Any]
        
        let schoolName:NSMutableAttributedString = NSMutableAttributedString(string: self.School_Name.uppercased(), attributes: titleParameters)
        
        let fname = getFirstName() + " "
        let mname = getMiddleName().count > 0 ? getMiddleName() + " " : ""
        let lname = getLastName()
        let fullname = fname + mname + lname
        let teacherName:NSMutableAttributedString = NSMutableAttributedString(string: fullname, attributes: subTitleParameters)
        
        let width = self.view.frame.width - 60
        let height = CGFloat(40)
        
        let lebelSchoolName = UILabel(frame: CGRect.init(x: 0, y: 0, width: width, height: height - 16))
        lebelSchoolName.attributedText = schoolName
        lebelSchoolName.numberOfLines = 1
        lebelSchoolName.textAlignment = .center
        lebelSchoolName.adjustsFontSizeToFitWidth = true
        
        let labelTeacherName = UILabel(frame: CGRect.init(x: 0, y: (height - 15), width: width, height: 15))
        labelTeacherName.numberOfLines = 1
        labelTeacherName.textAlignment = .center
        labelTeacherName.attributedText = teacherName
        labelTeacherName.adjustsFontSizeToFitWidth = true
        
        let navView = UIStackView(arrangedSubviews: [lebelSchoolName, labelTeacherName])
        navView.axis = .vertical
        self.navigationItem.titleView = navView
        //navView.sizeToFit()
        
        if(self.ProfileImage.count > 0){
            if let url = URL(string: self.ProfileImage) {
                getImageData(from: url) { data, response, error in
                    //let responseMessage = String(describing: response)
                    //print(responseMessage)
                    if error != nil {
                        print(error!.localizedDescription)
                    }
                    
                    guard let data = data else { return}
                    
                    DispatchQueue.main.async() {
                        
                        let containerView = UIView(frame: CGRect(x: 0, y: 0, width: 40, height: 40))
                        let imageview = UIImageView(frame: CGRect(x: 0, y: 0, width: 40, height: 40))
                        let sourceImage = UIImage(data: data)
                        //let shadowImage = sourceImage!.addShadow()
                        imageview.image = sourceImage
                        imageview.contentMode = .scaleAspectFit
                        containerView.layer.cornerRadius = 20
                        containerView.layer.masksToBounds = true
                        imageview.isUserInteractionEnabled = true
                        
                        let tapgesture = UITapGestureRecognizer(target: self , action: #selector(self.ProfileImageTap))
                        imageview.addGestureRecognizer(tapgesture)
                        
                        containerView.addSubview(imageview)
                        let rightBarButton = UIBarButtonItem(customView: containerView)
                        self.navigationItem.rightBarButtonItem = rightBarButton
                    }
                }
            }
        }
    }
    
    @objc func ProfileImageTap(_ sender: UITapGestureRecognizer)
    {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "vcProfileView") as! ProfileViewController
        vc.modalPresentationStyle = .fullScreen
        vc.schoolName = getSchoolName()
        let fname = getFirstName() + " "
        let mname = getMiddleName().count > 0 ? getMiddleName() + " " : ""
        let lname = getLastName()
        let fullname = fname + mname + lname
        vc.teacherName = fullname
        vc.email = getEmail()
        vc.mobile = getMobile()
        vc.dob = getDOB()
        vc.gender = getGender()
        vc.imagePath = getProfileImage()
        vc.schoolIds.append(Int(getSchoolId())!)
        vc.schoolNames.append(getSchoolName())
        
        vcShared.vcshared.vcName = "ViewProfile"
        
        self.present(vc, animated: false, completion: nil)
        CFRunLoopWakeUp(CFRunLoopGetCurrent())
    }
    
    func calculateTopDistance () -> CGFloat{
        if(self.navigationController != nil && !self.navigationController!.navigationBar.isTranslucent){
            return 0
        }else{
            
            let barHeight = self.navigationController?.navigationBar.frame.height ?? 0
            var statusBarHeight:CGFloat = 0
            
            if #available(iOS 13.0, *) {
                
                let sharedApplication = UIApplication.shared
                statusBarHeight = (sharedApplication.delegate?.window??.windowScene?.statusBarManager?.statusBarFrame)!.height

            } else {
                
                statusBarHeight = UIApplication.shared.isStatusBarHidden ? CGFloat(0) : UIApplication.shared.statusBarFrame.height
                
                if let statusBar = UIApplication.shared.value(forKey: "statusBar") as? UIView {
                    statusBar.backgroundColor = colorWithHexString(hex: "#00CCFF")
                }
            }
            
            return barHeight + statusBarHeight
        }
    }
    
    func popoverPresentationControllerDidDismissPopover(_ popoverPresentationController: UIPopoverPresentationController) {
        //print("Dismissed")
    }
    
    private func popoverPresentationControllerShouldDismissPopover(_ popoverPresentationController: UIPopoverPresentationController) {
        
        //return true
        
    }
    
    func prepareForPopoverPresentation(_ popoverPresentationController: UIPopoverPresentationController) {
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "seguePopover" {
        
            let popoverViewController = segue.destination
            let popoverPresentationController = popoverViewController.popoverPresentationController
            popoverPresentationController?.delegate = self
            popoverPresentationController?.sourceView = self.view
            popoverPresentationController?.sourceRect = CGRect(x: self.view.frame.width - 210, y: -380, width: 230, height: 380)
            popoverPresentationController?.permittedArrowDirections = [.up]
            
            popoverViewController.popoverPresentationController!.delegate = self
        }
    }
    
    func setAlphaOfBackgroundViews(alpha: CGFloat) {
        let statusBarWindow = UIApplication.shared.value(forKey: "statusBarWindow") as? UIWindow
        UIView.animate(withDuration: 0.2) {
            statusBarWindow?.alpha = alpha
            self.view.alpha = alpha
            self.navigationController?.navigationBar.alpha = alpha
        }
    }
    
    func adaptivePresentationStyle(for controller: UIPresentationController) -> UIModalPresentationStyle {
        // Tells iOS that we do NOT want to adapt the presentation style for iPhone
        return .none
    }
    
    func getxBound()-> CGFloat{
        var xbounds = 0.00
        if #available(iOS 11.0, *) {
            if let window = UIApplication.shared.keyWindow {
                xbounds = Double((view.bounds.width - window.safeAreaInsets.right))
            }
        }
        else
        {
            xbounds = Double(view.bounds.width)
        }
        
        return CGFloat(xbounds)
    }
    
    func getyBound()-> CGFloat{
        
        var xbounds = 0.00
        if #available(iOS 11.0, *) {
            if let window = UIApplication.shared.keyWindow {
                xbounds = Double((view.bounds.height -  window.safeAreaInsets.bottom))
            }
        }
        else
        {
            xbounds = Double(view.bounds.height)
        }
        
        let preferences = UserDefaults.standard
        
        let yboundKey = "yBound"
        if preferences.object(forKey: yboundKey) == nil {
            //  Doesn't exist
            preferences.set(Double(xbounds), forKey: yboundKey)
            
            preferences.synchronize()
        } else {
            xbounds = preferences.double(forKey: yboundKey)
        }
        
        return CGFloat(xbounds)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

extension UIView{
    
    func showFlip(){
        if self.isHidden{
            UIView.transition(with: self, duration: 1, options: [.transitionFlipFromRight,.allowUserInteraction], animations: nil, completion: nil)
            self.isHidden = false
        }
        
    }
    func hideFlip(){
        if !self.isHidden{
            UIView.transition(with: self, duration: 1, options: [.transitionFlipFromLeft,.allowUserInteraction], animations: nil,  completion: nil)
            self.isHidden = true
        }
    }
}
