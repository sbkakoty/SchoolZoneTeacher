//
//  Constants.swift
//  SchoolZoneTeacher
//
//  Created by Apple on 27/03/19.
//  Copyright © 2019 ClearWin Technologies. All rights reserved.
//

import Foundation

class Constants {
    static let baseUrl = "https://indiaapi.ourschoolzone.org/api/"
}
