//
//  BadgeModel.swift
//  SchoolZoneTeacher
//
//  Created by Apple on 24/11/19.
//  Copyright © 2019 ClearWin Technologies. All rights reserved.
//

import Foundation

struct Badges: Codable {
    let Notice: Int?
    let Event: Int?
}
