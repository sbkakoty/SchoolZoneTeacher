//
//  SlideModel.swift
//  SchoolZoneTeacher
//
//  Created by Apple on 26/03/20.
//  Copyright © 2020 ClearWin Technologies. All rights reserved.
//

import Foundation
struct Slide: Codable {
    let slideid: String
    let title: String
    let img_url: String
    let click_action: String
}
