//
//  VersionInfModel.swift
//  SchoolZoneTeacher
//
//  Created by Apple on 01/12/19.
//  Copyright © 2019 ClearWin Technologies. All rights reserved.
//

import Foundation

struct VersionInf: Codable {
    let id: String
    let version: String
    let description: String
}
