//
//  ExaminationModel.swift
//  SchoolZoneTeacher
//
//  Created by Apple on 29/12/18.
//  Copyright © 2018 ClearWin Technologies. All rights reserved.
//

import Foundation

struct Examination: Codable {
    let id: String?
    let ExamName: String?
    let ResultDoc: String?
}
