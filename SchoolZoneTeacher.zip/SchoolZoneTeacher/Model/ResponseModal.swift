//
//  ResponseModal.swift
//  SchoolZoneTeacher
//
//  Created by Apple on 18/12/18.
//  Copyright © 2018 ClearWin Technologies. All rights reserved.
//

import Foundation

struct Response: Codable {
    let ResponseVal: Int32?
    let Reason: String?
}
