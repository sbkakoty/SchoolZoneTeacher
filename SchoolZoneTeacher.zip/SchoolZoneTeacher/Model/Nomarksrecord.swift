//
//  Nomarksrecord.swift
//  SchoolZoneTeacher
//
//  Created by Apple on 03/03/19.
//  Copyright © 2019 ClearWin Technologies. All rights reserved.
//

import Foundation

struct Nomarksrecord: Codable {
    let ResponseVal: Int32?
    let Reason: String?
}
