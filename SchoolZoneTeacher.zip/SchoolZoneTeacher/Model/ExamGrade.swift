//
//  ExamGrade.swift
//  SchoolZoneTeacher
//
//  Created by Apple on 01/03/19.
//  Copyright © 2019 ClearWin Technologies. All rights reserved.
//

import Foundation

struct ExamGrade: Codable {
    let start_per: String?
    let end_per: String?
    let grade: String?
}
