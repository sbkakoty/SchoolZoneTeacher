//
//  ExamTimeTableModel.swift
//  SchoolZoneTeacher
//
//  Created by Apple on 29/12/18.
//  Copyright © 2018 ClearWin Technologies. All rights reserved.
//

import Foundation

struct ExamTimeTable: Codable {
    let ID: String?
    let Examination_Name: String?
    //let Start_Date: String?
    //let End_Date: String?
    let Timetable_Path: String?
}
