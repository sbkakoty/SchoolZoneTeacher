//
//  HelpViewController.swift
//  SchoolZoneTeacher
//
//  Created by Apple on 21/11/19.
//  Copyright © 2019 ClearWin Technologies. All rights reserved.
//

import UIKit
import SCLAlertView
import WebKit
import MaterialComponents

class FAQViewController: UIViewController, WKNavigationDelegate {
    
    let activityIndicator = MDCActivityIndicator()
    let defaultLocalizer = AMPLocalizeUtils.defaultLocalizer
    
    let appearance = SCLAlertView.SCLAppearance(
        kTitleFont: UIFont(name: "HelveticaNeue", size: 20)!,
        kTextFont: UIFont(name: "HelveticaNeue", size: 14)!,
        kButtonFont: UIFont(name: "HelveticaNeue-Bold", size: 14)!
    )
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        
        if(getLanguage().count > 0)
        {
            defaultLocalizer.setSelectedLanguage(lang: getLanguage())
        }
        else
        {
            defaultLocalizer.setSelectedLanguage(lang: "en")
        }
        
        self.setNavigationBar()
        
        if let viewWithTag = self.view.viewWithTag(100) {
            viewWithTag.removeFromSuperview()
        }
        
        let tabbarHeight = getTabbarHeight()
        let scroolHeight = self.view.frame.size.height - (self.calculateTopDistance() + tabbarHeight)
        
        let webview = WKWebView(frame: CGRect(x: 0, y: self.calculateTopDistance() + 5, width: self.view.frame.size.width, height: scroolHeight))
        webview.tag = 100
        //webview.delegate = self
        webview.navigationDelegate = self
        
        self.activityIndicator.sizeToFit()
        self.activityIndicator.center.x = super.view.center.x
        self.activityIndicator.center.y = (super.view.center.y - 50)
        webview.addSubview(activityIndicator)
        
        if let webViewURL = URL(string: "https://www.ourschoolzone.org/faq/teacher.html") {
            let webViewURLRequest = URLRequest(url: webViewURL)
            //webview.loadRequest(webViewURLRequest)
            webview.load(webViewURLRequest)
            if(webview.isLoading)
            {
                self.activityIndicator.startAnimating()
            }
            
            self.view.addSubview(webview)
        }
    }
    
    /*func webViewDidStartLoad(_ webView: UIWebView) // show indicator
     {
     self.activityIndicator.startAnimating()
     }
     func webViewDidFinishLoad(_ webView: UIWebView) // hide indicator
     {
     self.activityIndicator.stopAnimating()
     }
     func webView(_ webView: UIWebView, didFailLoadWithError error: Error) // hide indicator
     {
     self.activityIndicator.stopAnimating()
     }*/
    
    func webView(_ webView: WKWebView, didFailProvisionalNavigation navigation: WKNavigation!, withError error: Error) {
        print(error.localizedDescription)
    }
    func webView(_ webView: WKWebView, didStartProvisionalNavigation navigation: WKNavigation!) {
        self.activityIndicator.startAnimating()
    }
    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        self.activityIndicator.stopAnimating()
    }
    
    func calculateTopDistance () -> CGFloat{
        if(self.navigationController != nil && !self.navigationController!.navigationBar.isTranslucent){
            return 0
        }else{
            let barHeight=self.navigationController?.navigationBar.frame.height ?? 0
            let statusBarHeight = UIApplication.shared.isStatusBarHidden ? CGFloat(0) : UIApplication.shared.statusBarFrame.height
            return barHeight + statusBarHeight
        }
    }
    
    func setNavigationBar() {
        let navigationFont = UIFont(name: "Helvetica", size: getTitleFontSize())
        
        let button = UIButton.init(type: .custom)
        button.setTitle(self.defaultLocalizer.stringForKey(key: "navBarButtonBack"), for: UIControl.State.normal)
        var image = UIImage.init(named: "back")
        let templateImage = image?.withRenderingMode(UIImage.RenderingMode.alwaysTemplate)
        image = templateImage
        button.setImage(image, for: UIControl.State.normal)
        button.addTarget(self, action:#selector(back), for:.touchUpInside)
        button.addTarget(self, action:#selector(back), for:.touchUpOutside)
        button.frame = CGRect.init(x: 0, y: 0, width: 20, height: 20) //CGRectMake(0, 0, 30, 30)
        let doneItem = UIBarButtonItem.init(customView: button)
        self.navigationItem.leftBarButtonItem = doneItem
        
        let width = self.view.frame.width - 60
        let height = CGFloat(44)
        
        let titleLabel = UILabel(frame: CGRect.init(x: 0, y: 0, width: width, height: height))
        titleLabel.text = self.defaultLocalizer.stringForKey(key: "menuTitleFAQ")
        titleLabel.textAlignment = .center
        titleLabel.font = navigationFont
        titleLabel.textColor = .white
        titleLabel.sizeToFit()
        
        self.navigationItem.titleView = titleLabel
    }
    
    @objc func buttonShareTap()
    {
        let someText:String = "OurSchoolZone"
        let urlString = URLShared.urlshared.url!.addingPercentEncoding(withAllowedCharacters:NSCharacterSet.urlQueryAllowed)!
        let objectsToShare = URL(string: urlString)
        let sharedObjects:[AnyObject] = [objectsToShare as AnyObject,someText as AnyObject]
        
        let activityViewController:UIActivityViewController = UIActivityViewController(activityItems: sharedObjects, applicationActivities: nil)
        activityViewController.excludedActivityTypes = [UIActivity.ActivityType.print, UIActivity.ActivityType.postToWeibo, UIActivity.ActivityType.copyToPasteboard, UIActivity.ActivityType.addToReadingList, UIActivity.ActivityType.postToVimeo]
        self.present(activityViewController, animated: true, completion: nil)
    }
    
    @objc func back() { // remove @objc for Swift 3
        self.navigationController?.popViewController(animated: false)
    }
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destination.
     // Pass the selected object to the new view controller.
     }
     */
    
}
