//
//  ClassroomViewController.swift
//  SchoolZoneTeacher
//
//  Created by Apple on 11/10/19.
//  Copyright © 2019 ClearWin Technologies. All rights reserved.
//

import UIKit
import MaterialComponents
import iOSDropDown
import SCLAlertView
import Lightbox

class ClassroomViewController: UIViewController, UITextFieldDelegate, UITextViewDelegate, MDCTabBarDelegate, UIPopoverPresentationControllerDelegate, UITableViewDelegate, UITableViewDataSource, UISearchBarDelegate, LightboxControllerPageDelegate, LightboxControllerDismissalDelegate {
    
    let defaultLocalizer = AMPLocalizeUtils.defaultLocalizer
    let activityIndicator = MDCActivityIndicator()
    var result:Result?
    var classworks:[Classwork]?
    var homeworks:[Homework]?
    var assignments:[Assignment]?
    var students:[Student]?
    var classsections:[Classsection]?
    var response:Response?
    
    var classIds = [Int]()
    var classNames = [String]()
    var selectedStudentIds = [Int]()
    
    var tabBar = MDCTabBar()
    var tableView = UITableView()
    var footerView: UIView?
    let FOOTERHEIGHT : CGFloat = 170
    var refreshControlCW = UIRefreshControl()
    var refreshControlHW = UIRefreshControl()
    var refreshControlPW = UIRefreshControl()
    let buttonSelectAll = UIButton(type: .custom)
    var searchBar = UISearchBar()
    var searchActive : Bool = false
    var txtAttendanceDate = UITextField()
    var buttonCalendar = UIButton()
    var selectedDate = Date()
    var filtered:[Student] = []
    var classid = Int()
    
    var dropDown = DropDown()
    
    let buttonSelectAllLabel = UILabel(frame: CGRect(x: 0, y: 1, width: 100, height: 40))
    
    let appearance = SCLAlertView.SCLAppearance(
        kTitleFont: UIFont(name: "HelveticaNeue", size: 20)!,
        kTextFont: UIFont(name: "HelveticaNeue", size: 14)!,
        kButtonFont: UIFont(name: "HelveticaNeue-Bold", size: 14)!,
        showCloseButton: false
    )
    
    var ProfileImage: String!
    var School_id: String!
    var School_Name: String!
    var School_Logo: String!
    var TeacherID: String!
    var swipeTabCount = 0
    
    var statusBarShouldBeHidden = false
    
    open override var childForStatusBarHidden: UIViewController? {
        return nil
    }
    
    open override var prefersStatusBarHidden: Bool{
        return statusBarShouldBeHidden
    }
    
    @objc func swiped(_ gesture: UISwipeGestureRecognizer) {
        //print(swipeTabCount)
        if gesture.direction == .left {
            if(swipeTabCount < 3)
            {
                swipeTabCount += 1
            }
        } else if gesture.direction == .right {
            if(swipeTabCount > 0)
            {
                swipeTabCount -= 1
            }
        }
        
        tabBar.selectedItem = tabBar.items[swipeTabCount]
        switch(swipeTabCount)
        {
        case 0:
            loadClassWorkView()
            break
        case 1:
            loadHomeWorkView()
            break
        case 2:
            loadAssignmentView()
            break
        case 3:
            loadAttendanceView()
            break
        default:
            loadClassWorkView()
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        self.loadClass()
        self.getClassworks()
        self.getHomeworks()
        self.getAssignments()
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        self.setNeedsStatusBarAppearanceUpdate()
        
        /*let swipeRight = UISwipeGestureRecognizer(target: self, action: #selector(swiped))
         swipeRight.direction = UISwipeGestureRecognizer.Direction.right
         self.view.addGestureRecognizer(swipeRight)
         
         let swipeLeft = UISwipeGestureRecognizer(target: self, action: #selector(swiped))
         swipeLeft.direction = UISwipeGestureRecognizer.Direction.left
         self.view.addGestureRecognizer(swipeLeft)*/
        
        if(getLanguage().count > 0)
        {
            defaultLocalizer.setSelectedLanguage(lang: getLanguage())
        }
        else
        {
            defaultLocalizer.setSelectedLanguage(lang: "en")
        }
        
        self.ProfileImage = getProfileImage()
        self.School_id = getSchoolId()
        self.School_Name = getSchoolName()
        self.School_Logo = getSchoolLogo()
        self.TeacherID = getTeacherId()
        
        Reachability.isInternetAvailable(webSiteToPing: nil) { (isInternetAvailable) in
            guard isInternetAvailable else {
                //Get back to the main queue
                DispatchQueue.main.async {
                    // Inform user for example
                    let alertView = SCLAlertView(appearance: self.appearance)
                    alertView.addButton(self.defaultLocalizer.stringForKey(key: "actionSheetTitleOK")) {
                        alertView.dismiss(animated: true, completion: nil)
                    }
                    alertView.showError("OurSchoolZone", subTitle: "OOps! Internet Connection Appears To Be Offline.", closeButtonTitle: self.defaultLocalizer.stringForKey(key: "actionSheetTitleOK"))
                }
                return
            }
            
            // Do some action if there is Internet
        }
        
        self.setNavigationBar()
        
        self.setTabBar()
    }
    
    func setNavigationBar() {
        let navigationFont = UIFont(name: "Helvetica", size: getTitleFontSize())
        let button = UIButton.init(type: .custom)
        button.setTitle(self.defaultLocalizer.stringForKey(key: "navBarButtonBack"), for: UIControl.State.normal)
        var image = UIImage.init(named: "back")
        let templateImage = image?.withRenderingMode(UIImage.RenderingMode.alwaysTemplate)
        image = templateImage
        button.setImage(image, for: UIControl.State.normal)
        button.addTarget(self, action:#selector(back), for:.touchUpInside)
        button.addTarget(self, action:#selector(back), for:.touchUpOutside)
        button.frame = CGRect.init(x: 0, y: 0, width: 20, height: 20) //CGRectMake(0, 0, 30, 30)
        let doneItem = UIBarButtonItem.init(customView: button)
        self.navigationItem.leftBarButtonItem = doneItem
        
        let width = self.view.frame.width - 60
        let height = CGFloat(44)
        
        let titleLabel = UILabel(frame: CGRect.init(x: 0, y: 0, width: width, height: height))
        titleLabel.text = self.defaultLocalizer.stringForKey(key: "navBarTitleClassroom")
        titleLabel.textAlignment = .center
        titleLabel.font = navigationFont
        titleLabel.textColor = .white
        titleLabel.sizeToFit()
        
        self.navigationItem.titleView = titleLabel
    }
    
    func setTabBar() {
        let vcCW = ClassworkViewController()
        vcCW.tabBarItem = UITabBarItem(title: defaultLocalizer.stringForKey(key: "tabItemClassWork"), image: nil, tag: 0)
        
        let vcHW = HomeworkViewController()
        vcHW.tabBarItem =  UITabBarItem(title: defaultLocalizer.stringForKey(key: "tabItemHomeWork"), image: nil, tag: 1)
        
        let vcPW = AssignmentViewController()
        vcPW.tabBarItem = UITabBarItem(title: defaultLocalizer.stringForKey(key: "tabItemAssignment"), image: nil, tag: 2)
        
        let vcAT = AttendanceViewController()
        vcAT.tabBarItem = UITabBarItem(title: defaultLocalizer.stringForKey(key: "tabItemAttendance"), image: nil, tag: 3)
        
        tabBar = MDCTabBar(frame: CGRect(x: 0, y: self.calculateTopDistance(), width: self.view.frame.size.width, height: 48))
        
        tabBar.items = [ vcCW.tabBarItem,
                         vcHW.tabBarItem,
                         vcPW.tabBarItem,
                         vcAT.tabBarItem
        ]
        
        
        if(SharedSelectedTabIndex.sharedSelectedTabIndex.index != nil)
        {
            tabBar.selectedItem = tabBar.items[SharedSelectedTabIndex.sharedSelectedTabIndex.index]
            switch(SharedSelectedTabIndex.sharedSelectedTabIndex.index)
            {
            case 0:
                loadClassWorkView()
                swipeTabCount = 0
                break
            case 1:
                loadHomeWorkView()
                swipeTabCount = 1
                break
            case 2:
                loadAssignmentView()
                swipeTabCount = 2
                break
            default:
                loadClassWorkView()
            }
        }
        else
        {
            self.loadClassWorkView()
            tabBar.selectedItem = tabBar.items[0]
        }
        
        tabBar.delegate = self
        
        tabBar.itemAppearance = .titles
        tabBar.alignment = .justified
        tabBar.tintColor = UIColor.white
        tabBar.barTintColor = colorWithHexString(hex: "#00CCFF")
        tabBar.selectedItemTitleFont = UIFont.boldSystemFont(ofSize: getFontSize())
        tabBar.unselectedItemTitleFont = UIFont.boldSystemFont(ofSize: getFontSize())
        tabBar.autoresizingMask = [.flexibleWidth, .flexibleBottomMargin]
        tabBar.sizeToFit()
        
        view.addSubview(tabBar)
    }
    
    func tabBar(_ tabBar: MDCTabBar, didSelect item: UITabBarItem) {
        // do something
        
        print("didSelect")
        if(item == tabBar.items[0]){
            loadClassWorkView()
            swipeTabCount = 0
        }
        if(item == tabBar.items[1]){
            loadHomeWorkView()
            swipeTabCount = 1
        }
        if(item == tabBar.items[2]){
            loadAssignmentView()
            swipeTabCount = 2
        }
        if(item == tabBar.items[3]){
            loadAttendanceView()
            swipeTabCount = 3
        }
    }
    
    @objc func back() { // remove @objc for Swift 3
        
        /*AppLoadingStatus.appLoadingStatus.status = "Redirect"
         
         let vcLandingPage = self.storyboard!.instantiateViewController(withIdentifier: "vcRoot") as! RootViewController
         
         vcLandingPage.statusBarShouldBeHidden = false
         self.setNeedsStatusBarAppearanceUpdate()
         
         let appDelegate = UIApplication.shared.delegate as! AppDelegate
         appDelegate.window?.rootViewController = vcLandingPage*/
        
        self.navigationController?.popToRootViewController(animated: false)
    }
    
    func loadClass()
    {
        self.classIds.removeAll()
        self.classNames.removeAll()
        
        self.activityIndicator.startAnimating()
        let schoolid = getSchoolId()
        let teacherid = getTeacherId()
        if var urlComponents = URLComponents(string: Constants.baseUrl + "ClassV2") {
            urlComponents.query = "schoolid=" + schoolid + "&teacherid=" + teacherid
            // 3
            guard let url = urlComponents.url else { return }
            
            getData(from: url) { data, response, error in
                if error != nil {
                    self.activityIndicator.stopAnimating()
                    print(error!.localizedDescription)
                }
                
                guard let data = data else { return }
                //Implement JSON decoding and parsing
                do {
                    //Decode retrived data with JSONDecoder and assing type of Article object
                    let classData = try JSONDecoder().decode(Result.self, from: data)
                    
                    //Get back to the main queue
                    DispatchQueue.main.async {
                        self.activityIndicator.stopAnimating()
                        self.classsections = classData.ClassList
                        
                        self.response = classData.Response
                        
                        if(self.response?.ResponseVal == 1){
                            for classsection in self.classsections!
                            {
                                self.classIds.append(classsection.id)
                                self.classNames.append("   " + classsection.Classsecname)
                            }
                            
                            // The list of array to display. Can be changed dynamically
                            self.dropDown.optionArray = self.classNames
                            // Its Id Values and its optional
                            self.dropDown.optionIds = self.classIds
                        }
                    }
                    
                } catch let jsonError {
                    self.activityIndicator.stopAnimating()
                    print(jsonError)
                }
            }
        }
        
    }
    
    func calculateTopDistance () -> CGFloat{
        if(self.navigationController != nil && !self.navigationController!.navigationBar.isTranslucent){
            return 0
        }else{
            let barHeight=self.navigationController?.navigationBar.frame.height ?? 0
            let statusBarHeight = UIApplication.shared.isStatusBarHidden ? CGFloat(0) : UIApplication.shared.statusBarFrame.height
            return barHeight + statusBarHeight
        }
    }
    
    func popoverPresentationControllerDidDismissPopover(_ popoverPresentationController: UIPopoverPresentationController) {
        //print("Dismissed")
    }
    
    private func popoverPresentationControllerShouldDismissPopover(_ popoverPresentationController: UIPopoverPresentationController) {
        
        //return true
        
    }
    
    func prepareForPopoverPresentation(_ popoverPresentationController: UIPopoverPresentationController) {
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "seguePopover" {
            
            let popoverViewController = segue.destination
            let popoverPresentationController = popoverViewController.popoverPresentationController
            popoverPresentationController?.delegate = self
            popoverPresentationController?.sourceView = self.view
            popoverPresentationController?.sourceRect = CGRect(x: self.view.frame.width - 210, y: -380, width: 230, height: 380)
            popoverPresentationController?.permittedArrowDirections = [.up]
            
            popoverViewController.popoverPresentationController!.delegate = self
        }
    }
    
    func setAlphaOfBackgroundViews(alpha: CGFloat) {
        let statusBarWindow = UIApplication.shared.value(forKey: "statusBarWindow") as? UIWindow
        UIView.animate(withDuration: 0.2) {
            statusBarWindow?.alpha = alpha
            self.view.alpha = alpha
            self.navigationController?.navigationBar.alpha = alpha
        }
    }
    
    func adaptivePresentationStyle(for controller: UIPresentationController) -> UIModalPresentationStyle {
        // Tells iOS that we do NOT want to adapt the presentation style for iPhone
        return .none
    }
    
    func loadClassWorkView() {
        
        self.removeSubView()
        
        TabsShared.tabsshared.tag = 0
        //Get all views in the xib
        let allViewsInXibArray = Bundle.main.loadNibNamed("ClassWorkView", owner: self, options: nil)
        
        //If you only have one view in the xib and you set it's class to MyView class
        let classworkView = allViewsInXibArray?.first as! ClassWorkView
        
        //Set wanted position and size (frame)
        
        let tabbarHeight = getTabbarHeight()
        let scroolHeight = self.view.frame.size.height - (self.calculateTopDistance() + tabbarHeight + 140)
        
        classworkView.frame = CGRect(x: 0, y: (self.calculateTopDistance() + 48), width: self.view.frame.size.width, height: scroolHeight)
        classworkView.tag = 100
        
        self.tableView = UITableView(frame: CGRect(x: 0, y: 0, width: self.view.frame.size.width, height: scroolHeight), style: UITableView.Style.plain)
        
        self.tableView.register(UINib(nibName: "ClassworkTableViewCell", bundle: nil), forCellReuseIdentifier: "ClassworkCell")
        self.tableView.dataSource = self
        self.tableView.delegate = self
        self.tableView.allowsSelection = true
        self.tableView.rowHeight = 100.0// UITableView.automaticDimension
        self.tableView.estimatedRowHeight = 100.0
        self.tableView.separatorStyle = .none
        
        self.refreshControlCW = UIRefreshControl()
        self.refreshControlCW.addTarget(self, action: #selector(refreshTableCW), for: .valueChanged)
        
        //Setup pull to refresh
        if #available(iOS 10.0, *) {
            self.tableView.refreshControl = refreshControlCW
        } else {
            // Fallback on earlier versions
            self.tableView.addSubview(refreshControlCW)
        }
        
        self.removeSubView()
        classworkView.addSubview(tableView)
        
        let btn = UIButton(type: .custom)
        btn.tag = 5555
        self.setFABAppearence(btn: btn)
        btn.addTarget(self, action:#selector(btnClassworkTap), for:.touchUpInside)
        
        //Add the view
        self.view.addSubview(classworkView)
        self.view.addSubview(btn)
        
        self.activityIndicator.sizeToFit()
        self.activityIndicator.center.x = super.view.center.x
        self.activityIndicator.center.y = (super.view.center.y - 50)
        self.view.addSubview(activityIndicator)
        
    }
    
    @objc func refreshTableCW()
    {
        if let viewWithTag = self.view.viewWithTag(7575) {
            viewWithTag.removeFromSuperview()
        }
        self.getClassworks()
    }
    
    @objc func refreshTableHW()
    {
        if let viewWithTag = self.view.viewWithTag(7575) {
            viewWithTag.removeFromSuperview()
        }
        self.getHomeworks()
    }
    
    @objc func refreshTablePW()
    {
        if let viewWithTag = self.view.viewWithTag(7575) {
            viewWithTag.removeFromSuperview()
        }
        self.getAssignments()
    }
    
    func setFABAppearence (btn:UIButton) {
        
        let tabBarHeight = getTabbarHeight()
        if(tabBarHeight == 83){
            btn.frame = CGRect(x: (getxBound() - 90), y: (getyBound() - 230), width: 80, height: 80)
        }
        else
        {
            btn.frame = CGRect(x: (getxBound() - 90), y: (getyBound() - 205), width: 80, height: 80)
        }
        
        btn.setImage(UIImage(named: "plus"), for: .normal)
        btn.tintColor = UIColor.white
        btn.backgroundColor = UIColor.clear
        btn.backgroundColor = colorWithHexString(hex: "#00FFCC")
        btn.layer.cornerRadius = 40
        btn.layer.borderColor = UIColor.clear.cgColor
        btn.layer.borderWidth = 0.0
        btn.layer.shadowColor = UIColor(red: 0, green: 0, blue: 0, alpha: 0.25).cgColor
        btn.layer.shadowOffset = CGSize(width: 2.0, height: 5.0)
        btn.layer.shadowOpacity = 1.0
        btn.layer.shadowRadius = 5.0
        btn.layer.masksToBounds = false
    }
    
    @objc func btnClassworkTap()
    {
        print("btnClassworkTap")
        
        let vcCW = self.storyboard?.instantiateViewController(withIdentifier: "vcClassWork") as! ClassworkViewController
        vcCW.modalPresentationStyle = .fullScreen
        present(vcCW, animated: false, completion: nil)
    }
    
    @objc func getClassworks()
    {
        // To make the activity indicator appear:
        self.activityIndicator.startAnimating()
        
        let alertView = SCLAlertView(appearance: self.appearance)
        
        let schoolid = getSchoolId()
        let teacherid = getTeacherId()
        
        if var urlComponents = URLComponents(string: Constants.baseUrl + "Classwork") {
            urlComponents.query = "teacherid=" + teacherid + "&schoolid=" + schoolid
            // 3
            guard let url = urlComponents.url else { return }
            //print(url)
            
            getData(from: url) { data, response, error in
                if error != nil {
                    print(error!.localizedDescription)
                    DispatchQueue.main.async {
                        alertView.addButton(self.defaultLocalizer.stringForKey(key: "actionSheetTitleOK")) {
                            alertView.dismiss(animated: true, completion: nil)
                        }
                        alertView.showInfo("OurSchoolZone", subTitle: self.defaultLocalizer.stringForKey(key: "allertMessageFetchdataError"), closeButtonTitle: self.defaultLocalizer.stringForKey(key: "actionSheetTitleOK"))
                    }
                }
                guard let data = data else { return }
                //Implement JSON decoding and parsing
                do {
                    //Decode retrived data with JSONDecoder and assing type of Article object
                    let classworksData = try JSONDecoder().decode(Result.self, from: data)
                    
                    //Get back to the main queue
                    DispatchQueue.main.async {
                        self.refreshControlCW.endRefreshing()
                        
                        self.classworks = classworksData.ClasswList
                        //dump(self.classworks)
                        self.response = classworksData.Response
                        self.activityIndicator.stopAnimating()
                        
                        if(self.response?.ResponseVal == 0)
                        {
                            self.displayAlertMessage()
                        }
                        else{
                            if let viewWithTag = self.view.viewWithTag(7575) {
                                viewWithTag.removeFromSuperview()
                            }
                            self.tableView.reloadData()
                        }
                    }
                    
                } catch let jsonError {
                    self.activityIndicator.stopAnimating()
                    print(jsonError)
                }
            }
        }
    }
    
    func loadHomeWorkView() {
        
        self.removeSubView()
        TabsShared.tabsshared.tag = 1
        
        //Get all views in the xib
        let allViewsInXibArray = Bundle.main.loadNibNamed("HomeWorkView", owner: self, options: nil)
        
        //If you only have one view in the xib and you set it's class to MyView class
        let homeworkView = allViewsInXibArray?.first as! HomeWorkView
        
        //Set wanted position and size (frame)
        let tabbarHeight = getTabbarHeight()
        let scroolHeight = self.view.frame.size.height - (self.calculateTopDistance() + tabbarHeight + 140)
        
        homeworkView.frame = CGRect(x: 0, y: (self.calculateTopDistance() + 48), width: self.view.frame.size.width, height: scroolHeight)
        homeworkView.tag = 101
        
        self.tableView = UITableView(frame: CGRect(x: 0, y: 0, width: self.view.frame.size.width, height: scroolHeight), style: UITableView.Style.plain)
        self.tableView.register(UINib(nibName: "HomeworkTableViewCell", bundle: nil), forCellReuseIdentifier: "HomeworkCell")
        self.tableView.dataSource = self
        self.tableView.delegate = self
        self.tableView.allowsSelection = true
        self.tableView.rowHeight = 120.0// UITableView.automaticDimension
        self.tableView.estimatedRowHeight = 120.0
        self.tableView.separatorStyle = .none
        
        self.refreshControlHW = UIRefreshControl()
        self.refreshControlHW.addTarget(self, action: #selector(refreshTableHW), for: .valueChanged)
        
        //Setup pull to refresh
        if #available(iOS 10.0, *) {
            self.tableView.refreshControl = refreshControlHW
        } else {
            // Fallback on earlier versions
            self.tableView.addSubview(refreshControlHW)
        }
        
        homeworkView.addSubview(tableView)
        
        let btn = UIButton(type: .custom)
        btn.tag = 5555
        self.setFABAppearence(btn: btn)
        btn.addTarget(self, action:#selector(btnHomeworkTap), for:.touchUpInside)
        
        //Add the view
        self.view.addSubview(homeworkView)
        self.view.addSubview(btn)
        
        //self.view.addSubview(scrollView)
        self.activityIndicator.sizeToFit()
        self.activityIndicator.center.x = super.view.center.x
        self.activityIndicator.center.y = (super.view.center.y - 50)
        self.view.addSubview(activityIndicator)
        
    }
    
    @objc func btnHomeworkTap()
    {
        let vcHW = self.storyboard?.instantiateViewController(withIdentifier: "vcHomeWork") as! HomeworkViewController
        vcHW.modalPresentationStyle = .fullScreen
        present(vcHW, animated: false, completion: nil)
    }
    
    @objc func getHomeworks()
    {
        // To make the activity indicator appear:
        self.activityIndicator.startAnimating()
        
        let alertView = SCLAlertView(appearance: self.appearance)
        
        let schoolid = getSchoolId()
        let teacherid = getTeacherId()
        
        if var urlComponents = URLComponents(string: Constants.baseUrl + "Homework") {
            urlComponents.query = "teacherid=" + teacherid + "&schoolid=" + schoolid
            // 3
            guard let url = urlComponents.url else { return }
            
            getData(from: url) { data, response, error in
                if error != nil {
                    
                    DispatchQueue.main.async {
                        alertView.addButton(self.defaultLocalizer.stringForKey(key: "actionSheetTitleOK")) {
                            alertView.dismiss(animated: true, completion: nil)
                        }
                        alertView.showInfo("OurSchoolZone", subTitle: self.defaultLocalizer.stringForKey(key: "allertMessageFetchdataError"), closeButtonTitle: self.defaultLocalizer.stringForKey(key: "actionSheetTitleOK"))
                    }
                    print(error!.localizedDescription)
                }
                guard let data = data else { return }
                //Implement JSON decoding and parsing
                do {
                    //Decode retrived data with JSONDecoder and assing type of Article object
                    let homeworksData = try JSONDecoder().decode(Result.self, from: data)
                    
                    //Get back to the main queue
                    DispatchQueue.main.async {
                        self.refreshControlHW.endRefreshing()
                        
                        self.homeworks = homeworksData.HomeWorkList
                        //dump(self.homeworks)
                        self.response = homeworksData.Response
                        self.activityIndicator.stopAnimating()
                        
                        if(self.response?.ResponseVal == 0)
                        {
                            self.displayAlertMessage()
                        }
                        else{
                            if let viewWithTag = self.view.viewWithTag(7575) {
                                viewWithTag.removeFromSuperview()
                            }
                            self.tableView.reloadData()
                        }
                    }
                    
                } catch let jsonError {
                    self.activityIndicator.stopAnimating()
                    print(jsonError)
                }
            }
        }
    }
    
    func loadAssignmentView() {
        
        self.removeSubView()
        
        TabsShared.tabsshared.tag = 2
        
        //Get all views in the xib
        let allViewsInXibArray = Bundle.main.loadNibNamed("AssignmentView", owner: self, options: nil)
        
        //If you only have one view in the xib and you set it's class to MyView class
        let assignmentView = allViewsInXibArray?.first as! AssignmentView
        
        //Set wanted position and size (frame)
        
        let tabbarHeight = getTabbarHeight()
        let scroolHeight = self.view.frame.size.height - (self.calculateTopDistance() + tabbarHeight + 140)
        
        assignmentView.frame = CGRect(x: 0, y: (self.calculateTopDistance() + 48), width: self.view.frame.size.width, height: scroolHeight)
        assignmentView.tag = 102
        
        self.tableView = UITableView(frame: CGRect(x: 0, y: 0, width: self.view.frame.size.width, height: scroolHeight), style: UITableView.Style.plain)
        self.tableView.register(UINib(nibName: "AssignmentTableViewCell", bundle: nil), forCellReuseIdentifier: "AssignmentCell")
        self.tableView.dataSource = self
        self.tableView.delegate = self
        self.tableView.allowsSelection = true
        self.tableView.rowHeight = 100.0// UITableView.automaticDimension
        self.tableView.estimatedRowHeight = 100.0
        self.tableView.separatorStyle = .none
        
        self.refreshControlPW = UIRefreshControl()
        self.refreshControlPW.addTarget(self, action: #selector(refreshTablePW), for: .valueChanged)
        
        //Setup pull to refresh
        if #available(iOS 10.0, *) {
            self.tableView.refreshControl = refreshControlPW
        } else {
            // Fallback on earlier versions
            self.tableView.addSubview(refreshControlPW)
        }
        
        assignmentView.addSubview(tableView)
        
        let btn = UIButton(type: .custom)
        btn.tag = 5555
        self.setFABAppearence(btn: btn)
        btn.addTarget(self, action:#selector(btnAssignmentTap), for:.touchUpInside)
        
        //Add the view
        self.view.addSubview(assignmentView)
        self.view.addSubview(btn)
        
        //self.view.addSubview(scrollView)
        self.activityIndicator.sizeToFit()
        self.activityIndicator.center.x = super.view.center.x
        self.activityIndicator.center.y = (super.view.center.y - 50)
        self.view.addSubview(activityIndicator)
        
    }
    
    @objc func btnAssignmentTap()
    {
        let vcPW = self.storyboard?.instantiateViewController(withIdentifier: "vcAssignment") as! AssignmentViewController
        vcPW.modalPresentationStyle = .fullScreen
        present(vcPW, animated: false, completion: nil)
    }
    
    @objc func getAssignments()
    {
        // To make the activity indicator appear:
        self.activityIndicator.startAnimating()
        
        let alertView = SCLAlertView(appearance: self.appearance)
        
        let schoolid = getSchoolId()
        let teacherid = getTeacherId()
        
        if var urlComponents = URLComponents(string: Constants.baseUrl + "Assignment") {
            urlComponents.query = "teacherid=" + teacherid + "&schoolid=" + schoolid
            // 3
            guard let url = urlComponents.url else { return }
            
            getData(from: url) { data, response, error in
                if error != nil {
                    
                    DispatchQueue.main.async {
                        alertView.addButton(self.defaultLocalizer.stringForKey(key: "actionSheetTitleOK")) {
                            alertView.dismiss(animated: true, completion: nil)
                        }
                        alertView.showInfo("OurSchoolZone", subTitle: self.defaultLocalizer.stringForKey(key: "allertMessageFetchdataError"), closeButtonTitle: self.defaultLocalizer.stringForKey(key: "actionSheetTitleOK"))
                    }
                    print(error!.localizedDescription)
                }
                guard let data = data else { return }
                //Implement JSON decoding and parsing
                do {
                    //Decode retrived data with JSONDecoder and assing type of Article object
                    let assignmentData = try JSONDecoder().decode(Result.self, from: data)
                    
                    //Get back to the main queue
                    DispatchQueue.main.async {
                        self.refreshControlPW.endRefreshing()
                        
                        self.assignments = assignmentData.Assignments
                        //dump(self.assignments)
                        self.response = assignmentData.Response
                        
                        self.activityIndicator.stopAnimating()
                        
                        if(self.response?.ResponseVal == 0)
                        {
                            self.displayAlertMessage()
                        }
                        else{
                            if let viewWithTag = self.view.viewWithTag(7575) {
                                viewWithTag.removeFromSuperview()
                            }
                            self.tableView.reloadData()
                        }
                    }
                    
                } catch let jsonError {
                    self.activityIndicator.stopAnimating()
                    print(jsonError)
                }
            }
        }
    }
    
    @objc func doneButtonAction() {
        self.view.endEditing(true)
    }
    
    func loadAttendanceView() {
        
        self.removeSubView()
        
        TabsShared.tabsshared.tag = 3
        
        //Get all views in the xib
        let allViewsInXibArray = Bundle.main.loadNibNamed("AttendanceView", owner: self, options: nil)
        
        //If you only have one view in the xib and you set it's class to MyView class
        let attendanceView = allViewsInXibArray?.first as! AttendanceView
        
        //Set wanted position and size (frame)
        var scroolHeight = self.view.frame.size.height - (self.calculateTopDistance() + 48)
        if(UIScreen.main.nativeBounds.height >= 2436){
            scroolHeight = self.view.frame.size.height - (self.calculateTopDistance() + 48 + 89)
        }
        else
        {
            scroolHeight = self.view.frame.size.height - (self.calculateTopDistance() + 48 + 55)
        }
        attendanceView.frame = CGRect(x: 0, y: (self.calculateTopDistance() + 48), width: self.view.frame.size.width, height: scroolHeight)
        attendanceView.tag = 103
        
        //init toolbar
        let toolbar:UIToolbar = UIToolbar(frame: CGRect(x: 0, y: 0,  width: self.view.frame.size.width, height: 30))
        //create left side empty space so that done button set on right side
        let flexSpace = UIBarButtonItem(barButtonSystemItem:    .flexibleSpace, target: nil, action: nil)
        let doneBtn: UIBarButtonItem = UIBarButtonItem(title: self.defaultLocalizer.stringForKey(key: "toolBarButtonTitleDone"), style: .done, target: self, action: #selector(doneButtonAction))
        toolbar.setItems([flexSpace, doneBtn], animated: false)
        toolbar.sizeToFit()
        
        self.dropDown = DropDown(frame: CGRect(x: 10, y: 10, width: (attendanceView.frame.size.width - 20), height: 50))
        self.setDropdown(height: scroolHeight - 137, dropDown: self.dropDown, text: defaultLocalizer.stringForKey(key: "dropDownLabelClass"), classNames: classNames, classIds: classIds)
        
        // The the Closure returns Selected Index and String
        self.dropDown.didSelect{(selectedText , index ,id) in
            self.classid = id
            self.getStudents(classid: id)
        }
        
        let dateContainerView = UIView(frame: CGRect(x: 10, y: 70, width: (attendanceView.frame.size.width - 20), height: 50))
        
        txtAttendanceDate = UITextField(frame: CGRect(x: 0, y: 0, width: (attendanceView.frame.size.width - 20), height: 50))
        txtAttendanceDate.borderStyle = .roundedRect
        txtAttendanceDate.attributedPlaceholder = NSAttributedString(string: self.defaultLocalizer.stringForKey(key: "placeHolderAttendancedate"),
                                                                     attributes: [NSAttributedString.Key.foregroundColor: UIColor.lightGray])
        txtAttendanceDate.delegate = self
        txtAttendanceDate.tag = 5555
        txtAttendanceDate.inputAccessoryView = toolbar
        
        dateContainerView.addSubview(txtAttendanceDate)
        
        let searchBarContainer = UIView(frame: CGRect(x: 0, y: 130, width: self.view.bounds.width, height: 40))
        searchBarContainer.backgroundColor = UIColor.white
        
        self.buttonSelectAll.frame = CGRect(x: ((attendanceView.frame.size.width / 3) * 2), y: 0, width: attendanceView.frame.size.width / 3, height: 40)
        self.setbuttonSelectAllAppearence(buttonSelectAll: self.buttonSelectAll)
        self.buttonSelectAll.addTarget(self, action: #selector(setSwitchOn), for:.touchUpInside)
        self.buttonSelectAll.addTarget(self, action: #selector(setSwitchOn), for:.touchUpOutside)
        searchBarContainer.addSubview(buttonSelectAll)
        
        let tableViewContainer = UIScrollView(frame: CGRect(x: 0, y: 165, width: self.view.frame.size.width, height: scroolHeight - 230))
        self.tableView = UITableView(frame: CGRect(x: 0, y: 0, width: tableViewContainer.frame.size.width, height: tableViewContainer.frame.height), style: UITableView.Style.plain)
        self.tableView.register(UINib(nibName: "AttendanceTableViewCell", bundle: nil), forCellReuseIdentifier: "AttendanceCell")
        self.tableView.dataSource = self
        self.tableView.delegate = self
        self.tableView.allowsSelection = true
        self.tableView.rowHeight = 65.0// UITableView.automaticDimension
        self.tableView.estimatedRowHeight = 65.0
        self.tableView.separatorStyle = .none
        self.tableView.backgroundColor = UIColor.white
        
        self.searchBar = UISearchBar(frame: CGRect(x: 0, y: 0, width: ((attendanceView.frame.size.width / 3) * 2), height: 40))
        self.searchBar.searchBarStyle = UISearchBar.Style.prominent
        //searchBar.layer.borderWidth = 0.5
        //searchBar.layer.borderColor = colorWithHexString(hex: "#DDDDDD").cgColor
        //searchBar.layer.cornerRadius = 25
        self.searchBar.placeholder = self.defaultLocalizer.stringForKey(key: "placeHolderSearchStudent")
        self.searchBar.barTintColor = UIColor.white
        self.searchBar.layer.borderWidth = 1
        self.searchBar.layer.borderColor = UIColor.white.cgColor
        self.searchBar.delegate = self
        self.searchBar.tintColor = UIColor.gray
        //setting toolbar as inputAccessoryView
        self.searchBar.inputAccessoryView = toolbar
        searchBarContainer.addSubview(searchBar)
        
        tableViewContainer.addSubview(tableView)
        
        let buttonSubmit = UIButton(frame: CGRect(x: ((self.view.frame.size.width / 2) + 5), y: scroolHeight - 60, width: ((self.view.frame.size.width / 2) - 15), height: 50))
        self.setSubmitButtonAppearence(buttonSubmit: buttonSubmit, buttonText: self.defaultLocalizer.stringForKey(key: "buttonLabelSubmit"))
        buttonSubmit.addTarget(self, action: #selector(submitAttendance), for:.touchUpInside)
        buttonSubmit.addTarget(self, action: #selector(submitAttendance), for:.touchUpOutside)
        attendanceView.addSubview(buttonSubmit)
        attendanceView.addSubview(tableViewContainer)
        attendanceView.addSubview(searchBarContainer)
        attendanceView.addSubview(dateContainerView)
        attendanceView.addSubview(self.dropDown)
        
        //Add the view
        self.view.addSubview(attendanceView)
        self.searchBar.isHidden = true
        self.buttonSelectAll.isHidden = true
        
        self.activityIndicator.sizeToFit()
        self.activityIndicator.center.x = super.view.center.x
        self.activityIndicator.center.y = (super.view.center.y - 50)
        self.view.addSubview(activityIndicator)
    }
    
    func textFieldDidBeginEditing(_ textField: UITextField) {    //delegate method
        //print(textField.tag)
        if(textField.tag == 5555)
        {
            let datePickerView = UIDatePicker()
            datePickerView.datePickerMode = .date
            textField.inputView = datePickerView
            datePickerView.addTarget(self, action: #selector(handleDatePicker(sender:)), for: .valueChanged)
            
            let todaysDate = Date()
            let dateFormatter = DateFormatter()
            dateFormatter.dateFormat = "dd-MM-yyyy"
            let dateString = dateFormatter.string(from: todaysDate)
            txtAttendanceDate.text = dateString
        }
        
        textField.tintColor = UIColor.gray
    }
    
    @objc func handleDatePicker(sender: UIDatePicker) {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "dd-MM-yyyy"
        txtAttendanceDate.text = dateFormatter.string(from: sender.date)
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        
        //print("TextField did end editing method called\(String(describing: textField.text))")
    }
    
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {
        
        //print("TextField should begin editing method called")
        return true
    }
    
    func textFieldShouldClear(_ textField: UITextField) -> Bool {
        
        //print("TextField should clear method called")
        return true
    }
    
    func textFieldShouldEndEditing(_ textField: UITextField) -> Bool {
        //print("TextField should end editing method called")
        return true
    }
    
    func setDropdown(height: CGFloat, dropDown: DropDown, text: String, classNames: [String], classIds: [Int])
    {
        dropDown.placeholder = text
        //dropDown.font = UIFont.systemFont(ofSize: 14.00)
        dropDown.textColor = UIColor.lightGray
        dropDown.backgroundColor = UIColor.white
        dropDown.rowBackgroundColor = UIColor.white
        dropDown.borderWidth = 0.5
        dropDown.borderColor = colorWithHexString(hex: "#DDDDDD")
        dropDown.cornerRadius = 3
        dropDown.selectedRowColor = colorWithHexString(hex: "#DDDDDD")
        dropDown.arrowSize = 10
        dropDown.isSearchEnable = false
        // The list of array to display. Can be changed dynamically
        dropDown.optionArray = classNames
        // Its Id Values and its optional
        dropDown.optionIds = classIds
        dropDown.rowHeight = CGFloat(50)
        dropDown.listHeight = height
    }
    
    func setbuttonSelectAllAppearence(buttonSelectAll: UIButton){
        self.buttonSelectAllLabel.textColor = colorWithHexString (hex: "#00CCFF")
        self.buttonSelectAllLabel.font = UIFont(name:"Helvetica", size: 14.0)
        self.buttonSelectAllLabel.textAlignment = .right
        self.buttonSelectAllLabel.text = self.defaultLocalizer.stringForKey(key: "buttonLabelClearAll")
        //buttonSelectAll.layer.cornerRadius = 3
        //buttonSelectAll.layer.borderColor = colorWithHexString (hex: "#DDDDDD").cgColor
        //buttonSelectAll.layer.borderWidth = 1.0
        self.buttonSelectAll.addSubview(buttonSelectAllLabel)
    }
    
    @objc func setSwitchOn(sender: UIButton)
    {
        if(SwitchShared.switchshared.isON == false)
        {
            if(self.students != nil)
            {
                self.selectedStudentIds.removeAll()
                for student in self.students!
                {
                    self.selectedStudentIds.append(student.id!)
                }
                self.buttonSelectAllLabel.text = self.defaultLocalizer.stringForKey(key: "buttonLabelClearAll")
                SwitchShared.switchshared.isON = true
            }
        }
        else
        {
            if(self.students != nil)
            {
                self.selectedStudentIds.removeAll()
                self.buttonSelectAllLabel.text = self.defaultLocalizer.stringForKey(key: "buttonLabelSelectAll")
                SwitchShared.switchshared.isON = false
            }
        }
        self.tableView.reloadData()
    }
    
    @objc func btnAttendanceTap()
    {
        let vcAT = self.storyboard?.instantiateViewController(withIdentifier: "vcAttendance") as! AttendanceViewController
        present(vcAT, animated: false, completion: nil)
    }
    
    @objc func getStudents(classid: Int)
    {
        SwitchShared.switchshared.isON = true
        self.searchBar.isHidden = true
        self.buttonSelectAll.isHidden = true
        self.buttonSelectAllLabel.text = self.defaultLocalizer.stringForKey(key: "buttonLabelClearAll")
        // To make the activity indicator appear:
        self.activityIndicator.startAnimating()
        
        let schoolid = getSchoolId()
        
        if var urlComponents = URLComponents(string: Constants.baseUrl + "StudentList") {
            urlComponents.query = "schoolid=" + schoolid + "&classid=" + String(classid) + "&subjectid="
            // 3
            guard let url = urlComponents.url else { return }
            
            getData(from: url) { data, response, error in
                if error != nil {
                    print(error!.localizedDescription)
                }
                guard let data = data else { return }
                //Implement JSON decoding and parsing
                do {
                    //Decode retrived data with JSONDecoder and assing type of Article object
                    let studentData = try JSONDecoder().decode(Result.self, from: data)
                    
                    //Get back to the main queue
                    DispatchQueue.main.async {
                        self.students = studentData.Students
                        //dump(self.classworks)
                        self.response = studentData.Response
                        self.activityIndicator.stopAnimating()
                        
                        self.tableView.reloadData()
                    }
                    
                } catch let jsonError {
                    self.activityIndicator.stopAnimating()
                    print(jsonError)
                }
            }
        }
    }
    
    func searchBarTextDidBeginEditing(_ searchBar: UISearchBar) {
        self.searchActive = true
    }
    
    func searchBarTextDidEndEditing(_ searchBar: UISearchBar) {
        self.searchActive = false
    }
    
    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
        self.searchActive = false
    }
    
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        self.searchActive = false
    }
    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        filtered = students!.filter({
            return $0.StudentName?.range(of: searchText, options: .caseInsensitive) != nil
        })
        
        if(filtered.count == 0){
            self.searchActive = false
        } else {
            self.selectedStudentIds.removeAll()
            for student in self.filtered
            {
                self.selectedStudentIds.append(student.id!)
            }
            self.searchActive = true
        }
        self.tableView.reloadData()
    }
    
    func getxBound()-> CGFloat{
        var xbounds = 0.00
        if #available(iOS 11.0, *) {
            if let window = UIApplication.shared.keyWindow {
                xbounds = Double((view.bounds.width - window.safeAreaInsets.right))
            }
        }
        else
        {
            xbounds = Double(view.bounds.width)
        }
        
        return CGFloat(xbounds)
    }
    
    func getyBound()-> CGFloat{
        
        var xbounds = 0.00
        if #available(iOS 11.0, *) {
            if let window = UIApplication.shared.keyWindow {
                xbounds = Double((view.bounds.height -  window.safeAreaInsets.bottom))
            }
        }
        else
        {
            xbounds = Double(view.bounds.height)
        }
        
        let preferences = UserDefaults.standard
        
        let yboundKey = "yBound"
        if preferences.object(forKey: yboundKey) == nil {
            //  Doesn't exist
            preferences.set(Double(xbounds), forKey: yboundKey)
            
            preferences.synchronize()
        } else {
            xbounds = preferences.double(forKey: yboundKey)
        }
        
        return CGFloat(xbounds)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var cell: AnyObject?
        
        if let tag = TabsShared.tabsshared.tag {
            if(tag == 0){
                
                let cell1 = tableView.dequeueReusableCell(withIdentifier: "ClassworkCell") as! ClassworkTableViewCell
                
                var classwork:Classwork?
                classwork = self.classworks?[indexPath.row]
                
                cell1.labelClass.text = self.defaultLocalizer.stringForKey(key: "labelClass")
                cell1.labelSubject.text = self.defaultLocalizer.stringForKey(key: "labelSubject")
                
                cell1.textClass?.text = classwork?.Class_name
                cell1.textSubject?.text = classwork?.Subject_name
                cell1.textDate?.text = formateDateFromString(dateString: (classwork?.Date)!, withFormat: "dd-MMM-yyyy")
                cell1.textRemarks?.text = classwork?.Remarks
                cell1.buttonClassworkAttachment.tag = (classwork?.id)!
                if(classwork!.Doc_path?.count == 0 && classwork!.Doc_path2?.count == 0 && classwork!.Doc_path3?.count == 0)
                {
                    cell1.buttonClassworkAttachment.isHidden = true
                }
                else
                {
                    cell1.buttonClassworkAttachment.isHidden = false
                    cell1.buttonClassworkAttachment.addTarget(self, action:#selector(self.buttonClassworkAttachmentTap), for:.touchUpInside)
                }
                
                cell1.buttonEditClasswork.tag = indexPath.row
                cell1.buttonEditClasswork.addTarget(self, action:#selector(self.buttonEditClassworkTap), for:.touchUpInside)
                cell = cell1
            }
            if(tag == 1){
                
                let cell2 = tableView.dequeueReusableCell(withIdentifier: "HomeworkCell") as! HomeworkTableViewCell
                
                var homework:Homework?
                homework = self.homeworks?[indexPath.row]
                
                cell2.labelClass.text = self.defaultLocalizer.stringForKey(key: "labelClass")
                cell2.labelSubject.text = self.defaultLocalizer.stringForKey(key: "labelSubject")
                cell2.labelCompletionDate.text = self.defaultLocalizer.stringForKey(key: "labelCompletionDate")
                
                cell2.textClass?.text = homework?.Class_name
                cell2.textSubject?.text = homework?.Subject_name
                cell2.textDate?.text = formateDateFromString(dateString: (homework?.Date)!, withFormat: "dd-MMM-yyyy")
                cell2.textCompletionDate?.text = formateDateFromString(dateString: (homework?.Completion_date)!, withFormat: "dd-MMM-yyyy")
                cell2.textRemarks?.text = homework?.Remarks
                cell2.buttonHomeworkAttachment.tag = (homework?.id)!
                
                if(homework!.Doc_path.count == 0 && homework!.Doc_path2.count == 0 && homework!.Doc_path3.count == 0)
                {
                    cell2.buttonHomeworkAttachment.isHidden = true
                }
                else
                {
                    cell2.buttonHomeworkAttachment.isHidden = false
                    cell2.buttonHomeworkAttachment.addTarget(self, action:#selector(self.buttonHomeworkAttachmentTap), for:.touchUpInside)
                }
                
                cell2.buttonEditHomework.tag = indexPath.row
                cell2.buttonEditHomework.addTarget(self, action:#selector(self.buttonEditHomeworkTap), for:.touchUpInside)
                
                cell = cell2
            }
            if(tag == 2){
                
                let cell3 = tableView.dequeueReusableCell(withIdentifier: "AssignmentCell") as! AssignmentTableViewCell
                
                var assignment:Assignment?
                assignment = self.assignments?[indexPath.row]
                
                cell3.labelClass.text = self.defaultLocalizer.stringForKey(key: "labelClass")
                cell3.labelSubject.text = self.defaultLocalizer.stringForKey(key: "labelSubject")
                
                cell3.textClass?.text = assignment?.Class_name
                cell3.textSubject?.text = assignment?.Subject_name
                cell3.textDate?.text = formateDateFromString(dateString: (assignment?.Date)!, withFormat: "dd-MMM-yyyy")
                cell3.textRemarks?.text = assignment?.Description
                cell3.buttonAssignmentAttachment.tag = (assignment?.id)!
                
                if(assignment!.Doc_path.count == 0 && assignment!.Doc_path2.count == 0 && assignment!.Doc_path3.count == 0)
                {
                    cell3.buttonAssignmentAttachment.isHidden = true
                }
                else
                {
                    cell3.buttonAssignmentAttachment.isHidden = false
                    cell3.buttonAssignmentAttachment.addTarget(self, action:#selector(self.buttonAssignmentAttachmentTap), for:.touchUpInside)
                }
                
                cell3.buttonEditAssignment.tag = indexPath.row
                cell3.buttonEditAssignment.addTarget(self, action:#selector(self.buttonEditAssignmentTap), for:.touchUpInside)
                
                cell = cell3
            }
            if(tag == 3){
                
                let cell4 = tableView.dequeueReusableCell(withIdentifier: "AttendanceCell") as! AttendanceTableViewCell
                
                var student:Student?
                
                if(self.searchActive == true && self.filtered.count > 0){
                    student = self.filtered[indexPath.row]
                } else {
                    student = self.students?[indexPath.row]
                }
                
                cell4.textStudentName?.text = student!.StudentName
                cell4.textStudentName?.adjustsFontSizeToFitWidth = true
                cell4.textStudentName?.numberOfLines = 2
                
                if let url = URL(string: (student?.ProfileImage)!) {
                    getImageData(from: url) { data, response, error in
                        guard let data = data, error == nil else { return }
                        DispatchQueue.main.async() {
                            cell4.profileImageView.image = UIImage(data: data)
                        }
                    }
                }
                cell4.switchStudent.tag = (student?.id)!
                cell4.switchStudent.addTarget(self, action: #selector(self.onswitchStudentValueChanged), for: UISwitch.Event.valueChanged)
                
                if let switchState = SwitchShared.switchshared.isON {
                    if(switchState == true){
                        cell4.switchStudent.setOn(true, animated: true)
                        self.selectedStudentIds.append((student?.id)!)
                    }
                    else
                    {
                        cell4.switchStudent.setOn(false, animated: true)
                        self.selectedStudentIds.removeAll()
                    }
                }
                let studentcount = self.students?.count ?? 0
                if(studentcount > 0){
                    self.searchBar.isHidden = false
                    self.buttonSelectAll.isHidden = false
                }
                
                cell = cell4
            }
        }
        
        return cell as! UITableViewCell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        //print(indexPath.row)
        if let tag = TabsShared.tabsshared.tag {
            if(tag == 0){
                let vc = self.storyboard?.instantiateViewController(withIdentifier: "vcCWDetails") as! ClassworkDetailsViewController
                vc.modalPresentationStyle = .fullScreen
                var classwork:Classwork?
                classwork = classworks?[indexPath.row]
                //print(classwork?.Subject_name)
                
                vc.className = classwork!.Class_name
                vc.subjectName = classwork!.Subject_name
                vc.date = formateDateFromString(dateString: (classwork!.Date), withFormat: "dd-MMM-yyyy")
                vc.bookName = classwork!.Book
                vc.chapterName = classwork!.Chapter_Name
                vc.chapterIndex = classwork!.Chapter_index
                vc.remarks = classwork!.Remarks
                vc.Doc_path = classwork!.Doc_path
                vc.Doc_path2 = classwork!.Doc_path2
                vc.Doc_path3 = classwork!.Doc_path3
                
               self.navigationController?.pushViewController(vc, animated: false)
            }
            if(tag == 1){
                let vc = self.storyboard?.instantiateViewController(withIdentifier: "vcHWDetails") as! HomeworkDetailsViewController
                vc.modalPresentationStyle = .fullScreen
                var homework:Homework?
                homework = homeworks?[indexPath.row]
                
                vc.className = homework!.Class_name
                vc.subjectName = homework!.Subject_name
                vc.date = formateDateFromString(dateString: (homework!.Date), withFormat: "dd-MMM-yyyy")
                vc.bookName = homework!.Book
                vc.chapterName = homework!.Chapter_Name
                vc.chapterIndex = homework!.Chapter_index
                vc.completionDate = formateDateFromString(dateString: (homework!.Completion_date), withFormat: "dd-MMM-yyyy")
                vc.remarks = homework!.Remarks
                vc.Doc_path = homework!.Doc_path
                vc.Doc_path2 = homework!.Doc_path2
                vc.Doc_path3 = homework!.Doc_path3
                
                self.navigationController?.pushViewController(vc, animated: false)
            }
            if(tag == 2){
                let vc = self.storyboard?.instantiateViewController(withIdentifier: "vcPWDetails") as! AssignmentDetailsViewController
                vc.modalPresentationStyle = .fullScreen
                var assignment:Assignment?
                assignment = assignments?[indexPath.row]
                
                vc.className = assignment!.Class_name
                vc.subjectName = assignment!.Subject_name
                vc.date = formateDateFromString(dateString: (assignment!.Date), withFormat: "dd-MMM-yyyy")
                vc.remarks = assignment!.Description
                vc.Doc_path = assignment!.Doc_path
                vc.Doc_path2 = assignment!.Doc_path2
                vc.Doc_path3 = assignment!.Doc_path3
                
                self.navigationController?.pushViewController(vc, animated: false)
            }
        }
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        var count = 0
        if let tag = TabsShared.tabsshared.tag {
            if(tag == 0){
                count = classworks?.count ?? 0
            }
            if(tag == 1){
                count = homeworks?.count ?? 0
            }
            if(tag == 2){
                count = assignments?.count ?? 0
            }
            if(tag == 3){
                if(searchActive) {
                    return filtered.count
                }
                count = students?.count ?? 0
            }
        }
        
        return count
    }
    
    /*func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
     if self.footerView != nil {
     return self.footerView!.bounds.height
     }
     return FOOTERHEIGHT
     }
     
     func tableView(_ tableView: UITableView, viewForFooterInSection section: Int) -> UIView? {
     self.footerView = UIView(frame: CGRect(x: 0, y: 20, width: tableView.bounds.width, height: FOOTERHEIGHT))
     self.footerView?.backgroundColor = UIColor.clear
     
     let buttonSubmit = UIButton(type: .custom)
     self.setSubmitButtonAppearence(buttonSubmit: buttonSubmit, buttonText: self.defaultLocalizer.stringForKey(key: "buttonLabelSubmit"))
     buttonSubmit.addTarget(self, action: #selector(submitAttendance), for:.touchUpInside)
     buttonSubmit.addTarget(self, action: #selector(submitAttendance), for:.touchUpOutside)
     
     let selectedStudent = students?.count ?? 0
     if let tag = TabsShared.tabsshared.tag {
     if(tag == 3 && selectedStudent > 0){
     footerView?.addSubview(buttonSubmit)
     }
     }
     
     return footerView
     }*/
    
    func setSubmitButtonAppearence(buttonSubmit: UIButton, buttonText: String){
        
        let buttonimageView = UIImageView(frame: CGRect(x: 5, y: 10, width: 30, height: 30))
        buttonimageView.image = UIImage(named: "plus")
        let buttonLabel = UILabel(frame: CGRect(x: 40, y: 0, width: buttonSubmit.frame.width - 40, height: 50))
        buttonLabel.textColor = UIColor.white
        buttonLabel.font = UIFont(name:"HelveticaNeue-Bold", size: 16.0)
        buttonLabel.textAlignment = .left
        buttonLabel.text = buttonText
        //buttonSubmit.frame = CGRect(x: (tableView.bounds.width - 129), y: 5, width: 120, height: 50)
        buttonSubmit.addSubview(buttonimageView)
        buttonSubmit.addSubview(buttonLabel)
        buttonSubmit.tintColor = UIColor.white
        buttonSubmit.backgroundColor = colorWithHexString(hex: "#00FFCC")
        buttonSubmit.layer.shadowColor = UIColor(red: 0, green: 0, blue: 0, alpha: 0.25).cgColor
        buttonSubmit.layer.shadowOffset = CGSize(width: 1.0, height: 5.0)
        buttonSubmit.layer.shadowOpacity = 1.0
        buttonSubmit.layer.shadowRadius = 5.0
        buttonSubmit.layer.masksToBounds = false
        buttonSubmit.layer.cornerRadius = 3.0
    }
    
    @objc func submitAttendance()
    {
        let alertView = SCLAlertView(appearance: self.appearance)
        
        let selectedStudentCount = self.selectedStudentIds.count
        if(selectedStudentCount == 0)
        {
            alertView.addButton(self.defaultLocalizer.stringForKey(key: "actionSheetTitleOK")) {
                alertView.dismiss(animated: true, completion: nil)
            }
            
            alertView.showInfo("OurSchoolZone", subTitle: self.defaultLocalizer.stringForKey(key: "allertMessageSelectStudent"), closeButtonTitle: self.defaultLocalizer.stringForKey(key: "actionSheetTitleOK"))
            return
        }
        
        /*let currentDate = Date()
        let formatter = DateFormatter()
        formatter.dateFormat = "dd-MM-yyyy"*/
        
        // Create date formatter
        let dateFormatter: DateFormatter = DateFormatter()
        // Set date format
        dateFormatter.dateFormat = "dd-MM-yyyy"
        dateFormatter.timeZone = NSTimeZone.local
        let attendanceDate = dateFormatter.date(from: txtAttendanceDate.text!)
        
        if(attendanceDate! > Date()){
            alertView.addButton(self.defaultLocalizer.stringForKey(key: "actionSheetTitleOK")) {
                alertView.dismiss(animated: true, completion: nil)
            }
            alertView.showInfo("OurSchoolZone", subTitle: self.defaultLocalizer.stringForKey(key: "allertMessageFutureDateCanotBeSelected"), closeButtonTitle: self.defaultLocalizer.stringForKey(key: "actionSheetTitleOK"))
            return
        }
        
        let schoolid = getSchoolId()
        let teacherid = getTeacherId()
        var studentQueryString = String()
        var queryString = "schoolid=" + "\(schoolid)" + "&teacherid=" + "\(teacherid)" + "&classid=" + "\(classid)&"
        for selectedId in self.selectedStudentIds
        {
            studentQueryString += "studentid=\(selectedId)&"
        }
        queryString += studentQueryString
        queryString += "subjectid=" + "&date=" + txtAttendanceDate.text!
        
        if var urlComponents = URLComponents(string: Constants.baseUrl + "AddStudentAttendance") {
            urlComponents.query = queryString
            // 3
            guard let url = urlComponents.url else { return}
            
            var request = URLRequest(url: url)
            request.httpMethod = "POST"
            
            postData(from: request) { data, response, error in
                if let httpStatus = response as? HTTPURLResponse, httpStatus.statusCode != 200 {
                    //let responseMessage = String(describing: response)
                    
                    alertView.addButton(self.defaultLocalizer.stringForKey(key: "actionSheetTitleOK")) {
                        alertView.dismiss(animated: true, completion: nil)
                    }
                    
                    alertView.showError("OurSchoolZone", subTitle: self.defaultLocalizer.stringForKey(key: "allertMessageAttendanceSubmitError"), closeButtonTitle: self.defaultLocalizer.stringForKey(key: "actionSheetTitleOK"))
                }else{
                    self.selectedStudentIds.removeAll()
                    self.buttonSelectAllLabel.text = self.defaultLocalizer.stringForKey(key: "buttonLabelClearAll")
                    SwitchShared.switchshared.isON = true
                    self.buttonSelectAll.sendActions(for: .touchUpInside)
                    self.buttonSelectAll.sendActions(for: .touchUpOutside)
                    
                    alertView.addButton(self.defaultLocalizer.stringForKey(key: "actionSheetTitleOK")) {
                        alertView.dismiss(animated: true, completion: nil)
                    }
                    alertView.showSuccess("OurSchoolZone", subTitle: self.defaultLocalizer.stringForKey(key: "allertMessageAttendanceSubmitSuccess"), closeButtonTitle: self.defaultLocalizer.stringForKey(key: "actionSheetTitleOK"))
                }
                /*guard let data = data else { return }
                
                do {
                    //Decode retrived data with JSONDecoder and assing type of Article object
                    let attendanceData = try JSONDecoder().decode(Result.self, from: data)
                    
                    //Get back to the main queue
                    DispatchQueue.main.async {
                        self.response = attendanceData.Response
                        
                        if(self.response?.ResponseVal == 1){
                            self.selectedStudentIds.removeAll()
                            self.buttonSelectAllLabel.text = self.defaultLocalizer.stringForKey(key: "buttonLabelClearAll")
                            SwitchShared.switchshared.isON = true
                            self.buttonSelectAll.sendActions(for: .touchUpInside)
                            self.buttonSelectAll.sendActions(for: .touchUpOutside)
                            
                            alertView.addButton(self.defaultLocalizer.stringForKey(key: "actionSheetTitleOK")) {
                                alertView.dismiss(animated: true, completion: nil)
                            }
                            alertView.showSuccess("OurSchoolZone", subTitle: self.defaultLocalizer.stringForKey(key: "allertMessageAttendanceSubmitSuccess"), closeButtonTitle: self.defaultLocalizer.stringForKey(key: "actionSheetTitleOK"))
                        }
                        else
                        {
                            alertView.addButton(self.defaultLocalizer.stringForKey(key: "actionSheetTitleOK")) {
                                alertView.dismiss(animated: true, completion: nil)
                            }
                            
                            alertView.showError("OurSchoolZone", subTitle: self.defaultLocalizer.stringForKey(key: "allertMessageAttendanceSubmitError"), closeButtonTitle: self.defaultLocalizer.stringForKey(key: "actionSheetTitleOK"))
                        }
                    }
                    
                } catch {
                    //let responseMessage = String(describing: jsonError)
                    alertView.addButton(self.defaultLocalizer.stringForKey(key: "actionSheetTitleOK")) {
                        alertView.dismiss(animated: true, completion: nil)
                    }
                    alertView.showError("OurSchoolZone", subTitle: self.defaultLocalizer.stringForKey(key: "allertMessageAttendanceSubmitError"), closeButtonTitle: self.defaultLocalizer.stringForKey(key: "actionSheetTitleOK"))
                }*/
            }
        }
    }
    
    @objc func onswitchStudentValueChanged(sender: UISwitch){
        let actualStudentCount = students?.count ?? 0
        
        if(sender.isOn){
            selectedStudentIds.append(sender.tag)
        }else{
            let temp = selectedStudentIds.filter {$0 != sender.tag}
            selectedStudentIds = temp
        }
        
        let selectedStudentCount = selectedStudentIds.count
        
        if(selectedStudentCount == 0)
        {
            self.buttonSelectAllLabel.text = self.defaultLocalizer.stringForKey(key: "buttonLabelSelectAll")
        }
        if(selectedStudentCount == actualStudentCount)
        {
            self.buttonSelectAllLabel.text = self.defaultLocalizer.stringForKey(key: "buttonLabelClearAll")
        }
    }
    
    @objc func buttonEditClassworkTap(sender: UIButton)
    {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "vcEditClasswork") as! EditClassworkViewController
        vc.modalPresentationStyle = .fullScreen
        var classwork:Classwork?
        classwork = classworks?[sender.tag]
        
        vc.classworkId = classwork!.id
        vc.className = classwork!.Class_name
        vc.subjectName = classwork!.Subject_name
        vc.date = formateDateFromString(dateString: (classwork!.Date), withFormat: "dd-MMM-yyyy")
        vc.bookName = classwork!.Book
        vc.chapterName = classwork!.Chapter_Name
        vc.chapterIndex = classwork!.Chapter_index
        vc.remarks = classwork!.Remarks
        vc.Doc_path = classwork!.Doc_path
        vc.Doc_path2 = classwork!.Doc_path2
        vc.Doc_path3 = classwork!.Doc_path3
        
        self.present(vc, animated: false, completion: nil)
        CFRunLoopWakeUp(CFRunLoopGetCurrent())
    }
    
    @objc func buttonEditHomeworkTap(sender: UIButton)
    {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "vcEditHomework") as! EditHomeworkViewController
        vc.modalPresentationStyle = .fullScreen
        var homework:Homework?
        homework = homeworks?[sender.tag]
        
        vc.homeworkId = homework!.id
        vc.className = homework!.Class_name
        vc.subjectName = homework!.Subject_name
        vc.completiondate = formateDateFromString(dateString: (homework!.Completion_date), withFormat: "dd-MM-yyyy")
        vc.bookName = homework!.Book
        vc.chapterName = homework!.Chapter_Name
        vc.chapterIndex = homework!.Chapter_index
        vc.remarks = homework!.Remarks
        vc.Doc_path = homework!.Doc_path
        vc.Doc_path2 = homework!.Doc_path2
        vc.Doc_path3 = homework!.Doc_path3
        
        self.present(vc, animated: false, completion: nil)
    }
    
    @objc func buttonEditAssignmentTap(sender: UIButton)
    {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "vcEditAssignment") as! EditAssignmentViewController
        vc.modalPresentationStyle = .fullScreen
        var assignment:Assignment?
        assignment = assignments?[sender.tag]
        
        vc.assignmentId = assignment!.id
        vc.className = assignment!.Class_name
        vc.subjectName = assignment!.Subject_name
        vc.remarks = assignment!.Description
        vc.Doc_path = assignment!.Doc_path
        vc.Doc_path2 = assignment!.Doc_path2
        vc.Doc_path3 = assignment!.Doc_path3
        
        self.present(vc, animated: false, completion: nil)
        CFRunLoopWakeUp(CFRunLoopGetCurrent())
    }
    
    @objc func buttonClassworkAttachmentTap(sender: UIButton)
    {
        let filtered = classworks!.filter({
            return $0.id == sender.tag
        })
        
        var images = [LightboxImage(imageURL: URL(string: filtered[0].Doc_path!)!)]
        
        if(filtered[0].Doc_path2!.count > 0)
        {
            images.append(LightboxImage(imageURL: URL(string: filtered[0].Doc_path2!)!))
        }
        
        if(filtered[0].Doc_path3!.count > 0)
        {
            images.append(LightboxImage(imageURL: URL(string: filtered[0].Doc_path3!)!))
        }
        
        // Create an instance of LightboxController.
        let controller = LightboxController(images: images)
        
        // Set delegates.
        controller.pageDelegate = self
        controller.dismissalDelegate = self
        
        // Use dynamic background.
        controller.dynamicBackground = true
        controller.modalPresentationStyle = .fullScreen
        // Present your controller.
        present(controller, animated: false, completion: nil)
    }
    
    @objc func buttonHomeworkAttachmentTap(sender: UIButton)
    {
        let filtered = homeworks!.filter({
            return $0.id == sender.tag
        })
        
        var images = [LightboxImage(imageURL: URL(string: filtered[0].Doc_path)!)]
        
        if(filtered[0].Doc_path2.count > 0)
        {
            images.append(LightboxImage(imageURL: URL(string: filtered[0].Doc_path2)!))
        }
        
        if(filtered[0].Doc_path3.count > 0)
        {
            images.append(LightboxImage(imageURL: URL(string: filtered[0].Doc_path3)!))
        }
        
        // Create an instance of LightboxController.
        let controller = LightboxController(images: images)
        
        // Set delegates.
        controller.pageDelegate = self
        controller.dismissalDelegate = self
        
        // Use dynamic background.
        controller.dynamicBackground = true
        controller.modalPresentationStyle = .fullScreen
        // Present your controller.
        present(controller, animated: false, completion: nil)
    }
    
    @objc func buttonAssignmentAttachmentTap(sender: UIButton)
    {
        let filtered = assignments!.filter({
            return $0.id == sender.tag
        })
        
        var images = [LightboxImage(imageURL: URL(string: filtered[0].Doc_path)!)]
        
        if(filtered[0].Doc_path2.count > 0)
        {
            images.append(LightboxImage(imageURL: URL(string: filtered[0].Doc_path2)!))
        }
        
        if(filtered[0].Doc_path3.count > 0)
        {
            images.append(LightboxImage(imageURL: URL(string: filtered[0].Doc_path3)!))
        }
        
        // Create an instance of LightboxController.
        let controller = LightboxController(images: images)
        
        // Set delegates.
        controller.pageDelegate = self
        controller.dismissalDelegate = self
        
        // Use dynamic background.
        controller.dynamicBackground = true
        controller.modalPresentationStyle = .fullScreen
        // Present your controller.
        present(controller, animated: false, completion: nil)
    }
    
    func lightboxControllerWillDismiss(_ controller: LightboxController) {
        
    }
    
    func lightboxController(_ controller: LightboxController, didMoveToPage page: Int) {
        
    }
    
    func removeSubView()
    {
        
        if let viewWithTag = self.view.viewWithTag(100) {
            viewWithTag.removeFromSuperview()
        }
        
        if let viewWithTag = self.view.viewWithTag(101) {
            viewWithTag.removeFromSuperview()
        }
        
        if let viewWithTag = self.view.viewWithTag(102) {
            viewWithTag.removeFromSuperview()
        }
        
        if let viewWithTag = self.view.viewWithTag(103) {
            viewWithTag.removeFromSuperview()
        }
        if let viewWithTag = self.view.viewWithTag(7575) {
            viewWithTag.removeFromSuperview()
        }
        if let viewWithTag = self.view.viewWithTag(5555) {
            viewWithTag.removeFromSuperview()
        }
    }
    
    func displayAlertMessage()
    {
        let imageview = UIImageView(frame: CGRect(x: ((self.view.frame.size.width / 2) - 50), y: ((self.view.frame.size.height / 2) - 74), width: 100, height: 100))
        imageview.image = UIImage(named: "norecordfound")
        imageview.contentMode = UIView.ContentMode.scaleAspectFit
        imageview.layer.masksToBounds = true
        imageview.tag = 7575
        self.view.addSubview(imageview)
    }
}
