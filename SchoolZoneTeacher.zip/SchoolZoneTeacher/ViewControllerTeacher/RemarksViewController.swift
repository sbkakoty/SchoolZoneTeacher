//
//  RemarksViewController.swift
//  SchoolZoneTeacher
//
//  Created by Apple on 16/12/18.
//  Copyright © 2018 ClearWin Technologies. All rights reserved.
//

import UIKit
import MaterialComponents
import iOSDropDown
import SCLAlertView

class RemarksViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    var popoverVC: UIViewController!
    
    let defaultLocalizer = AMPLocalizeUtils.defaultLocalizer
    let activityIndicator = MDCActivityIndicator()
    var result:Result?
    var remarks:[Remark]?
    var response:Response?
    
    var addRemarksVC: UIViewController!
    var tableView = UITableView()
    var refreshControl = UIRefreshControl()
    
    let appearance = SCLAlertView.SCLAppearance(
        kTitleFont: UIFont(name: "HelveticaNeue", size: 20)!,
        kTextFont: UIFont(name: "HelveticaNeue", size: 14)!,
        kButtonFont: UIFont(name: "HelveticaNeue-Bold", size: 14)!
    )
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        self.getRemarks()
    }

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        if(getLanguage().count > 0)
        {
            defaultLocalizer.setSelectedLanguage(lang: getLanguage())
        }
        else
        {
            defaultLocalizer.setSelectedLanguage(lang: "en")
        }
        if(popoverVC != nil)
        {
            popoverVC.dismiss(animated: false, completion: nil)
        }
        if(addRemarksVC != nil)
        {
            addRemarksVC.dismiss(animated: false, completion: nil)
        }
        
        self.setNavigationBar()
        self.loadRemarkView()
    }
    
    func setNavigationBar() {
        let navigationFont = UIFont(name: "Helvetica", size: getTitleFontSize())
        /*let screenSize: CGRect = UIScreen.main.bounds;
        let statusBarHeight = UIApplication.shared.isStatusBarHidden ? CGFloat(0) : UIApplication.shared.statusBarFrame.height
        let navBar: UINavigationBar = UINavigationBar(frame: CGRect(x: 0, y: statusBarHeight, width: screenSize.width, height: 44))
        self.view.addSubview(navBar);
        
        let navItem = UINavigationItem(title: self.defaultLocalizer.stringForKey(key: "navBarTitleRemarks"));
        let button = UIButton.init(type: .custom)
        button.setTitle(self.defaultLocalizer.stringForKey(key: "navBarButtonBack"), for: UIControl.State.normal)
        var image = UIImage.init(named: "back");
        let templateImage = image?.withRenderingMode(UIImage.RenderingMode.alwaysTemplate)
        image = templateImage
        button.setImage(image, for: UIControl.State.normal)
        button.addTarget(self, action:#selector(back), for:.touchUpInside)
        button.addTarget(self, action:#selector(back), for:.touchUpOutside)
        button.frame = CGRect.init(x: 0, y: 0, width: 60, height: 44) //CGRectMake(0, 0, 30, 30)
        let doneItem = UIBarButtonItem.init(customView: button)
        
        //let doneItem = UIBarButtonItem(title: self.defaultLocalizer.stringForKey(key: "navBarButtonBack"), style: .plain, target: self, action: #selector(back))
        navItem.leftBarButtonItem = doneItem;
        
        navBar.setItems([navItem], animated: false);
        navBar.backgroundColor = colorWithHexString(hex: "#00CCFF");
        navBar.isTranslucent = false;
        navBar.titleTextAttributes = [
            NSAttributedString.Key.foregroundColor : UIColor.white, NSAttributedString.Key.font: navigationFont!, NSAttributedString.Key.shadow: setNavBarTitleShadow()
        ]
        
        if #available(iOS 11, *){
            navBar.titleTextAttributes = [NSAttributedString.Key.foregroundColor: UIColor.white, NSAttributedString.Key.font: navigationFont!, NSAttributedString.Key.shadow: setNavBarTitleShadow()]
        }*/
        
        let button = UIButton.init(type: .custom)
        button.setTitle(self.defaultLocalizer.stringForKey(key: "navBarButtonBack"), for: UIControl.State.normal)
        var image = UIImage.init(named: "back")
        let templateImage = image?.withRenderingMode(UIImage.RenderingMode.alwaysTemplate)
        image = templateImage
        button.setImage(image, for: UIControl.State.normal)
        button.addTarget(self, action:#selector(back), for:.touchUpInside)
        button.addTarget(self, action:#selector(back), for:.touchUpOutside)
        button.frame = CGRect.init(x: 0, y: 0, width: 20, height: 20) //CGRectMake(0, 0, 30, 30)
        let doneItem = UIBarButtonItem.init(customView: button)
        self.navigationItem.leftBarButtonItem = doneItem
        
        let width = self.view.frame.width - 60
        let height = CGFloat(44)
        
        let titleLabel = UILabel(frame: CGRect.init(x: 0, y: 0, width: width, height: height))
        titleLabel.text = self.defaultLocalizer.stringForKey(key: "navBarTitleRemarks")
        titleLabel.textAlignment = .center
        titleLabel.font = navigationFont
        titleLabel.textColor = .white
        titleLabel.sizeToFit()
        self.navigationItem.titleView = titleLabel
    }
    
    @objc func back() {
        self.navigationController?.popViewController(animated: false)
    }
    
    func position(for bar: UIBarPositioning) -> UIBarPosition {
        return .topAttached
    }
    
    func calculateTopDistance () -> CGFloat{
        let statusBarHeight = UIApplication.shared.isStatusBarHidden ? CGFloat(0) : UIApplication.shared.statusBarFrame.height
        return statusBarHeight + 45
    }
    
    func loadRemarkView() {
        //Set wanted position and size (frame)
        let tabbarHeight = getTabbarHeight()
        let scroolHeight = self.view.frame.size.height - (self.calculateTopDistance() + tabbarHeight)
        
        let remarkView = UIView(frame: CGRect(x: 0, y: 0, width: self.view.frame.size.width, height: scroolHeight))
        remarkView.tag = 100
        
        self.tableView = UITableView(frame: CGRect(x: 0, y: 0, width: self.view.frame.size.width, height: scroolHeight), style: UITableView.Style.plain)
        self.tableView.dataSource = self
        self.tableView.delegate = self
        self.tableView.register(UINib(nibName: "RemarksTableViewCell", bundle: nil), forCellReuseIdentifier: "RemarksCell")
        self.tableView.rowHeight = 100.0// UITableView.automaticDimension
        self.tableView.estimatedRowHeight = 100.0
        self.tableView.separatorStyle = .none
        
        self.refreshControl.addTarget(self, action: #selector(refreshTable), for: .valueChanged)
        
        //Setup pull to refresh
        if #available(iOS 10.0, *) {
            self.tableView.refreshControl = refreshControl
        } else {
            // Fallback on earlier versions
            self.tableView.addSubview(refreshControl)
        }
        
        self.removeSubView()
        remarkView.addSubview(tableView)
        
        let btn = UIButton(type: .custom)
        self.setFABAppearence(btn: btn)
        btn.addTarget(self, action:#selector(btnAnnouncementTap), for:.touchUpInside)
        
        remarkView.addSubview(btn)
        
        //Add the view
        self.view.addSubview(remarkView)
        
        //self.view.addSubview(scrollView)
        self.activityIndicator.sizeToFit()
        self.activityIndicator.center.x = super.view.center.x
        self.activityIndicator.center.y = (super.view.center.y - 50)
        self.view.addSubview(activityIndicator)
    }
    
    @objc func btnAnnouncementTap()
    {
        let vcAddRemark = self.storyboard?.instantiateViewController(withIdentifier: "vcAddRemark") as! AddRemarkViewController;()
        vcAddRemark.RemarksVC = self
        present(vcAddRemark, animated: false, completion: nil)
    }
    
    @objc func getRemarks()
    {
        // To make the activity indicator appear:
        self.activityIndicator.startAnimating()
        
        if let viewWithTag = self.view.viewWithTag(7575) {
            viewWithTag.removeFromSuperview()
        }
        
        let alertView = SCLAlertView(appearance: self.appearance)
        
        let schoolid = getSchoolId()
        let teacherid = getTeacherId()
        
        if var urlComponents = URLComponents(string: Constants.baseUrl + "GetRemarksTeacher") {
            urlComponents.query = "schoolid=" + schoolid + "&teacherid=" + teacherid
            // 3
            guard let url = urlComponents.url else { return }
            
            //print("getRemarks: \(url)")
            
            getData(from: url) { data, response, error in
                if error != nil {
                    DispatchQueue.main.async {
                        alertView.showInfo("OurSchoolZone", subTitle: self.defaultLocalizer.stringForKey(key: "allertMessageFetchdataError"), closeButtonTitle: self.defaultLocalizer.stringForKey(key: "actionSheetTitleOK"))
                    }
                    print(error!.localizedDescription)
                }
                guard let data = data else { return }
                //Implement JSON decoding and parsing
                do {
                    //Decode retrived data with JSONDecoder and assing type of Article object
                    let remarkData = try JSONDecoder().decode(Result.self, from: data)
                    
                    //Get back to the main queue
                    DispatchQueue.main.async {
                        self.refreshControl.endRefreshing()
                        
                        self.remarks = remarkData.Remarks
                        dump(self.remarks)
                        //setRemarks(Remarks: self.remarks!)
                        
                        self.response = remarkData.Response
                        
                        self.activityIndicator.stopAnimating()
                        
                        if(self.response?.ResponseVal == 0)
                        {
                            self.displayAlertMessage()
                        }
                        else{
                            if let viewWithTag = self.view.viewWithTag(7575) {
                                viewWithTag.removeFromSuperview()
                            }
                            self.tableView.reloadData()
                        }
                    }
                    
                } catch let jsonError {
                    self.activityIndicator.stopAnimating()
                    print(jsonError)
                }
            }
        }
    }
    
    @objc func refreshTable()
    {
        if let viewWithTag = self.view.viewWithTag(7575) {
            viewWithTag.removeFromSuperview()
        }
        self.getRemarks()
    }
    
    func setFABAppearence (btn:UIButton) {
        
        let tabBarHeight = getTabbarHeight()
        if(tabBarHeight == 83){
            btn.frame = CGRect(x: (getxBound() - 90), y: (getyBound() - 230), width: 80, height: 80)
        }
        else
        {
            btn.frame = CGRect(x: (getxBound() - 90), y: (getyBound() - 205), width: 80, height: 80)
        }
        
        btn.setImage(UIImage(named: "plus"), for: .normal)
        btn.tintColor = UIColor.white
        btn.backgroundColor = UIColor.clear
        btn.backgroundColor = colorWithHexString(hex: "#00FFCC")
        btn.layer.cornerRadius = 40
        btn.layer.borderColor = UIColor.clear.cgColor
        btn.layer.borderWidth = 0.0
        btn.layer.shadowColor = UIColor(red: 0, green: 0, blue: 0, alpha: 0.25).cgColor
        btn.layer.shadowOffset = CGSize(width: 2.0, height: 5.0)
        btn.layer.shadowOpacity = 1.0
        btn.layer.shadowRadius = 5.0
        btn.layer.masksToBounds = false
    }
    
    func getxBound()-> CGFloat{
        var xbounds = 0.00
        if #available(iOS 11.0, *) {
            if let window = UIApplication.shared.keyWindow {
                xbounds = Double((view.bounds.width - window.safeAreaInsets.right))
            }
        }
        else
        {
            xbounds = Double(view.bounds.width)
        }
        
        return CGFloat(xbounds)
    }
    
    func getyBound()-> CGFloat{
        
        var xbounds = 0.00
        if #available(iOS 11.0, *) {
            if let window = UIApplication.shared.keyWindow {
                xbounds = Double((view.bounds.height -  window.safeAreaInsets.bottom))
            }
        }
        else
        {
            xbounds = Double(view.bounds.height)
        }
        
        let preferences = UserDefaults.standard
        
        let yboundKey = "yBound"
        if preferences.object(forKey: yboundKey) == nil {
            //  Doesn't exist
            preferences.set(Double(xbounds), forKey: yboundKey)
            
            preferences.synchronize()
        } else {
            xbounds = preferences.double(forKey: yboundKey)
        }
        
        return CGFloat(xbounds)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "vcRemarksDetails") as! RemarksDetailsViewController
        vc.modalPresentationStyle = .fullScreen
        let remarkModel = remarks?[indexPath.row]
        
        vc.varRemarkId = remarkModel?.id
        vc.varClassName = remarkModel?.Class_name
        vc.varDate = formateDateFromString(dateString: ((remarkModel?.Date)!), withFormat: "dd-MMM-yyyy")
        vc.varSubjectName = remarkModel?.Subject_name
        vc.varTeacherName = remarkModel?.TeacherName
        vc.varRemarks = remarkModel?.Remark
        vc.varStatus = remarkModel?.Read
        
        self.navigationController?.pushViewController(vc, animated: false)
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "RemarksCell") as! RemarksTableViewCell
        
        cell.labelClass?.text = self.defaultLocalizer.stringForKey(key: "labelClass")
        cell.labelSubject?.text = self.defaultLocalizer.stringForKey(key: "labelSubject")
        
        var remarkModel:Remark?
        remarkModel = remarks?[indexPath.row]
        
        cell.textClass?.text = remarkModel?.Class_name
        cell.textSubject?.text = remarkModel?.Subject_name
        cell.textDate?.text = formateDateFromString(dateString: (remarkModel?.Date)!, withFormat: "dd-MMM-yyyy")
        cell.textRemarks?.text = remarkModel?.Remark
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return remarks?.count ?? 0
    }
    
    func removeSubView()
    {
        if let viewWithTag = self.view.viewWithTag(100) {
            viewWithTag.removeFromSuperview()
        }
        if let viewWithTag = self.view.viewWithTag(7575) {
            viewWithTag.removeFromSuperview()
        }
    }
    
    func displayAlertMessage()
    {
        let imageview = UIImageView(frame: CGRect(x: ((self.view.frame.size.width / 2) - 50), y: ((self.view.frame.size.height / 2) - 74), width: 100, height: 100))
        imageview.image = UIImage(named: "norecordfound")
        imageview.contentMode = UIView.ContentMode.scaleAspectFit
        imageview.layer.masksToBounds = true
        imageview.tag = 7575
        self.view.addSubview(imageview)
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
