//
//  SetLanguageViewController.swift
//  SchoolZoneTeacher
//
//  Created by Apple on 21/02/19.
//  Copyright © 2019 ClearWin Technologies. All rights reserved.
//

import UIKit

class SetLanguageViewController: UIViewController {
    
    var opQueue = OperationQueue()
    let defaultLocalizer = AMPLocalizeUtils.defaultLocalizer
    
    var buttonActionSheet = UIButton()

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        if(getFirstName().trimmingCharacters(in: .whitespaces).count > 0)
        {
            AppLoadingStatus.appLoadingStatus.status = "Fresh"
            
            let vcLandingPage = self.storyboard!.instantiateViewController(withIdentifier: "vcRoot") as! RootViewController
            
            let appDelegate = UIApplication.shared.delegate as! AppDelegate
            appDelegate.window?.rootViewController = vcLandingPage
        }
        
        if(getLanguage().count > 0)
        {
            defaultLocalizer.setSelectedLanguage(lang: getLanguage())
        }
        else
        {
            defaultLocalizer.setSelectedLanguage(lang: "en")
        }
        
        self.buttonActionSheet = UIButton(frame: CGRect(x: 0, y: self.calculateTopDistance() + 225, width: self.view.frame.size.width, height: 50))
        self.buttonActionSheet.setTitle("", for: .normal)
        
        self.view.addSubview(buttonActionSheet)
        
        let actionsheet = UIAlertController(title: self.defaultLocalizer.stringForKey(key: "navBarTitleSetLanguage"), message: nil, preferredStyle: UIAlertController.Style.actionSheet)
        actionsheet.addAction(UIAlertAction(title: self.defaultLocalizer.stringForKey(key: "actionSheetTitleEnglishIndia"), style: UIAlertAction.Style.default, handler: { (action) -> Void in
            //print("English")
            setLanguage(languageCode: "en")
            setCountryCode(countryCode: "IN")
            
            //UserDefaults.standard.set(["en"], forKey: "AppleLanguages")
            //UserDefaults.standard.synchronize()
            
            let vc = self.storyboard?.instantiateViewController(withIdentifier: "vcTerms") as! TermsViewController
            vc.modalPresentationStyle = .fullScreen
            self.opQueue.addOperation {
                // Put queue to the main thread which will update the UI
                OperationQueue.main.addOperation({
                    self.present(vc, animated: false, completion: nil)
                })
            }
        }))
        
        actionsheet.addAction(UIAlertAction(title: self.defaultLocalizer.stringForKey(key: "actionSheetTitleThai"), style: UIAlertAction.Style.default, handler: { (action) -> Void in
            
            //UserDefaults.standard.set(["th"], forKey: "AppleLanguages")
            //UserDefaults.standard.synchronize()
            
            setLanguage(languageCode: "th")
            setCountryCode(countryCode: "TH")
            
            let vc = self.storyboard?.instantiateViewController(withIdentifier: "vcTerms") as! TermsViewController
            vc.modalPresentationStyle = .fullScreen
            self.opQueue.addOperation {
                // Put queue to the main thread which will update the UI
                OperationQueue.main.addOperation({
                    self.present(vc, animated: false, completion: nil)
                })
            }
            
        }))
        
        actionsheet.addAction(UIAlertAction(title: self.defaultLocalizer.stringForKey(key: "actionSheetTitleAssameseIndia"), style: UIAlertAction.Style.default, handler: { (action) -> Void in
            
            //UserDefaults.standard.set(["th"], forKey: "AppleLanguages")
            //UserDefaults.standard.synchronize()
            
            setLanguage(languageCode: "as-IN")
            setCountryCode(countryCode: "IN")
            
            let vc = self.storyboard?.instantiateViewController(withIdentifier: "vcTerms") as! TermsViewController
            vc.modalPresentationStyle = .fullScreen
            self.opQueue.addOperation {
                // Put queue to the main thread which will update the UI
                OperationQueue.main.addOperation({
                    self.present(vc, animated: false, completion: nil)
                })
            }
            
        }))
        
        actionsheet.addAction(UIAlertAction(title: self.defaultLocalizer.stringForKey(key: "actionSheetTitleCancel"), style: UIAlertAction.Style.cancel, handler: { (action) -> Void in
            
            exit(0)
        }))
        
        /*If you want work actionsheet on ipad
         then you have to use popoverPresentationController to present the actionsheet,
         otherwise app will crash on iPad */
        switch UIDevice.current.userInterfaceIdiom {
        case .pad:
            actionsheet.popoverPresentationController?.sourceView = buttonActionSheet
            actionsheet.popoverPresentationController?.sourceRect = buttonActionSheet.bounds
            actionsheet.popoverPresentationController?.permittedArrowDirections = .up
        default:
            break
        }
        
        // Restyle the view of the Alert
        actionsheet.view.tintColor = colorWithHexString (hex: "#333333")  // change text color of the buttons
        actionsheet.view.backgroundColor = colorWithHexString (hex: "#00CCFF")  // change background color
        actionsheet.view.layer.cornerRadius = 25
        self.opQueue.addOperation {
            // Put queue to the main thread which will update the UI
            OperationQueue.main.addOperation({
                
                switch UIDevice.current.userInterfaceIdiom {
                case .phone:
                    self.present(actionsheet, animated: true, completion: {
                        actionsheet.view.superview?.subviews[0].isUserInteractionEnabled = false
                    })
                case .pad:
                    self.present(actionsheet, animated: true, completion: nil)
                default:
                    self.present(actionsheet, animated: true, completion: {
                        actionsheet.view.superview?.subviews[0].isUserInteractionEnabled = false
                    })
                }
            })
        }
    }
    
    @objc func alertControllerBackgroundTapped()
    {
        //print("alertControllerBackgroundTapped")
        self.dismiss(animated: true, completion: nil)
    }
    
    func position(for bar: UIBarPositioning) -> UIBarPosition {
        return .topAttached
    }
    
    func calculateTopDistance () -> CGFloat{
        if(self.navigationController != nil && !self.navigationController!.navigationBar.isTranslucent){
            return 0
        }else{
            let barHeight=self.navigationController?.navigationBar.frame.height ?? 0
            let statusBarHeight = UIApplication.shared.isStatusBarHidden ? CGFloat(0) : UIApplication.shared.statusBarFrame.height
            return barHeight + statusBarHeight
        }
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
