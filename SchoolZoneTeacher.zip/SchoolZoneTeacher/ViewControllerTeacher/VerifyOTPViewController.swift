//
//  VerifyOTPViewController.swift
//  SchoolZoneTeacher
//
//  Created by Apple on 19/01/19.
//  Copyright © 2019 ClearWin Technologies. All rights reserved.
//

import UIKit
import SCLAlertView
import MaterialComponents

class VerifyOTPViewController: UIViewController, UITextFieldDelegate, CodeInputViewDelegate  {
    
    let defaultLocalizer = AMPLocalizeUtils.defaultLocalizer
    var buttonResendOTP = UIButton()
    var response:Response?
    var teachers:[Teacher]?
    let activityIndicator = MDCActivityIndicator();
    let appearance = SCLAlertView.SCLAppearance(
        kTitleFont: UIFont(name: "HelveticaNeue", size: 20)!,
        kTextFont: UIFont(name: "HelveticaNeue", size: 14)!,
        kButtonFont: UIFont(name: "HelveticaNeue-Bold", size: 14)!
    )
    
    var mobileNumber: String!
    var codeInputView = CodeInputView()
    
    var window: UIWindow?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        
        if(getLanguage().count > 0)
        {
            defaultLocalizer.setSelectedLanguage(lang: getLanguage())
        }
        else
        {
            defaultLocalizer.setSelectedLanguage(lang: "en")
        }
        
        let imageViewBackground = UIImageView(frame: CGRect(x: 0, y: 0, width: self.view.frame.size.width, height: self.view.frame.size.height))
        imageViewBackground.image = UIImage(named: "landing_page")
        
        // you can change the content mode:
        imageViewBackground.contentMode = UIView.ContentMode.scaleToFill
        
        self.view.addSubview(imageViewBackground)
        
        let logoImage = UIImageView(frame: CGRect(x: 40, y: view.center.y - 210, width: self.view.frame.size.width - 80, height: 70))
        logoImage.image = UIImage(named: "sz_logo")
        
        // you can change the content mode:
        logoImage.contentMode = UIView.ContentMode.scaleAspectFit
        
        self.view.addSubview(logoImage)
        
        let welcomeLabel = UILabel(frame: CGRect(x: 10, y: view.center.y - 140, width: self.view.frame.size.width - 20, height: 100))
        welcomeLabel.textColor = UIColor.white
        welcomeLabel.font = UIFont(name:"HelveticaNeue-Bold", size: 15.0)
        welcomeLabel.textAlignment = .left
        welcomeLabel.numberOfLines = 5
        welcomeLabel.lineBreakMode = .byWordWrapping
        welcomeLabel.text = self.defaultLocalizer.stringForKey(key: "labelHeaderEnterOTP")
        
        self.view.addSubview(welcomeLabel)
        
        codeInputView = CodeInputView(frame: CGRect(x: (view.frame.width-315)/2, y: view.center.y - 30, width: 315, height: 60))
        codeInputView.center.y = (view.center.y - 35)
        
        let toolbar:UIToolbar = UIToolbar(frame: CGRect(x: 0, y: 0,  width: self.view.frame.size.width, height: 30))
        //create left side empty space so that done button set on right side
        let flexSpace = UIBarButtonItem(barButtonSystemItem:    .flexibleSpace, target: nil, action: nil)
        let doneBtn: UIBarButtonItem = UIBarButtonItem(title: self.defaultLocalizer.stringForKey(key: "toolBarButtonTitleDone"), style: .done, target: self, action: #selector(doneButtonAction))
        toolbar.setItems([flexSpace, doneBtn], animated: false)
        toolbar.sizeToFit()
        codeInputView.delegate = self
        codeInputView.isUserInteractionEnabled = true
        codeInputView.keyboardType = .numberPad
        codeInputView.inputAccessoryView?.addSubview(toolbar)
        codeInputView.becomeFirstResponder()
        view.addSubview(codeInputView)
        
        window?.endEditing(false)
        
        let resendOTPLabel = UILabel(frame: CGRect(x: 10, y: (view.center.y - 20), width: self.view.frame.size.width - 20, height: 30))
        resendOTPLabel.textColor = UIColor.white
        resendOTPLabel.font = UIFont(name:"HelveticaNeue-Bold", size: 15.0)
        resendOTPLabel.textAlignment = .center
        resendOTPLabel.numberOfLines = 1
        resendOTPLabel.lineBreakMode = .byWordWrapping
        resendOTPLabel.text = self.defaultLocalizer.stringForKey(key: "labelDidnotGetOTP")
        
        self.view.addSubview(resendOTPLabel)
        
        self.buttonResendOTP = UIButton(frame: CGRect(x: 10, y: view.center.y + 15, width: self.view.frame.size.width - 20, height: 40))
        self.setSubmitButtonAppearence(buttonResendOTP: buttonResendOTP, buttonText: self.defaultLocalizer.stringForKey(key: "labelButtonReSendOTP"))
        buttonResendOTP.addTarget(self, action: #selector(resendOTP), for:.touchUpInside)
        
        view.addSubview(buttonResendOTP)
        
        self.activityIndicator.sizeToFit()
        self.activityIndicator.center.x = super.view.center.x
        self.activityIndicator.center.y = (super.view.center.y - 50)
        self.view.addSubview(activityIndicator)
        
        /*NotificationCenter.default.addObserver(self,
                                               selector: #selector(appWillEnterForeground),
                                               name: UIApplication.willEnterForegroundNotification,
                                               object: nil)*/
    }
    
    /*@objc func appWillEnterForeground() {
        //print("appWillEnterForeground")
        //window?.endEditing(false)
        //codeInputView.delegate = self
        //codeInputView.isUserInteractionEnabled = true
        //codeInputView.keyboardType = .numberPad
        //codeInputView.becomeFirstResponder()
    }*/
    
    @objc func resendOTP(sender: UIButton)
    {
        self.buttonResendOTP.isUserInteractionEnabled = false
        
        let alertView = SCLAlertView(appearance: self.appearance)
        self.activityIndicator.startAnimating()
        
        let mobile = MobileNumberShared.mobileNumberShared.MobileNumber!
        if var urlComponents = URLComponents(string: Constants.baseUrl + "sendOTP") {
            urlComponents.query = "mobile_number=" + mobile
            // 3
            guard let url = urlComponents.url else { return }
            
            getData(from: url) { data, response, error in
                if error != nil {
                    DispatchQueue.main.async {
                        self.buttonResendOTP.isUserInteractionEnabled = true
                        alertView.showError("OurSchoolZone", subTitle: self.defaultLocalizer.stringForKey(key: "allertMessageOTPNotSent"), closeButtonTitle: self.defaultLocalizer.stringForKey(key: "actionSheetTitleOK"))
                    }
                }
                guard let data = data else { return }
                //Implement JSON decoding and parsing
                do {
                    //Decode retrived data with JSONDecoder and assing type of Article object
                    let otpData = try JSONDecoder().decode(Result.self, from: data)
                    
                    //Get back to the main queue
                    DispatchQueue.main.async {
                        self.response = otpData.Response
                        
                        self.activityIndicator.stopAnimating()
                        
                        if(self.response?.ResponseVal == 0)
                        {
                            self.buttonResendOTP.isUserInteractionEnabled = true
                            alertView.showError("OurSchoolZone", subTitle: self.defaultLocalizer.stringForKey(key: "allertMessageOTPNotSent"), closeButtonTitle: self.defaultLocalizer.stringForKey(key: "actionSheetTitleOK"))
                        }
                    }
                    
                } catch let jsonError {
                    self.activityIndicator.stopAnimating()
                    print(jsonError)
                }
                
                
            }
        }
    }
    
    @objc func doneButtonAction() {
        self.view.endEditing(true)
    }
    
    func calculateTopDistance () -> CGFloat{
        let statusBarHeight = UIApplication.shared.isStatusBarHidden ? CGFloat(0) : UIApplication.shared.statusBarFrame.height
        return statusBarHeight + 45
    }
    
    func setSubmitButtonAppearence(buttonResendOTP: UIButton, buttonText: String){
        
        buttonResendOTP.tintColor = UIColor.gray
        buttonResendOTP.backgroundColor = colorWithHexString(hex: "#FFFFFF")
        buttonResendOTP.layer.masksToBounds = false
        buttonResendOTP.layer.borderColor = colorWithHexString(hex: "#DDDDDD").cgColor
        buttonResendOTP.layer.shadowColor = UIColor(red: 0, green: 0, blue: 0, alpha: 0.25).cgColor
        buttonResendOTP.layer.shadowOffset = CGSize(width: 1.0, height: 3.0)
        buttonResendOTP.layer.shadowOpacity = 1.0
        buttonResendOTP.layer.shadowRadius = 3.0
        buttonResendOTP.layer.masksToBounds = false
        buttonResendOTP.layer.cornerRadius = 3.0
        self.buttonResendOTP.isMultipleTouchEnabled = false
        
        let buttonLabel = UILabel(frame: CGRect(x: 0, y: 0, width: buttonResendOTP.frame.width, height: 40))
        buttonLabel.textColor = UIColor.gray
        buttonLabel.backgroundColor = colorWithHexString(hex: "#FFFFFF")
        buttonLabel.font = UIFont(name:"HelveticaNeue-Bold", size: 14.0)
        buttonLabel.textAlignment = .center
        buttonLabel.text = buttonText
        
        buttonResendOTP.addSubview(buttonLabel)
    }
    
    func codeInputView(_ codeInputView: CodeInputView, didFinishWithCode code: String) {
        self.activityIndicator.startAnimating()
        
        let alertView = SCLAlertView(appearance: self.appearance)
        
        if var urlComponents = URLComponents(string: Constants.baseUrl + "verifyOTPV2") {
            urlComponents.query = "mobile_number=" + mobileNumber + "&otp=" + code
            // 3
            guard let url = urlComponents.url else { return }
            
            getData(from: url) { data, response, error in
                if error != nil {
                    print(error!.localizedDescription)
                }
                guard let data = data else { return }
                //Implement JSON decoding and parsing
                do {
                    //Decode retrived data with JSONDecoder and assing type of Article object
                    let verifyotpData = try JSONDecoder().decode(Result.self, from: data)
                    
                    //Get back to the main queue
                    DispatchQueue.main.async {
                        self.response = verifyotpData.Response
                        
                        self.activityIndicator.stopAnimating()
                        
                        if(self.response?.ResponseVal == 0)
                        {
                            
                            alertView.showError("OurSchoolZone", subTitle: self.defaultLocalizer.stringForKey(key: "allertMessageInvalidOTP"), closeButtonTitle: self.defaultLocalizer.stringForKey(key: "actionSheetTitleOK"))
                        }
                        else{
                            self.view.endEditing(true)
                            self.teachers = verifyotpData.Teachers
                            
                            var teacher: Teacher?
                            teacher = self.teachers?[0]
                            
                            setSchoolId(schoolId: (teacher?.School_id)!)
                            setSchoolName(schoolName: (teacher?.School_Name)!)
                            setTeacherId(teacherId: (teacher?.TeacherID)!)
                            setFirstName(firstName: (teacher?.FirstName)!)
                            setMiddleName(middleName: (teacher?.MiddleName)!)
                            setLastName(lastName: (teacher?.LastName)!)
                            setEmail(email: (teacher?.Email)!)
                            setMobile(mobile: (teacher?.Mobile)!)
                            setDOB(dob: (teacher?.DOB)!)
                            setGender(gender: (teacher?.Gender)!)
                            setLang(lang: (teacher?.Language)!)
                            setProfileImage(profileImage: (teacher?.ProfileImage)!)
                            setSchoolLogo(logoImage: (teacher?.SchoolLogo)!)
                            setSchoolAddress(address: (teacher?.SchoolAddress)!)
                            
                            let startDate = (teacher?.Start_Date)!
                            let endDate = (teacher?.End_Date)!
                            let startDateArr = startDate.components(separatedBy: "-")
                            let endDateArr = endDate.components(separatedBy: "-")
                            
                            var academicYear = String()
                            if(startDateArr[2] == endDateArr[2])
                            {
                                academicYear = startDateArr[2]
                            }
                            else if( startDateArr[2] < endDateArr[2])
                            {
                                academicYear = startDateArr[2] + " - " + endDateArr[2]
                            }
                            
                            setAcademicYear(academicYear: self.defaultLocalizer.stringForKey(key: "allertMessageAcademicYearSelected") + academicYear)
                            
                            var teacherids = [String]()
                            var schoolids = [String]()
                            var schoolnames = [String]()
                            var schoollogos = [String]()
                            if(self.response?.ResponseVal == 1){
                                for teacherRec in self.teachers!
                                {
                                    teacherids.append(teacherRec.TeacherID!)
                                    schoolids.append(teacherRec.School_id!)
                                    schoolnames.append("  " + teacherRec.School_Name!)
                                    schoollogos.append(teacherRec.SchoolLogo!)
                                }
                                
                                setTeacherIds(teacherIds: teacherids)
                                setSchoolIds(schoolIds: schoolids)
                                setSchoolNames(schoolNames: schoolnames)
                                setSchoolLogos(schoolLogos: schoollogos)
                            }
                            
                            AppLoginStatus.appLoginStatus.status = 1
                            AppLoadingStatus.appLoadingStatus.status = "Fresh"
                            
                            //register device
                            
                            var schoolIdQueryString = String()
                            for id in schoolids
                            {
                                schoolIdQueryString += "schoolId=\(id)&"
                            }
                            
                            let teacherId = getTeacherId()
                            let deviceToken = getDeviceToken()
                            let uuid = KeychainService.loadUUID()!
                            let fname = getFirstName() + " "
                            let mname = getMiddleName().count > 0 ? getMiddleName() + " " : ""
                            let lname = getLastName()
                            let fullname = fname + mname + lname
                            let mobile = getMobile()
                            let email = getEmail()
                            
                            if(deviceToken.count > 0)
                            {
                                let queryString = schoolIdQueryString + "parentid=&teacherid=\(teacherId)" + "&token=\(deviceToken)" + "&UUID=\(uuid)" + "&username=\(fullname)" + "&usermobile=\(mobile)" + "&useremail=\(email)" + "&iPhone=true"
                                
                                if var urlComponents = URLComponents(string: Constants.baseUrl + "RegisterDeviceV2") {
                                    urlComponents.query = queryString
                                    // 3
                                    guard let url = urlComponents.url else { return }
                                    
                                    print(url)
                                    
                                    var request = URLRequest(url: url)
                                    request.setValue("application/x-www-form-urlencoded", forHTTPHeaderField: "Content-Type")
                                    request.httpMethod = "POST"
                                    let postString = queryString
                                    request.httpBody = postString.data(using: .utf8)
                                    
                                    postData(from: request) { data, response, error in
                                        if let httpStatus = response as? HTTPURLResponse, httpStatus.statusCode != 200 {
                                            let responseMessage = String(describing: response)
                                            
                                            print(responseMessage)
                                        }
                                        guard let data = data else { return }
                                        
                                        do {
                                            //Decode retrived data with JSONDecoder and assing type of Article object
                                            let responseData = try JSONDecoder().decode(Result.self, from: data)
                                            
                                            //Get back to the main queue
                                            DispatchQueue.main.async {
                                                if(responseData.Response.ResponseVal == 0)
                                                {
                                                    alertView.showError("OurSchoolZone", subTitle: self.defaultLocalizer.stringForKey(key: "allertMessageDeviceNotRegistered"))
                                                }
                                                //print(responseData.Response.Reason!)
                                            }
                                            
                                        } catch let jsonError {
                                            let responseMessage = String(describing: jsonError)
                                            
                                            print(responseMessage)
                                        }
                                    }
                                }
                            }
                            
                            let vcLandingPage = self.storyboard!.instantiateViewController(withIdentifier: "vcRoot") as! RootViewController
                            
                            let appDelegate = UIApplication.shared.delegate as! AppDelegate
                            appDelegate.window?.rootViewController = vcLandingPage
                        }
                    }
                    
                } catch let jsonError {
                    self.activityIndicator.stopAnimating()
                    print(jsonError)
                }
            }
        }
    }
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destination.
     // Pass the selected object to the new view controller.
     }
     */
}
