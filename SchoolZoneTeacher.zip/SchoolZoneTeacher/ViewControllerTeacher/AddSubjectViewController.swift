//
//  AddSubjectViewController.swift
//  SchoolZoneTeacher
//
//  Created by Apple on 20/05/19.
//  Copyright © 2019 ClearWin Technologies. All rights reserved.
//

import UIKit
import WebKit
import SCLAlertView
import iOSDropDown
import MaterialComponents
import CropViewController
import MobileCoreServices
import PDFKit

class AddSubjectViewController: UIViewController, UINavigationControllerDelegate, UIImagePickerControllerDelegate, UIActionSheetDelegate, CropViewControllerDelegate, UIDocumentMenuDelegate, UIDocumentPickerDelegate, WKNavigationDelegate {

    let defaultLocalizer = AMPLocalizeUtils.defaultLocalizer
    let activityIndicator = MDCActivityIndicator();
    var classsections:[Classsection]?
    var subjects:[Subject]?
    var response:Response?
    var classIds = [Int]()
    var classNames = [String]()
    var subjectIds = [Int]()
    var subjectNames = [String]()
    
    var containerView = UIView()
    var dropDownClass = DropDown()
    var dropDownSubject = DropDown()
    var schoolid = Int()
    var teacherid = Int()
    var classId = Int()
    var subjectId = Int()
    
    var imageController = UIImagePickerController()
    var imagePreviewContainer = UIView()
    
    var buttonSubmit = UIButton()
    var buttonAttachment = UIButton()
    
    var adjustY = CGFloat()
    
    let appearance = SCLAlertView.SCLAppearance(
        kTitleFont: UIFont(name: "HelveticaNeue", size: 20)!,
        kTextFont: UIFont(name: "HelveticaNeue", size: 14)!,
        kButtonFont: UIFont(name: "HelveticaNeue-Bold", size: 14)!,
        showCloseButton: false
    )
    
    override func viewDidAppear(_ animated: Bool) {

        if #available(iOS 13, *)
        {
            let statusBar = UIView(frame: (UIApplication.shared.keyWindow?.windowScene?.statusBarManager?.statusBarFrame)!)
            statusBar.backgroundColor = colorWithHexString(hex: "#00CCFF")
            UIApplication.shared.keyWindow?.addSubview(statusBar)
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        dropDownClassShared.dropdownClassShared.isShown = 0
        dropDownSubjectShared.dropdownSubjectShared.isShown = 0
        
        if(getLanguage().count > 0)
        {
            defaultLocalizer.setSelectedLanguage(lang: getLanguage())
        }
        else
        {
            defaultLocalizer.setSelectedLanguage(lang: "en")
        }
        
        PickedImageCountShared.pickedImageCountShared.count = 0
        self.setNavigationBar()
        self.setSubjectSyllabusSubmissionView()
        self.loadClass()
    }
    
    func loadClass() {
        self.activityIndicator.startAnimating()
        let schoolid = getSchoolId()
        let teacherid = getTeacherId()
        //self.dropDownSubject.delegate = self
        
        if var urlComponents = URLComponents(string: Constants.baseUrl + "ClassV2") {
            urlComponents.query = "schoolid=" + schoolid + "&teacherid=" + teacherid
            // 3
            guard let url = urlComponents.url else { return}
            
            getData(from: url) { data, response, error in
                if error != nil {
                    self.activityIndicator.stopAnimating()
                    print(error!.localizedDescription)
                }
                
                guard let data = data else { return}
                //Implement JSON decoding and parsing
                do {
                    //Decode retrived data with JSONDecoder and assing type of Article object
                    let classData = try JSONDecoder().decode(Result.self, from: data)
                    
                    //Get back to the main queue
                    DispatchQueue.main.async {
                        self.activityIndicator.stopAnimating()
                        self.classsections = classData.ClassList
                        self.response = classData.Response
                        if(self.response?.ResponseVal == 1){
                            for classsection in self.classsections!
                            {
                                self.classIds.append(classsection.id)
                                self.classNames.append("   " + classsection.Classsecname)
                            }
                            
                            if(self.classIds.count > 0 && self.classNames.count > 0){
                                // The list of array to display. Can be changed dynamically
                                self.dropDownClass.optionArray = self.classNames
                                // Its Id Values and its optional
                                self.dropDownClass.optionIds = self.classIds
                            }
                        }
                    }
                } catch let jsonError {
                    self.activityIndicator.stopAnimating()
                    print(jsonError)
                }
            }
        }
    }
    
    func loadSubjects(classId: Int) {
        
        if(dropDownSubjectShared.dropdownSubjectShared.isShown == 1)
        {
            dropDownSubjectShared.dropdownSubjectShared.isShown = 0
            self.dropDownSubject.hideList()
        }
        
        self.subjectIds.removeAll()
        self.subjectNames.removeAll()
        
        // The list of array to display. Can be changed dynamically
        self.dropDownSubject.optionArray = self.subjectNames
        // Its Id Values and its optional
        self.dropDownSubject.optionIds = self.subjectIds
        
        let schoolid = getSchoolId();
        let teacherid = getTeacherId()
        
        if var urlComponents = URLComponents(string: Constants.baseUrl + "SubjectV2") {
            urlComponents.query = "schoolid=" + schoolid + "&classid=" + "\(classId)" + "&teacherid=" + teacherid
            // 3
            guard let url = urlComponents.url else { return}
            //print(url)
            getData(from: url) { data, response, error in
                if error != nil {
                    print(error!.localizedDescription)
                }
                
                guard let data = data else { return}
                //Implement JSON decoding and parsing
                do {
                    //Decode retrived data with JSONDecoder and assing type of Article object
                    let subjectData = try JSONDecoder().decode(Result.self, from: data)
                    
                    //Get back to the main queue
                    DispatchQueue.main.async {
                        self.subjects = subjectData.SubjectList
                        //dump(subjectData.SubjectList)
                        self.response = subjectData.Response
                        if(self.response?.ResponseVal == 1){
                            for subject in self.subjects!
                            {
                                self.subjectIds.append(subject.id)
                                self.subjectNames.append("   " + subject.Subjectname)
                            }
                            
                            if(self.subjectIds.count > 0 && self.subjectNames.count > 0){
                                // The list of array to display. Can be changed dynamically
                                self.dropDownSubject.optionArray = self.subjectNames
                                // Its Id Values and its optional
                                self.dropDownSubject.optionIds = self.subjectIds
                            }
                        }
                    }
                } catch let jsonError {
                    print(jsonError)
                }
            }
        }
    }
    
    func calculateTopDistance () -> CGFloat{
        let statusBarHeight = UIApplication.shared.isStatusBarHidden ? CGFloat(0) : UIApplication.shared.statusBarFrame.height
        return statusBarHeight + 45
    }
    
    func setDropdown(height: CGFloat, dropDown: DropDown, text: String, optionNames: [String], optionIds: [Int])
    {
        dropDown.placeholder = text;
        //dropDown.font = UIFont.systemFont(ofSize: 14.00)
        dropDown.textColor = UIColor.lightGray
        dropDown.backgroundColor = UIColor.white
        dropDown.rowBackgroundColor = UIColor.white;
        dropDown.borderWidth = 0.5
        dropDown.borderColor = colorWithHexString(hex: "#DDDDDD")
        dropDown.cornerRadius = 3
        dropDown.selectedRowColor = colorWithHexString(hex: "#DDDDDD");
        dropDown.arrowSize = 10;
        dropDown.isSearchEnable = false;
        // The list of array to display. Can be changed dynamically
        dropDown.optionArray = optionNames
        // Its Id Values and its optional
        dropDown.optionIds = optionIds
        dropDown.rowHeight = CGFloat(50)
        dropDown.listHeight = height
    }
    
    func setNavigationBar() {
        let navigationFont = UIFont(name: "Helvetica", size: getTitleFontSize())
        let screenSize: CGRect = UIScreen.main.bounds;
        let statusBarHeight = UIApplication.shared.isStatusBarHidden ? CGFloat(0) : UIApplication.shared.statusBarFrame.height
        let navBar: UINavigationBar = UINavigationBar(frame: CGRect(x: 0, y: statusBarHeight, width: screenSize.width, height: 44))
        self.view.insertSubview(navBar, at: 50);
        
        let navItem = UINavigationItem(title: defaultLocalizer.stringForKey(key: "navBarTitleNewSyllabus"));
        let button = UIButton.init(type: .custom)
        button.setTitle(defaultLocalizer.stringForKey(key: "navBarButtonBack"), for: UIControl.State.normal)
        var image = UIImage.init(named: "back");
        let templateImage = image?.withRenderingMode(UIImage.RenderingMode.alwaysTemplate)
        image = templateImage
        button.setImage(image, for: UIControl.State.normal)
        button.addTarget(self, action:#selector(back), for:.touchUpInside)
        button.addTarget(self, action:#selector(back), for:.touchUpOutside)
        button.frame = CGRect.init(x: 0, y: 0, width: 20, height: 20) //CGRectMake(0, 0, 30, 30)
        let doneItem = UIBarButtonItem.init(customView: button)
        
        //let doneItem = UIBarButtonItem(title: "Back", style: .plain, target: self, action: #selector(back))
        navItem.leftBarButtonItem = doneItem;
        
        navBar.setItems([navItem], animated: false);
        navBar.backgroundColor = colorWithHexString(hex: "#00CCFF");
        navBar.isTranslucent = false;
        
        navBar.titleTextAttributes = [
            NSAttributedString.Key.foregroundColor : UIColor.white, NSAttributedString.Key.font: navigationFont!, NSAttributedString.Key.shadow: setNavBarTitleShadow()
        ]
        
        if #available(iOS 11, *){
            navBar.titleTextAttributes = [NSAttributedString.Key.foregroundColor: UIColor.white, NSAttributedString.Key.font: navigationFont!, NSAttributedString.Key.shadow: setNavBarTitleShadow()]
        }
    }
    
    @objc func back() { // remove @objc for Swift 3
        self.dismiss(animated: false, completion: nil);
    }
    
    func position(for bar: UIBarPositioning) -> UIBarPosition {
        return .topAttached
    }
    
    @objc func dropDownClassTap(){
        //dropDownSubject.delegate = self
        // The list of array to display. Can be changed dynamically
        self.dropDownSubject.optionArray = [String]()
        // Its Id Values and its optional
        self.dropDownSubject.optionIds = [Int]()
    }
    
    @objc func doneButtonAction() {
        self.view.endEditing(true)
    }
    
    func setSubjectSyllabusSubmissionView()
    {
        let scroolHeight = self.view.frame.size.height - self.calculateTopDistance()
        
        containerView = UIView(frame: CGRect(x: 0, y: self.calculateTopDistance(), width: self.view.frame.size.width, height: scroolHeight))
        
        //init toolbar
        let toolbar:UIToolbar = UIToolbar(frame: CGRect(x: 0, y: 0,  width: self.view.frame.size.width, height: 30))
        //create left side empty space so that done button set on right side
        let flexSpace = UIBarButtonItem(barButtonSystemItem:    .flexibleSpace, target: nil, action: nil)
        let doneBtn: UIBarButtonItem = UIBarButtonItem(title: self.defaultLocalizer.stringForKey(key: "toolBarButtonTitleDone"), style: .done, target: self, action: #selector(doneButtonAction))
        toolbar.setItems([flexSpace, doneBtn], animated: false)
        toolbar.sizeToFit()
        
        self.dropDownClass = DropDown(frame: CGRect(x: 10, y: 10, width: self.containerView.frame.size.width - 20, height: 50))
        self.setDropdown(height: scroolHeight - 108, dropDown: self.dropDownClass, text: defaultLocalizer.stringForKey(key: "dropDownLabelClass"), optionNames: classNames, optionIds: classIds)
        
        self.dropDownClass.listWillAppear {
            //You can Do anything when iOS DropDown listDidAppear
            dropDownClassShared.dropdownClassShared.isShown = 1;
        }
        
        // The the Closure returns Selected Index and String
        self.dropDownClass.didSelect{(selectedText , index ,id) in
            self.dropDownClass.textColor = UIColor.black
            self.classId = id
            self.subjectId = 0
            self.dropDownSubject.text = String()
            self.dropDownSubject.placeholder = self.defaultLocalizer.stringForKey(key: "dropDownLabelSubject")
            
            self.loadSubjects(classId: self.classId)
        }
        
        self.dropDownSubject = DropDown(frame: CGRect(x: 10, y: 70, width: self.containerView.frame.size.width - 20, height: 50))
        self.setDropdown(height: scroolHeight - 108, dropDown: self.dropDownSubject, text: self.defaultLocalizer.stringForKey(key: "dropDownLabelSubject"), optionNames: subjectNames, optionIds: subjectIds)
        // The the Closure returns Selected Index and String
        self.dropDownSubject.didSelect{(selectedText , index ,id) in
            self.dropDownSubject.textColor = UIColor.black
            self.subjectId = id
        }
        
        self.dropDownSubject.listWillAppear {
            //You can Do anything when iOS DropDown listDidAppear
            dropDownSubjectShared.dropdownSubjectShared.isShown = 1;
        }
        
        buttonAttachment = UIButton(frame: CGRect(x: 10, y: 130, width: ((self.containerView.frame.size.width / 2) - 5), height: 50))
        self.setAttachmentButtonAppearence(buttonAttachment: buttonAttachment, buttonText: self.defaultLocalizer.stringForKey(key: "buttonLabelSyllabysAttachment"))
        
        self.buttonSubmit = UIButton(frame: CGRect(x: ((self.containerView.frame.size.width / 2) + 15), y: 130, width: ((self.containerView.frame.size.width / 2) - 25), height: 50))
        self.setSubmitButtonAppearence(buttonSubmit: buttonSubmit, buttonText: self.defaultLocalizer.stringForKey(key: "buttonLabelSubmit"))
        buttonSubmit.addTarget(self, action: #selector(submitSyllabus), for:.touchUpInside)
        buttonSubmit.addTarget(self, action: #selector(submitSyllabus), for:.touchUpOutside)
        
        self.imagePreviewContainer = UIView(frame: CGRect(x: 10, y: 190, width: self.containerView.frame.size.width, height: (self.containerView.frame.size.width / 3) - 40))
        
        self.containerView.insertSubview(self.imagePreviewContainer, at: 0)
        self.containerView.insertSubview(self.buttonSubmit, at: 1)
        self.containerView.insertSubview(self.buttonAttachment, at: 2)
        self.containerView.insertSubview(self.dropDownSubject, at: 9)
        self.containerView.insertSubview(self.dropDownClass, at: 10)
        self.view.insertSubview(self.containerView, at: 0)
        
        self.activityIndicator.sizeToFit()
        self.activityIndicator.center.x = super.view.center.x
        self.activityIndicator.center.y = (super.view.center.y - 50)
        
        self.view.addSubview(activityIndicator)
    }
    
    func generateBoundaryString() -> String {
        return "Boundary-\(NSUUID().uuidString)"
    }
    
    func createBody(boundary: String) -> Data {
        var body = Data();
        
        var imageView = UIImageView()
        if (PickedImageCountShared.pickedImageCountShared.count > 0 && self.view.viewWithTag(11) != nil) {
            imageView = self.view.viewWithTag(11) as! UIImageView
            
            let imageData = imageView.image!.jpegData(compressionQuality: 0.75)
            
            if(imageData != nil){
                let filePathKey = "file1"
                let filename = "SubjectSyllabus_Image1.jpg"
                let mimetype = "image/jpg"
                
                body.append("--\(boundary)\r\n".data(using: String.Encoding.utf8)!)
                body.append("Content-Disposition: form-data; name=\"\(filePathKey)\"; filename=\"\(filename)\"\r\n".data(using: String.Encoding.utf8)!)
                body.append("Content-Type: \(mimetype)\r\n\r\n".data(using: String.Encoding.utf8)!)
                body.append(imageData!)
                //body.appendData(imageDataKey)
                body.append("\r\n".data(using: String.Encoding.utf8)!)
            }
        }
        else if ( PickedFileURLShared.pickedFileURLShared.url != nil)
        {
            //print("File Picked: " + "\(PickedFileURLShared.pickedFileURLShared.url)")
            let filePathKey = "file1"
            let filename = "SubjectSyllabus_PDF.pdf"
            let mimetype = "application/pdf"
            
            let pdfData = try! Data(contentsOf: PickedFileURLShared.pickedFileURLShared.url.asURL())
            let data : Data = pdfData
            
            body.append("--\(boundary)\r\n".data(using: String.Encoding.utf8)!)
            body.append("Content-Disposition: form-data; name=\"\(filePathKey)\"; filename=\"\(filename)\"\r\n".data(using: String.Encoding.utf8)!)
            body.append("Content-Type: \(mimetype)\r\n\r\n".data(using: String.Encoding.utf8)!)
            body.append(data)
            //body.appendData(imageDataKey)
            body.append("\r\n".data(using: String.Encoding.utf8)!)
        }
        
        body.append("--\(boundary)--\r\n".data(using: String.Encoding.utf8)!)
        
        return body
    }
    
    func resetInputFileds()
    {
        self.dropDownClass.text = String()
        self.dropDownSubject.text = String()
        self.dropDownClass.placeholder = defaultLocalizer.stringForKey(key: "dropDownLabelClass")
        self.dropDownSubject.placeholder = self.defaultLocalizer.stringForKey(key: "dropDownLabelSubject")
        self.dropDownClass.isSelected = false
        self.dropDownSubject.isSelected = false
        if let viewWithTag = self.view.viewWithTag(11) {
            viewWithTag.removeFromSuperview()
        }
        if let viewWithTag = self.view.viewWithTag(14) {
            viewWithTag.removeFromSuperview()
        }
        
        self.buttonSubmit.isUserInteractionEnabled = true;
    }
    
    @objc func alertViewOKTap()
    {
        
        self.navigationController?.popViewController(animated: false)
    }
    
    func insertSyllabus(schoolId: Int, classId: Int, subjectId: Int)
    {
        let alertView = SCLAlertView(appearance: self.appearance)
        
        let queryString = "school_id=" + "\(schoolId)" + "&class_id=" + "\(classId)" + "&subject_id=" + "\(subjectId)"
        
        // To make the activity indicator appear:
        self.activityIndicator.startAnimating()
        
        if var urlComponents = URLComponents(string: Constants.baseUrl + "AddSubjectSyllabus") {
            urlComponents.query = queryString
            // 3
            guard let url = urlComponents.url else { return}
            
            var request = URLRequest(url: url)
            request.httpMethod = "POST"
            
            if self.view.viewWithTag(11) != nil || self.view.viewWithTag(14) != nil {
                
                let boundary = generateBoundaryString()
                request.setValue("multipart/form-data; boundary=\(boundary)", forHTTPHeaderField: "Content-Type")
                request.httpBody = createBody(boundary: boundary)
            }
            
            postData(from: request) { data, response, error in
                if let httpStatus = response as? HTTPURLResponse, httpStatus.statusCode != 200 {
                    //let responseMessage = String(describing: response)
                    
                    //Get back to the main queue
                    DispatchQueue.main.async {
                        self.activityIndicator.stopAnimating()
                        
                        alertView.addButton(self.defaultLocalizer.stringForKey(key: "actionSheetTitleOK")) {
                            alertView.dismiss(animated: true, completion: nil)
                        }
                        alertView.showError("OurSchoolZone", subTitle: self.defaultLocalizer.stringForKey(key: "allertMessageSyllabusSubmitError"), closeButtonTitle: self.defaultLocalizer.stringForKey(key: "actionSheetTitleOK"))
                        self.buttonSubmit.isUserInteractionEnabled = true;
                    }
                    return
                }
                else
                {
                    //Get back to the main queue
                    DispatchQueue.main.async {
                        self.activityIndicator.stopAnimating()
                        
                        self.resetInputFileds();
                        
                        alertView.addButton(self.defaultLocalizer.stringForKey(key: "actionSheetTitleOK"), target:self, selector: #selector(self.alertViewOKTap))
                        
                        alertView.showSuccess("OurSchoolZone", subTitle: self.defaultLocalizer.stringForKey(key: "allertMessageSyllabusSubmitSuccess"), closeButtonTitle: self.defaultLocalizer.stringForKey(key: "actionSheetTitleOK"))
                    }
                }
            }
        }
    }
    
    @objc func submitSyllabus()
    {
        
        schoolid = Int(getSchoolId())!;
        teacherid = Int(getTeacherId())!;
        
        let alertView = SCLAlertView(appearance: self.appearance)
        alertView.addButton(self.defaultLocalizer.stringForKey(key: "actionSheetTitleOK")) {
            alertView.dismiss(animated: true, completion: nil)
        }
        
        if(self.classId == 0 || self.subjectId == 0)
        {
            alertView.showInfo("OurSchoolZone", subTitle: self.defaultLocalizer.stringForKey(key: "allertMessageSelectAllFields"), closeButtonTitle: self.defaultLocalizer.stringForKey(key: "actionSheetTitleOK"))
            return
        }
        if self.view.viewWithTag(11) == nil && self.view.viewWithTag(14) == nil {
            alertView.showInfo("OurSchoolZone", subTitle: self.defaultLocalizer.stringForKey(key: "allertMessageSelectAttachment"), closeButtonTitle: self.defaultLocalizer.stringForKey(key: "actionSheetTitleOK"))
            return
        }
        
        buttonSubmit.isUserInteractionEnabled = false
        self.insertSyllabus(schoolId: Int(self.schoolid), classId: self.classId, subjectId: self.subjectId)
    }
    
    func setSubmitButtonAppearence(buttonSubmit: UIButton, buttonText: String){
        
        buttonSubmit.tintColor = UIColor.white
        buttonSubmit.backgroundColor = colorWithHexString(hex: "#00FFCC")
        buttonSubmit.layer.masksToBounds = false
        buttonSubmit.layer.borderColor = colorWithHexString(hex: "#DDDDDD").cgColor
        buttonSubmit.layer.shadowColor = UIColor(red: 0, green: 0, blue: 0, alpha: 0.25).cgColor
        buttonSubmit.layer.shadowOffset = CGSize(width: 1.0, height: 5.0)
        buttonSubmit.layer.shadowOpacity = 1.0
        buttonSubmit.layer.shadowRadius = 5.0
        buttonSubmit.layer.masksToBounds = false
        buttonSubmit.layer.cornerRadius = 3.0
        buttonSubmit.isMultipleTouchEnabled = false
        
        let imageView = UIImageView(frame: CGRect(x: 5, y: 5, width: 40, height: 40))
        imageView.image = UIImage(named: "ok")
        
        let buttonLabel = UILabel(frame: CGRect(x: 40, y: 0, width: buttonSubmit.frame.width - 40, height: 50))
        
        buttonLabel.textColor = UIColor.white
        buttonLabel.font = UIFont(name:"HelveticaNeue-Bold", size: 16.0)
        buttonLabel.textAlignment = .left
        buttonLabel.text = buttonText
        
        buttonSubmit.addSubview(imageView)
        buttonSubmit.addSubview(buttonLabel)
    }
    
    func setAttachmentButtonAppearence(buttonAttachment: UIButton, buttonText: String){
        buttonAttachment.tintColor = UIColor.gray
        buttonAttachment.backgroundColor = colorWithHexString(hex: "#FFFFFF")
        buttonAttachment.layer.masksToBounds = false
        buttonAttachment.layer.borderColor = colorWithHexString(hex: "#DDDDDD").cgColor
        buttonAttachment.backgroundColor = colorWithHexString(hex: "#00FFCC")
        buttonAttachment.layer.shadowColor = UIColor(red: 0, green: 0, blue: 0, alpha: 0.25).cgColor
        buttonAttachment.layer.shadowOffset = CGSize(width: 1.0, height: 5.0)
        buttonAttachment.layer.shadowOpacity = 1.0
        buttonAttachment.layer.shadowRadius = 5.0
        buttonAttachment.layer.masksToBounds = false
        buttonAttachment.layer.cornerRadius = 3.0
        buttonAttachment.addTarget(self, action:#selector(buttonAttachmentTap), for:.touchUpInside)
        
        let imageView = UIImageView(frame: CGRect(x: 5, y: 5, width: 40, height: 40))
        imageView.image = UIImage(named: "attachment")
        
        let buttonAttachementLabel = UILabel(frame: CGRect(x: 40, y: 0, width: buttonAttachment.frame.width - 40, height: 50))
        buttonAttachementLabel.textColor = UIColor.gray
        buttonAttachment.backgroundColor = colorWithHexString(hex: "#FFFFFF")
        buttonAttachementLabel.font = UIFont(name:"HelveticaNeue-Bold", size: 16.0)
        buttonAttachementLabel.textAlignment = .left
        buttonAttachementLabel.text = buttonText
        
        buttonAttachment.addSubview(imageView)
        buttonAttachment.addSubview(buttonAttachementLabel)
    }
    
    @objc func buttonAttachmentTap(_ sender: UIButton) {
        imageController.delegate = self;
        
        //here I want to execute the UIActionSheet
        let actionsheet = UIAlertController(title: nil, message: nil, preferredStyle: UIAlertController.Style.actionSheet)
        
        actionsheet.addAction(UIAlertAction(title: self.defaultLocalizer.stringForKey(key: "actionSheetTitleCamera"), style: UIAlertAction.Style.default, handler: { (action) -> Void in
            self.openCamera()
        }))
        
        actionsheet.addAction(UIAlertAction(title: self.defaultLocalizer.stringForKey(key: "actionSheetTitleGallery"), style: UIAlertAction.Style.default, handler: { (action) -> Void in
            self.openGallary()
        }))
        actionsheet.addAction(UIAlertAction(title: self.defaultLocalizer.stringForKey(key: "actionSheetTitleFile"), style: .default, handler: { (action) -> Void in
            self.documentPicker()
        }))
        actionsheet.addAction(UIAlertAction(title: self.defaultLocalizer.stringForKey(key: "actionSheetTitleCancel"), style: UIAlertAction.Style.cancel, handler: { (action) -> Void in
            
        }))
        
        /*If you want work actionsheet on ipad
         then you have to use popoverPresentationController to present the actionsheet,
         otherwise app will crash on iPad */
        switch UIDevice.current.userInterfaceIdiom {
        case .pad:
            actionsheet.popoverPresentationController?.sourceView = sender
            actionsheet.popoverPresentationController?.sourceRect = sender.bounds
            actionsheet.popoverPresentationController?.permittedArrowDirections = .up
        default:
            break
        }
        
        // Restyle the view of the Alert
        actionsheet.view.tintColor = colorWithHexString (hex: "#333333")  // change text color of the buttons
        actionsheet.view.backgroundColor = colorWithHexString (hex: "#00CCFF")  // change background color
        actionsheet.view.layer.cornerRadius = 25
        
        self.present(actionsheet, animated: true, completion: nil)
    }
    
    @objc func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        dismiss(animated: true, completion: nil)
        
        let cropViewController = CropViewController(image: (info[.originalImage] as? UIImage)!)
        cropViewController.delegate = self
        cropViewController.modalPresentationStyle = .fullScreen
        present(cropViewController, animated: true, completion: nil)
    }
    
    func cropViewController(_ cropViewController: CropViewController, didCropToImage image: UIImage, withRect cropRect: CGRect, angle: Int) {
        // 'image' is the newly cropped version of the original image
        
        let pickedImageCount = PickedImageCountShared.pickedImageCountShared.count
        var imagePreviewXCord = CGFloat()
        var imagePreviewTag = Int(0)
        
        if(pickedImageCount == 0)
        {
            imagePreviewXCord = 0
            PickedImageCountShared.pickedImageCountShared.count = 1
            imagePreviewTag = 11
        }
        if(pickedImageCount! > 0)
        {
            imagePreviewXCord = 0
        }
        
        let imagePreview = UIImageView(frame: CGRect(x: imagePreviewXCord, y: 0, width: imagePreviewContainer.frame.size.width - 20, height: imagePreviewContainer.frame.size.width - 20))
        imagePreview.contentMode = .scaleAspectFit // OR .scaleAspectFill
        imagePreview.clipsToBounds = true
        imagePreview.layer.borderWidth = 0.5
        imagePreview.layer.borderColor = colorWithHexString(hex: "#DDDDDD").cgColor
        imagePreview.layer.cornerRadius = 5
        imagePreview.image = image
        imagePreview.tag = imagePreviewTag
        
        var image = UIImage.init(named: "close");
        let templateImage = image?.withRenderingMode(UIImage.RenderingMode.alwaysTemplate)
        image = templateImage
        
        let removeButton = UIButton(frame: CGRect(x: imagePreviewXCord + (imagePreview.frame.size.width - 30), y: 0, width: 30, height: 30))
        removeButton.backgroundColor = colorWithHexString(hex: "#FFFFFF")
        removeButton.tintColor = colorWithHexString(hex: "#00CCFF")
        removeButton.layer.cornerRadius = 15
        removeButton.tintColor = colorWithHexString(hex: "#00CCFF")
        removeButton.layer.masksToBounds = true
        
        removeButton.tag = imagePreviewTag * 100
        removeButton.setImage(image, for: UIControl.State.normal)
        removeButton.addTarget(self, action:#selector(removeImage), for:.touchUpInside)
        removeButton.addTarget(self, action:#selector(removeImage), for:.touchUpOutside)
        
        imagePreviewContainer.addSubview(imagePreview)
        imagePreviewContainer.addSubview(removeButton)
        dismiss(animated: true, completion: nil)
    }
    
    @objc func removeImage(sender: UIButton)
    {
        let pickedImageCount = PickedImageCountShared.pickedImageCountShared.count
        if(pickedImageCount == 1)
        {
            PickedImageCountShared.pickedImageCountShared.count = 0
        }
        
        let tag = sender.tag / 100
        if let viewWithTag = self.imagePreviewContainer.viewWithTag(tag) {
            viewWithTag.removeFromSuperview()
        }
        if let viewWithTag = self.imagePreviewContainer.viewWithTag(sender.tag) {
            viewWithTag.removeFromSuperview()
        }
    }
    
    @objc func removePDF(sender: UIButton)
    {
        if(PickedFileURLShared.pickedFileURLShared.url != nil)
        {
            PickedFileURLShared.pickedFileURLShared.url = nil
        }
        
        let tag = sender.tag / 100
        if let viewWithTag = self.imagePreviewContainer.viewWithTag(tag) {
            viewWithTag.removeFromSuperview()
        }
        if let viewWithTag = self.imagePreviewContainer.viewWithTag(sender.tag) {
            viewWithTag.removeFromSuperview()
        }
    }
    
    func documentPicker(){
        let importMenu = UIDocumentMenuViewController(documentTypes: [String(kUTTypePDF)], in: .import)
        importMenu.delegate = self
        importMenu.modalPresentationStyle = .formSheet
        self.present(importMenu, animated: true, completion: nil)
    }
    
    func openCamera()
    {
        PickedImageCountShared.pickedImageCountShared.count = 0
        PickedFileURLShared.pickedFileURLShared.url = nil
        
        if let viewWithTag = self.imagePreviewContainer.viewWithTag(11) {
            viewWithTag.removeFromSuperview()
        }
        if let viewWithTag = self.imagePreviewContainer.viewWithTag(1100) {
            viewWithTag.removeFromSuperview()
        }
        
        if let viewWithTag = self.imagePreviewContainer.viewWithTag(14) {
            viewWithTag.removeFromSuperview()
        }
        if let viewWithTag = self.imagePreviewContainer.viewWithTag(1400) {
            viewWithTag.removeFromSuperview()
        }
        
        if(UIImagePickerController .isSourceTypeAvailable(UIImagePickerController.SourceType.camera))
        {
            self.imageController = UIImagePickerController.init()
            self.imageController.sourceType = UIImagePickerController.SourceType.camera
            self.imageController.delegate = self
            self.imageController.allowsEditing = false
            self.imageController.modalPresentationStyle = .overCurrentContext
            self.present(imageController, animated: true, completion: nil)
        }
        else
        {
            let alert  = UIAlertController(title: self.defaultLocalizer.stringForKey(key: "actionSheetTitleWarning"), message: self.defaultLocalizer.stringForKey(key: "actionSheetMessageNoCamera"), preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: self.defaultLocalizer.stringForKey(key: "actionSheetTitleOK"), style: .default, handler: nil))
            self.present(alert, animated: true, completion: nil)
        }
    }
    
    func openGallary()
    {
        PickedImageCountShared.pickedImageCountShared.count = 0
        PickedFileURLShared.pickedFileURLShared.url = nil
        
        if let viewWithTag = self.imagePreviewContainer.viewWithTag(11) {
            viewWithTag.removeFromSuperview()
        }
        if let viewWithTag = self.imagePreviewContainer.viewWithTag(1100) {
            viewWithTag.removeFromSuperview()
        }
        
        if let viewWithTag = self.imagePreviewContainer.viewWithTag(14) {
            viewWithTag.removeFromSuperview()
        }
        if let viewWithTag = self.imagePreviewContainer.viewWithTag(1400) {
            viewWithTag.removeFromSuperview()
        }
        
        self.imageController = UIImagePickerController.init()
        self.imageController.sourceType = UIImagePickerController.SourceType.photoLibrary
        self.imageController.delegate = self
        self.imageController.allowsEditing = false
        self.imageController.modalPresentationStyle = .overCurrentContext
        self.present(imageController, animated: true, completion: nil)
    }
    
    func documentMenu(_ documentMenu: UIDocumentMenuViewController, didPickDocumentPicker documentPicker: UIDocumentPickerViewController) {
        documentPicker.delegate = self
        self.present(documentPicker, animated: true, completion: nil)
    }
    
    
    func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentAt url: URL) {
        PickedImageCountShared.pickedImageCountShared.count = 0
        PickedFileURLShared.pickedFileURLShared.url = nil
        
        if let viewWithTag = self.imagePreviewContainer.viewWithTag(11) {
            viewWithTag.removeFromSuperview()
        }
        if let viewWithTag = self.imagePreviewContainer.viewWithTag(1100) {
            viewWithTag.removeFromSuperview()
        }
        
        if let viewWithTag = self.imagePreviewContainer.viewWithTag(14) {
            viewWithTag.removeFromSuperview()
        }
        if let viewWithTag = self.imagePreviewContainer.viewWithTag(1400) {
            viewWithTag.removeFromSuperview()
        }
        
        PickedFileURLShared.pickedFileURLShared.url = url
        
        var pdfPreviewTag = Int(0)
        var pdfPreviewXCord = CGFloat()
        
        if(PickedFileURLShared.pickedFileURLShared.url != nil)
        {
            pdfPreviewXCord = 0
            pdfPreviewTag = 14
        }
        
        let removeButton = UIButton(frame: CGRect(x: pdfPreviewXCord + (imagePreviewContainer.frame.size.width - 90), y: 0, width: 30, height: 30))
        removeButton.backgroundColor = colorWithHexString(hex: "#FFFFFF")
        removeButton.tintColor = colorWithHexString(hex: "#00CCFF")
        removeButton.layer.cornerRadius = 15
        removeButton.tintColor = colorWithHexString(hex: "#00CCFF")
        removeButton.layer.masksToBounds = true
        
        var image = UIImage.init(named: "close");
        let templateImage = image?.withRenderingMode(UIImage.RenderingMode.alwaysTemplate)
        image = templateImage
        removeButton.tag = pdfPreviewTag * 100
        removeButton.setImage(image, for: UIControl.State.normal)
        removeButton.addTarget(self, action:#selector(removePDF), for:.touchUpInside)
        removeButton.addTarget(self, action:#selector(removePDF), for:.touchUpOutside)
        
        if #available(iOS 11.0, *) {
            let pdfView = PDFView(frame: CGRect(x: 50, y: 0, width: imagePreviewContainer.frame.width - 110, height: imagePreviewContainer.frame.width - 50))
            pdfView.tag = pdfPreviewTag
            //pdfView.translatesAutoresizingMaskIntoConstraints = false
            imagePreviewContainer.addSubview(pdfView)
            
            if let document = PDFDocument(url: PickedFileURLShared.pickedFileURLShared.url!) {
                pdfView.document = document
                pdfView.autoScales = true
                pdfView.maxScaleFactor = 4.0
                pdfView.minScaleFactor = pdfView.scaleFactorForSizeToFit
            }
        } else {
            // Fallback on earlier versions
            
            let webview = WKWebView(frame: CGRect(x: 50, y: 0, width: imagePreviewContainer.frame.width - 110, height: imagePreviewContainer.frame.width - 50))
            webview.tag = pdfPreviewTag
            webview.scrollView.isScrollEnabled = true
            webview.scrollView.bounces = true
            imagePreviewContainer.addSubview(webview)
            webview.navigationDelegate = self
            webview.load(URLRequest(url: PickedFileURLShared.pickedFileURLShared.url!))//URL(string: "http://") for web URL
        }
        
        imagePreviewContainer.addSubview(removeButton)
    }
    
    //    Method to handle cancel action.
    func documentPickerWasCancelled(_ controller: UIDocumentPickerViewController) {
        //self.dismiss(animated: true, completion: nil)
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
