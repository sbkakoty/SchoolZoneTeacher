//
//  ProfileViewController.swift
//  SchoolZoneTeacher
//
//  Created by Apple on 22/01/19.
//  Copyright © 2019 ClearWin Technologies. All rights reserved.
//

import UIKit
import MaterialComponents
import iOSDropDown
import SCLAlertView

class ProfileViewController: UIViewController {

    @IBOutlet weak var containerView: UIView!
    let defaultLocalizer = AMPLocalizeUtils.defaultLocalizer
    var headerView = UIView()
    var contentView = UIView()
    var profileImageButton = UIButton()
    var buttonEditProfile = UIButton()
    var textTeacherName = UILabel()
    var textUserType = UILabel()
    var labelName = UILabel()
    var textName = UILabel()
    var labelGender = UILabel()
    var textGender = UILabel()
    var labelDOB = UILabel()
    var textDOB = UILabel()
    var labelEmail = UILabel()
    var textEmail = UILabel()
    var labelMobile = UILabel()
    var textMobile = UILabel()
    var labelSchoolName = UILabel()
    var textSchoolName = UILabel()
    
    var response:Response?
    var teachers:[Teacher]?
    
    var editprofileVC: UIViewController!
    var imagePath: String!
    var teacherName: String!
    var dob: String!
    var gender: String!
    var email: String!
    var mobile: String!
    var schoolName: String!
    var schoolIds = [Int]()
    var schoolNames = [String]()
    var schoolid = Int()
    var teacherid = String()
    var dropDownSchool = DropDown()
    
    override func viewDidAppear(_ animated: Bool) {

        if #available(iOS 13, *)
        {
            let statusBar = UIView(frame: (UIApplication.shared.keyWindow?.windowScene?.statusBarManager?.statusBarFrame)!)
            statusBar.backgroundColor = colorWithHexString(hex: "#00CCFF")
            UIApplication.shared.keyWindow?.addSubview(statusBar)
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let schoolids = getSchoolIds()
        
        // Do any additional setup after loading the view.
        schoolIds.removeAll()
        schoolNames.removeAll()
        
        for id in schoolids
        {
            schoolIds.append(Int(id)!)
        }
        schoolNames = getSchoolNames()
        
        if(editprofileVC != nil)
        {
            editprofileVC.dismiss(animated: false, completion: nil)
        }
        if(getLanguage().count > 0)
        {
            defaultLocalizer.setSelectedLanguage(lang: getLanguage())
        }
        else
        {
            defaultLocalizer.setSelectedLanguage(lang: "en")
        }
        
        self.setNavigationBar()
        self.setProfileView()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        let teacherIds = getTeacherIds()
        self.loadProfileImage(schoolid: String(schoolIds[0]), teacherid: teacherIds[0])
    }
    
    func setDropdown(height: CGFloat, dropDown: DropDown, text: String, optionNames: [String], optionIds: [Int])
    {
        dropDown.placeholder = text;
        dropDown.textColor = UIColor.lightGray
        dropDown.backgroundColor = UIColor.white
        dropDown.rowBackgroundColor = UIColor.white;
        dropDown.borderWidth = 0.5
        dropDown.borderColor = colorWithHexString(hex: "#DDDDDD")
        dropDown.cornerRadius = 3
        dropDown.selectedRowColor = colorWithHexString(hex: "#DDDDDD");
        dropDown.arrowSize = 10;
        dropDown.isSearchEnable = false;
        // The list of array to display. Can be changed dynamically
        dropDown.optionArray = optionNames
        // Its Id Values and its optional
        dropDown.optionIds = optionIds
        dropDown.rowHeight = CGFloat(50)
        dropDown.listHeight = height
        
        dropDown.selectedIndex = self.schoolIds.firstIndex(of: Int(getSchoolId())!)
        dropDown.text = schoolNames[self.schoolIds.firstIndex(of: Int(getSchoolId())!)!]
    }
    
    func setProfileView(){
        self.headerView = UIView(frame: CGRect(x: 0, y: self.calculateTopDistance() - 1, width: self.view.frame.size.width, height: 130))
        self.headerView.backgroundColor = colorWithHexString(hex: "#00CCFF")
        
        self.profileImageButton = UIButton(frame: CGRect(x: (self.headerView.frame.size.width / 2) - 40, y: 0, width: 80, height: 80))
        self.profileImageButton.backgroundColor = UIColor.white
        self.profileImageButton.layer.cornerRadius = 40
        self.profileImageButton.tintColor = colorWithHexString(hex: "#00CCFF")
        self.profileImageButton.clipsToBounds = true
        self.profileImageButton.isUserInteractionEnabled = false
        
        self.buttonEditProfile = UIButton(frame: CGRect(x: self.headerView.frame.size.width - 50, y: 0, width: 40, height: 40))
        self.buttonEditProfile.backgroundColor = colorWithHexString(hex: "#FFFFFF")
        self.buttonEditProfile.tintColor = colorWithHexString(hex: "#00CCFF")
        self.textTeacherName = UILabel(frame: CGRect(x: 0, y: 80, width: self.view.frame.size.width, height: 23))
        self.textUserType = UILabel(frame: CGRect(x: 0, y: 103, width: self.view.frame.size.width, height: 23))
        self.textTeacherName.textColor = UIColor.white
        self.textUserType.textColor = UIColor.white
        self.textTeacherName.textAlignment = .center
        self.textUserType.textAlignment = .center
        
        self.headerView.addSubview(self.profileImageButton)
        self.headerView.addSubview(self.buttonEditProfile)
        self.headerView.addSubview(self.textTeacherName)
        self.headerView.addSubview(self.textUserType)
        self.containerView.addSubview(self.headerView)
        
        self.contentView = UIView(frame: CGRect(x: 10, y: self.calculateTopDistance() + 130, width: self.view.frame.size.width - 20, height: self.view.bounds.maxY))
        self.labelName = UILabel(frame: CGRect(x: 0, y: 5, width: self.contentView.frame.size.width, height: 20))
        self.labelName.text = defaultLocalizer.stringForKey(key: "labelTeacherName")
        self.labelName.textColor = UIColor.gray
        self.textName = UILabel(frame: CGRect(x: 0, y: 25, width: self.contentView.frame.size.width, height: 25))
        let separatorOne = UIView(frame: CGRect(x: 0, y: 51, width: self.contentView.frame.size.width, height: 1))
        separatorOne.backgroundColor = UIColor.groupTableViewBackground
        
        self.labelGender = UILabel(frame: CGRect(x: 0, y: 55, width: (self.contentView.frame.size.width / 2) - 20, height: 20))
        self.labelGender.text = defaultLocalizer.stringForKey(key: "labelGender")
        self.labelGender.textColor = UIColor.gray
        self.textGender = UILabel(frame: CGRect(x: 0, y: 75, width: (self.contentView.frame.size.width / 2) - 20, height: 25))
        
        self.labelDOB = UILabel(frame: CGRect(x: (self.contentView.frame.size.width / 2) + 10, y: 55, width: (self.contentView.frame.size.width / 2) - 20, height: 20))
        self.labelDOB.text = defaultLocalizer.stringForKey(key: "labelDOB")
        self.labelDOB.textColor = UIColor.gray
        self.textDOB = UILabel(frame: CGRect(x: (self.contentView.frame.size.width / 2) + 10, y: 75, width: (self.contentView.frame.size.width / 2) - 20, height: 25))
        
        let separatorTwo = UIView(frame: CGRect(x: 0, y: 101, width: self.contentView.frame.size.width, height: 1))
        separatorTwo.backgroundColor = UIColor.groupTableViewBackground
        let separatorThree = UIView(frame: CGRect(x: (self.contentView.frame.size.width / 2), y: 55, width: 1, height: 40))
        separatorThree.backgroundColor = UIColor.groupTableViewBackground
        
        self.labelEmail = UILabel(frame: CGRect(x: 0, y: 106, width: self.contentView.frame.size.width, height: 20))
        self.labelEmail.text = defaultLocalizer.stringForKey(key: "labelEmail")
        self.labelEmail.textColor = UIColor.gray
        self.textEmail = UILabel(frame: CGRect(x: 0, y: 126, width: self.contentView.frame.size.width, height: 20))
        
        let separatorFour = UIView(frame: CGRect(x: 0, y: 147, width: self.contentView.frame.size.width, height: 1))
        separatorFour.backgroundColor = UIColor.groupTableViewBackground
        
        self.labelMobile = UILabel(frame: CGRect(x: 0, y: 152, width: self.contentView.frame.size.width, height: 20))
        self.labelMobile.text = defaultLocalizer.stringForKey(key: "labelMobile")
        self.labelMobile.textColor = UIColor.gray
        self.textMobile = UILabel(frame: CGRect(x: 0, y: 172, width: self.contentView.frame.size.width, height: 20))
        
        let separatorFive = UIView(frame: CGRect(x: 0, y: 193, width: self.contentView.frame.size.width, height: 1))
        separatorFive.backgroundColor = UIColor.groupTableViewBackground
        
        self.labelSchoolName = UILabel(frame: CGRect(x: 0, y: 198, width: self.contentView.frame.size.width, height: 20))
        self.labelSchoolName.text = defaultLocalizer.stringForKey(key: "labelSchoolName")
        self.labelSchoolName.textColor = UIColor.gray
        //self.textSchoolName = UILabel(frame: CGRect(x: 0, y: 218, width: self.contentView.frame.size.width, height: 20))
        
        let scroolHeight = self.view.frame.size.height - (self.calculateTopDistance() + 48)
        self.dropDownSchool = DropDown(frame: CGRect(x: 0, y: 218, width: self.contentView.frame.size.width, height: 50))
        self.setDropdown(height: scroolHeight, dropDown: self.dropDownSchool, text: self.defaultLocalizer.stringForKey(key: "dropDownLabelSchool"), optionNames: schoolNames, optionIds: schoolIds)
        
        self.dropDownSchool.isEnabled = false
        
        // The the Closure returns Selected Index and String
        self.dropDownSchool.didSelect{(selectedText , index ,id) in
            self.dropDownSchool.textColor = UIColor.black
            self.schoolid = id
            let teacherIds = getTeacherIds()
            self.teacherid = teacherIds[index]
            
            self.loadProfile(schoolid: String(self.schoolIds[index]), teacherid: self.teacherid)
        }
        
        self.contentView.addSubview(self.labelName)
        self.contentView.addSubview(self.textName)
        self.contentView.addSubview(separatorOne)
        self.contentView.addSubview(self.labelGender)
        self.contentView.addSubview(self.textGender)
        self.contentView.addSubview(separatorThree)
        self.contentView.addSubview(self.labelDOB)
        self.contentView.addSubview(self.textDOB)
        self.contentView.addSubview(separatorTwo)
        self.contentView.addSubview(self.labelEmail)
        self.contentView.addSubview(self.textEmail)
        self.contentView.addSubview(self.labelMobile)
        self.contentView.addSubview(self.textMobile)
        self.contentView.addSubview(self.labelSchoolName)
        self.contentView.addSubview(self.dropDownSchool)
        //self.contentView.addSubview(self.textSchoolName)
        self.contentView.addSubview(separatorFour)
        self.contentView.addSubview(separatorFive)
        self.containerView.addSubview(self.contentView)
        
        if(teacherName.trimmingCharacters(in: .whitespaces).count > 0){
            self.textUserType.text = defaultLocalizer.stringForKey(key: "labelUserType")
            textTeacherName.text = teacherName
            textName.text = teacherName
            textDOB.text = dob
            textGender.text = gender
            textEmail.text = email
            textMobile.text = mobile
            textSchoolName.text = schoolName
            
            let imageView = UIImageView(frame: CGRect(x: 0, y: 0, width: 80, height: 80))
            imageView.image = UIImage()
            imageView.tag = 5
            self.profileImageButton.addSubview(imageView)
            
            var image = UIImage.init(named: "edit");
            let templateImage = image?.withRenderingMode(UIImage.RenderingMode.alwaysTemplate)
            image = templateImage
            self.buttonEditProfile.layer.cornerRadius = 20
            self.buttonEditProfile.tintColor = colorWithHexString(hex: "#00CCFF")
            self.buttonEditProfile.layer.masksToBounds = true
            self.buttonEditProfile.setImage(image, for: UIControl.State.normal)
            self.buttonEditProfile.addTarget(self, action:#selector(editProfile), for:.touchUpInside)
            self.buttonEditProfile.addTarget(self, action:#selector(editProfile), for:.touchUpOutside)
        }
    }
    
    func loadProfile(schoolid : String, teacherid: String)
    {
        setFirstName(firstName: "")
        setMiddleName(middleName: "")
        setLastName(lastName: "")
        setDOB(dob: "")
        setGender(gender: "")
        
        if var urlComponents = URLComponents(string: Constants.baseUrl + "getTeacherProfile") {
            
            urlComponents.query = "schoolid=" + schoolid + "&teacherid=" + teacherid
            // 3
            guard let url = urlComponents.url else { return }
            //print(url)
            getData(from: url) { data, response, error in
                if error != nil {
                    print(error!.localizedDescription)
                }
                guard let data = data else { return }
                //Implement JSON decoding and parsing
                do {
                    //Decode retrived data with JSONDecoder and assing type of Article object
                    let profileData = try JSONDecoder().decode(Result.self, from: data)
                    
                    self.response = profileData.Response
                    
                    if(self.response?.ResponseVal != 0)
                    {
                        self.teachers = profileData.Teachers
                        //dump(self.teachers)
                        var teacher: Teacher?
                        teacher = self.teachers?[0]
                        
                        //Get back to the main queue
                        DispatchQueue.main.async {
                            setSchoolId(schoolId: (teacher?.School_id)!)
                            setSchoolName(schoolName: (teacher?.School_Name)!)
                            setTeacherId(teacherId: (teacher?.TeacherID)!)
                            setFirstName(firstName: (teacher?.FirstName)!)
                            setMiddleName(middleName: (teacher?.MiddleName)!)
                            setLastName(lastName: (teacher?.LastName)!)
                            setEmail(email: (teacher?.Email)!)
                            setMobile(mobile: (teacher?.Mobile)!)
                            setDOB(dob: (teacher?.DOB)!)
                            setGender(gender: (teacher?.Gender)!)
                            //setLang(lang: (teacher?.Language)!)
                            setProfileImage(profileImage: (teacher?.ProfileImage)!)
                            setSchoolLogo(logoImage: (teacher?.SchoolLogo)!)
                            
                            let fname = getFirstName() + " "
                            let mname = getMiddleName().count > 0 ? getMiddleName() + " " : ""
                            let lname = getLastName()
                            let fullname = fname + mname + lname
                            self.textTeacherName.text = fullname
                            self.textName.text = fullname
                            self.textDOB.text = (teacher?.DOB)!
                            self.textGender.text = (teacher?.Gender)!
                            self.textEmail.text = (teacher?.Email)!
                            self.textMobile.text = (teacher?.Mobile)!
                            
                            if let url = URL(string: (teacher?.ProfileImage)!) {
                                getImageData(from: url) { data, response, error in
                                    guard let data = data, error == nil else { return }
                                    //print(response)
                                    DispatchQueue.main.async() {
                                        let imageView = UIImageView(frame: CGRect(x: 0, y: 0, width: 80, height: 80))
                                        imageView.image = UIImage(data: data)
                                        imageView.tag = 5
                                        self.profileImageButton.addSubview(imageView)
                                    }
                                }
                            }
                        }
                    }
                    
                } catch let jsonError {
                    print(jsonError)
                }
            }
        }
    }
    
    func loadProfileImage(schoolid : String, teacherid: String)
    {
        if var urlComponents = URLComponents(string: Constants.baseUrl + "getTeacherProfile") {
            
            urlComponents.query = "schoolid=" + schoolid + "&teacherid=" + teacherid
            // 3
            guard let url = urlComponents.url else { return }
            
            getData(from: url) { data, response, error in
                if error != nil {
                    print(error!.localizedDescription)
                }
                guard let data = data else { return }
                //Implement JSON decoding and parsing
                do {
                    //Decode retrived data with JSONDecoder and assing type of Article object
                    let profileData = try JSONDecoder().decode(Result.self, from: data)
                    
                    self.response = profileData.Response
                    
                    if(self.response?.ResponseVal != 0)
                    {
                        self.teachers = profileData.Teachers
                        //dump(self.teachers)
                        var teacher: Teacher?
                        teacher = self.teachers?[0]
                        
                        setProfileImage(profileImage: (teacher?.ProfileImage)!)
                        
                        //Get back to the main queue
                        DispatchQueue.main.async {
                            
                            if let url = URL(string: (teacher?.ProfileImage)!) {
                                getImageData(from: url) { data, response, error in
                                    if error != nil {
                                        print(error!.localizedDescription)
                                    }
                                    
                                    guard let data = data else { return}
                                    
                                    //print(response)
                                    DispatchQueue.main.async() {
                                        let imageView = UIImageView(frame: CGRect(x: 0, y: 0, width: 80, height: 80))
                                        imageView.image = UIImage(data: data)
                                        imageView.tag = 5
                                        self.profileImageButton.addSubview(imageView)
                                    }
                                }
                            }
                        }
                    }
                    
                } catch let jsonError {
                    print(jsonError)
                }
            }
        }
    }
    
    func calculateTopDistance () -> CGFloat{
        let statusBarHeight = UIApplication.shared.isStatusBarHidden ? CGFloat(0) : UIApplication.shared.statusBarFrame.height
        return statusBarHeight + 45
    }
    
    @objc func editProfile()
    {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "vcUpdateProfile") as! UpdateProfileViewController;()
        vc.modalPresentationStyle = .fullScreen
        let fname = getFirstName() + " "
        let mname = getMiddleName().count > 0 ? getMiddleName() + " " : ""
        let lname = getLastName()
        let fullname = fname + mname + lname
        vc.teacherName = fullname
        vc.email = getEmail()
        vc.mobile = getMobile()
        vc.dob = getDOB()
        vc.gender = getGender()
        vc.imagePath = getProfileImage()
        vc.viewProfileVC = self
        
        present(vc, animated: false, completion: nil)
        CFRunLoopWakeUp(CFRunLoopGetCurrent())
    }
    
    func setNavigationBar() {
        let navigationFont = UIFont(name: "Helvetica", size: getTitleFontSize())
        let screenSize: CGRect = UIScreen.main.bounds;
        let statusBarHeight = UIApplication.shared.isStatusBarHidden ? CGFloat(0) : UIApplication.shared.statusBarFrame.height
        let navBar: UINavigationBar = UINavigationBar(frame: CGRect(x: 0, y: statusBarHeight, width: screenSize.width, height: 44))
        self.view.addSubview(navBar);
        
        let navItem = UINavigationItem(title: defaultLocalizer.stringForKey(key: "navBarTitleViewProfile"));
        let button = UIButton.init(type: .custom)
        button.setTitle(defaultLocalizer.stringForKey(key: "navBarButtonBack"), for: UIControl.State.normal)
        var image = UIImage.init(named: "back");
        let templateImage = image?.withRenderingMode(UIImage.RenderingMode.alwaysTemplate)
        image = templateImage
        button.setImage(image, for: UIControl.State.normal)
        button.addTarget(self, action:#selector(back), for:.touchUpInside)
        button.addTarget(self, action:#selector(back), for:.touchUpOutside)
        button.frame = CGRect.init(x: 0, y: 0, width: 60, height: 44) //CGRectMake(0, 0, 30, 30)
        let doneItem = UIBarButtonItem.init(customView: button)
        
        //let doneItem = UIBarButtonItem(title: "Back", style: .plain, target: self, action: #selector(back))
        navItem.leftBarButtonItem = doneItem;
        
        navBar.setItems([navItem], animated: false);
        navBar.backgroundColor = colorWithHexString(hex: "#00CCFF");
        navBar.isTranslucent = false;
        navBar.titleTextAttributes = [
            NSAttributedString.Key.foregroundColor : UIColor.white, NSAttributedString.Key.font: navigationFont!, NSAttributedString.Key.shadow: setNavBarTitleShadow()
        ]
        
        if #available(iOS 11, *){
            navBar.titleTextAttributes = [NSAttributedString.Key.foregroundColor: UIColor.white, NSAttributedString.Key.font: navigationFont!, NSAttributedString.Key.shadow: setNavBarTitleShadow()]
        }
    }
    
    @objc func back() { // remove @objc for Swift 3
        
        self.dismiss(animated: false, completion: nil)
    }
    
    func position(for bar: UIBarPositioning) -> UIBarPosition {
        return .topAttached
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
