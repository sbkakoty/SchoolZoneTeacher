//
//  BreakingNewsDetailsViewController.swift
//  SchoolZoneTeacher
//
//  Created by Apple on 05/12/19.
//  Copyright © 2019 ClearWin Technologies. All rights reserved.
//

import UIKit
import Lightbox
import WebKit

class BreakingNewsDetailsViewController: UIViewController, LightboxControllerPageDelegate, LightboxControllerDismissalDelegate, WKNavigationDelegate {
    
    let defaultLocalizer = AMPLocalizeUtils.defaultLocalizer
    
    @IBOutlet weak var container: UIView!
    @IBOutlet weak var webViewContainer: UIView!
    @IBOutlet weak var cardImage: UIImageView!
    @IBOutlet weak var textTitle: UILabel!
    @IBOutlet weak var labelAuthor: UILabel!
    @IBOutlet weak var txtAuthor: UILabel!
    
    @IBOutlet weak var txtDate: UILabel!
    @IBOutlet weak var labelDesc: UILabel!
    @IBOutlet weak var labelDate: UILabel!
    
    var iWebView: WKWebView!
    var activityView: UIActivityIndicatorView!
    
    var newsID:String!
    var imagePath:String!
    var newsTitle:String!
    var newsAuthor:String!
    var newsDate:String!
    var newsDesc:String!
    
    override func viewDidAppear(_ animated: Bool) {
        
        container.layer.borderWidth = 0.5
        container.layer.cornerRadius = 3.0
        container.layer.borderColor = colorWithHexString(hex: "#DDDDDD").cgColor
        container.layer.shadowColor = UIColor.lightGray.cgColor
        container.layer.shadowOffset = CGSize(width: 3, height: 3)
        container.layer.shadowOpacity = 0.5
        
        let dateFormatterGet = DateFormatter()
        dateFormatterGet.dateFormat = "dd-MM-yyyy"
        
        self.labelAuthor.text = self.defaultLocalizer.stringForKey(key: "labelAuthor")
        self.labelDate.text = self.defaultLocalizer.stringForKey(key: "labelPublishDate")
        self.labelDesc.text = self.defaultLocalizer.stringForKey(key: "labelDesc")
        self.textTitle.text = newsTitle
        self.txtDate.text = newsDate
        self.txtAuthor.text = newsAuthor
        
        if let url = URL(string: imagePath!) {
            getImageData(from: url) { data, response, error in
                guard let data = data, error == nil else {
                    return
                }
                DispatchQueue.main.async() {
                    self.cardImage.image = UIImage(data: data)
                }
            }
        }
        
        self.iWebView = WKWebView(frame: self.webViewContainer.frame)
        self.webViewContainer.addSubview(self.iWebView)
        
        self.iWebView.translatesAutoresizingMaskIntoConstraints = false
        self.iWebView.centerXAnchor.constraint(equalTo: self.webViewContainer.centerXAnchor).isActive = true
        self.iWebView.centerYAnchor.constraint(equalTo: self.webViewContainer.centerYAnchor).isActive = true
        self.iWebView.widthAnchor.constraint(equalToConstant: self.webViewContainer.bounds.width).isActive = true
        self.iWebView.heightAnchor.constraint(equalToConstant: self.webViewContainer.bounds.height).isActive = true
        
        self.iWebView.navigationDelegate = self
        //iWebView.navigationDelegate = self
        var headerString = "<!DOCTYPE html><html lang='en'><head><meta name='viewport' content='width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0'></head><body>"
        headerString.append(newsDesc)
        headerString.append("</body></html>")
        
        DispatchQueue.main.async() {
            
            self.iWebView.loadHTMLString(self.updateDataWithFont(data:headerString), baseURL: nil)
        }
        // add activity
        activityView = UIActivityIndicatorView(style: .gray)
        activityView.center = self.iWebView.center
        activityView.startAnimating()
        self.view.addSubview(activityView)
        activityView.hidesWhenStopped = true
        
        self.addReadNews()
    }
    
    func calculateTopDistance () -> CGFloat{
        if(self.navigationController != nil && !self.navigationController!.navigationBar.isTranslucent){
            return 0
        }else{
            let barHeight=self.navigationController?.navigationBar.frame.height ?? 0
            let statusBarHeight = UIApplication.shared.isStatusBarHidden ? CGFloat(0) : UIApplication.shared.statusBarFrame.height
            return barHeight + statusBarHeight
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        if(getLanguage().count > 0)
        {
            defaultLocalizer.setSelectedLanguage(lang: getLanguage())
        }
        else
        {
            defaultLocalizer.setSelectedLanguage(lang: "en")
        }
        
        self.setNavigationBar()
    }
    
    func setNavigationBar() {
        let navigationFont = UIFont(name: "Helvetica", size: getTitleFontSize())
        let screenSize: CGRect = UIScreen.main.bounds
        let statusBarHeight = UIApplication.shared.isStatusBarHidden ? CGFloat(0) : UIApplication.shared.statusBarFrame.height
        let navBar: UINavigationBar = UINavigationBar(frame: CGRect(x: 0, y: statusBarHeight, width: screenSize.width, height: 44))
        self.view.addSubview(navBar)
        
        let navItem = UINavigationItem(title: self.defaultLocalizer.stringForKey(key: "labelBreakingNewsDetails"))
        let button = UIButton(type: .custom)
        button.setTitle(self.defaultLocalizer.stringForKey(key: "navBarButtonBack"), for: UIControl.State.normal)
        var image = UIImage(named: "back")
        let templateImage = image?.withRenderingMode(UIImage.RenderingMode.alwaysTemplate)
        image = templateImage
        button.setImage(image, for: UIControl.State.normal)
        button.addTarget(self, action:#selector(back), for:.touchUpInside)
        //button.addTarget(self, action:#selector(back), for:.touchUpOutside)
        button.frame = CGRect(x: 0, y: 0, width: 20, height: 20) //CGRectMake(0, 0, 30, 30)
        let doneItem = UIBarButtonItem(customView: button)
        
        //let doneItem = UIBarButtonItem(title: "Back", style: .plain, target: self, action: #selector(back))
        navItem.leftBarButtonItem = doneItem
        
        navBar.setItems([navItem], animated: false)
        navBar.backgroundColor = colorWithHexString(hex: "#00CCFF")
        navBar.isTranslucent = false
        navBar.titleTextAttributes = [
            NSAttributedString.Key.foregroundColor : UIColor.white, NSAttributedString.Key.font: navigationFont!, NSAttributedString.Key.shadow: setNavBarTitleShadow()
        ]
        
        if #available(iOS 11, *){
            navBar.titleTextAttributes = [NSAttributedString.Key.foregroundColor: UIColor.white, NSAttributedString.Key.font: navigationFont!, NSAttributedString.Key.shadow: setNavBarTitleShadow()]
        }
    }
    
    deinit {
        print("deinit")
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @objc func back() {
        
        self.iWebView.removeFromSuperview()
        presentingViewController?.dismiss(animated: true)
        //self.dismiss(animated:true, completion: nil)
    }
    
    func addReadNews(){
        
        let teacherid = getTeacherId()
        let schoolid = getSchoolId()
        
        let queryString = "breaking_news_id=\(self.newsID!)&school_id=\(schoolid)&parent_id=&teacher_id=\(teacherid)"
        
        //print("addReadEvents URL: \(queryString)")
        
        if var urlComponents = URLComponents(string: Constants.baseUrl + "AddBreakingNewsRead") {
            urlComponents.query = queryString
            // 3
            guard let url = urlComponents.url else { return}
            
            var request = URLRequest(url: url)
            request.httpMethod = "POST"
            
            postData(from: request) { data, response, error in
                if let httpStatus = response as? HTTPURLResponse, httpStatus.statusCode != 200 {
                    //let responseMessage = String(describing: response)
                    
                    return
                }
                //let responseMessage = String(describing: response)
                
                //print("AddBreakingNewsRead Response: \(responseMessage)")
            }
        }
    }
    
    func webView(_ webView: WKWebView, didFinish navigation:
        WKNavigation!) {
        self.activityView.stopAnimating()
    }
    
    func webView(_ webView: WKWebView, didStartProvisionalNavigation
        navigation: WKNavigation!) {
        self.activityView.startAnimating()
    }
    
    func webView(_ webView: WKWebView, didFail navigation:
        WKNavigation!, withError error: Error) {
        self.activityView.stopAnimating()
    }
    
    func updateDataWithFont(data:String)->String{
        return String(format: "<html><body><span style=\"font-family:%@;font-size:%@;text-align:justify\">%@</span></body></html>","Helvetica","12px",data)
    }
    
    func getImageData(from url: URL, completion: @escaping (Data?, URLResponse?, Error?) -> ()) {
        URLSession.shared.dataTask(with: url, completionHandler: completion).resume()
    }
    
    @objc func zoomImage(_ sender: UITapGestureRecognizer)
    {
        //print("zoomImageTap")
        let images = [LightboxImage(imageURL: URL(string: imagePath)!)]
        
        // Create an instance of LightboxController.
        let controller = LightboxController(images: images)
        
        // Set delegates.
        controller.pageDelegate = self
        controller.dismissalDelegate = self
        
        // Use dynamic background.
        controller.dynamicBackground = true
        controller.modalPresentationStyle = .fullScreen
        // Present your controller.
        present(controller, animated: true, completion: nil)
    }
    
    func position(for bar: UIBarPositioning) -> UIBarPosition {
        return .topAttached
    }
    
    func lightboxControllerWillDismiss(_ controller: LightboxController) {
        
    }
    
    func lightboxController(_ controller: LightboxController, didMoveToPage page: Int) {
        
    }
    
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destination.
     // Pass the selected object to the new view controller.
     }
     */
    
}
