//
//  EventsViewController.swift
//  SchoolZoneTeacher
//
//  Created by Apple on 26/02/19.
//  Copyright © 2019 ClearWin Technologies. All rights reserved.
//

import UIKit
import MaterialComponents
import iOSDropDown
import SCLAlertView
import Alamofire

class EventsViewController: UIViewController, UITableViewDelegate, UITableViewDataSource, UISearchBarDelegate {
    
    let defaultLocalizer = AMPLocalizeUtils.defaultLocalizer
    let activityIndicator = MDCActivityIndicator()
    var popoverVC: UIViewController!
    var result:Result?
    var events:[Event]?
    var response:Response?
    var sections = [Section]()
    
    var searchBar = UISearchBar()
    var searchActive : Bool = false
    var filtered:[Event] = []
    var tableView = UITableView()
    var refreshControl = UIRefreshControl()
    
    var dataCache = NSCache<AnyObject, AnyObject>()
    
    let appearance = SCLAlertView.SCLAppearance(
        kTitleFont: UIFont(name: "HelveticaNeue", size: 20)!,
        kTextFont: UIFont(name: "HelveticaNeue", size: 14)!,
        kButtonFont: UIFont(name: "HelveticaNeue-Bold", size: 14)!
    )
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        if(popoverVC != nil)
        {
            popoverVC.dismiss(animated: false, completion: nil)
        }
        
        if(getLanguage().count > 0)
        {
            defaultLocalizer.setSelectedLanguage(lang: getLanguage())
        }
        else
        {
            defaultLocalizer.setSelectedLanguage(lang: "en")
        }
        
        self.setNavigationBar()
        self.loadEventsView()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        self.getEvents()
    }
    
    func setNavigationBar() {
        let navigationFont = UIFont(name: "Helvetica", size: getTitleFontSize())
        let button = UIButton.init(type: .custom)
        button.setTitle(self.defaultLocalizer.stringForKey(key: "navBarButtonBack"), for: UIControl.State.normal)
        var image = UIImage.init(named: "back")
        let templateImage = image?.withRenderingMode(UIImage.RenderingMode.alwaysTemplate)
        image = templateImage
        button.setImage(image, for: UIControl.State.normal)
        button.addTarget(self, action:#selector(back), for:.touchUpInside)
        button.addTarget(self, action:#selector(back), for:.touchUpOutside)
        button.frame = CGRect.init(x: 0, y: 0, width: 20, height: 20) //CGRectMake(0, 0, 30, 30)
        let doneItem = UIBarButtonItem.init(customView: button)
        self.navigationItem.leftBarButtonItem = doneItem
        
        let width = self.view.frame.width - 60
        let height = CGFloat(44)
        
        let titleLabel = UILabel(frame: CGRect.init(x: 0, y: 0, width: width, height: height))
        titleLabel.text = self.defaultLocalizer.stringForKey(key: "navBarTitleEvents")
        titleLabel.textAlignment = .center
        titleLabel.font = navigationFont
        titleLabel.textColor = .white
        titleLabel.sizeToFit()
        
        self.navigationItem.titleView = titleLabel
    }
    
    @objc func back() { // remove @objc for Swift 3
        AppLoadingStatus.appLoadingStatus.status = "Redirect"
        
        let vcLandingPage = self.storyboard!.instantiateViewController(withIdentifier: "vcRoot") as! RootViewController
        
        vcLandingPage.statusBarShouldBeHidden = false
        self.setNeedsStatusBarAppearanceUpdate()
        
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        appDelegate.window?.rootViewController = vcLandingPage
    }
    
    func position(for bar: UIBarPositioning) -> UIBarPosition {
        return .topAttached
    }
    
    func calculateTopDistance () -> CGFloat{
        if(self.navigationController != nil && !self.navigationController!.navigationBar.isTranslucent){
            return 0
        }else{
            let barHeight=self.navigationController?.navigationBar.frame.height ?? 0
            let statusBarHeight = UIApplication.shared.isStatusBarHidden ? CGFloat(0) : UIApplication.shared.statusBarFrame.height
            return barHeight + statusBarHeight
        }
    }
    
    func loadEventsView() {
        //Set wanted position and size (frame)
        let tabbarHeight = getTabbarHeight()
        let scroolHeight = self.view.frame.size.height - (self.calculateTopDistance() + tabbarHeight)
        
        let eventsView = UIView(frame: CGRect(x: 0, y: self.calculateTopDistance() + 5, width: self.view.frame.size.width, height: scroolHeight))
        eventsView.tag = 100
        
        //init toolbar
        let toolbar:UIToolbar = UIToolbar(frame: CGRect(x: 0, y: 0,  width: self.view.frame.size.width, height: 30))
        //create left side empty space so that done button set on right side
        let flexSpace = UIBarButtonItem(barButtonSystemItem:    .flexibleSpace, target: nil, action: nil)
        let doneBtn: UIBarButtonItem = UIBarButtonItem(title: self.defaultLocalizer.stringForKey(key: "toolBarButtonTitleDone"), style: .done, target: self, action: #selector(doneButtonAction))
        toolbar.setItems([flexSpace, doneBtn], animated: false)
        toolbar.sizeToFit()
        
        self.searchBar = UISearchBar(frame: CGRect(x: 0, y: 0, width: eventsView.frame.size.width, height: 40))
        self.searchBar.searchBarStyle = UISearchBar.Style.prominent
        self.searchBar.placeholder = self.defaultLocalizer.stringForKey(key: "placeHolderSearchEvent")
        self.searchBar.barTintColor = UIColor.white
        self.searchBar.delegate = self
        self.searchBar.layer.borderWidth = 1
        self.searchBar.layer.borderColor = UIColor.white.cgColor
        //setting toolbar as inputAccessoryView
        self.searchBar.inputAccessoryView = toolbar
        
        self.tableView = UITableView(frame: CGRect(x: 0, y: 0, width: self.view.frame.size.width, height: scroolHeight), style: UITableView.Style.plain)
        self.tableView.dataSource = self
        self.tableView.delegate = self
        self.tableView.register(UINib(nibName: "EventsTableViewCell", bundle: nil), forCellReuseIdentifier: "EventsCell")
        self.tableView.rowHeight = 75.0// UITableView.automaticDimension
        self.tableView.estimatedRowHeight = 75.0
        self.tableView.separatorStyle = .none
        self.tableView.tableHeaderView = self.searchBar
        self.refreshControl.addTarget(self, action: #selector(refreshTable), for: .valueChanged)
        
        //Setup pull to refresh
        if #available(iOS 10.0, *) {
            self.tableView.refreshControl = refreshControl
        } else {
            // Fallback on earlier versions
            self.tableView.addSubview(refreshControl)
        }
        
        self.removeSubView()
        eventsView.insertSubview(tableView, at: 0)
        //eventsView.insertSubview(searchBar, at: 1)
        
        //Add the view
        self.view.addSubview(eventsView)
        
        //self.view.addSubview(scrollView)
        self.activityIndicator.sizeToFit()
        self.activityIndicator.center.x = super.view.center.x
        self.activityIndicator.center.y = (super.view.center.y - 50)
        self.view.addSubview(activityIndicator)
    }
    
    @objc func doneButtonAction() {
        self.view.endEditing(true)
    }
    
    func searchBarTextDidBeginEditing(_ searchBar: UISearchBar) {
        self.searchActive = true
    }
    
    func searchBarTextDidEndEditing(_ searchBar: UISearchBar) {
        self.searchActive = false
    }
    
    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
        self.searchActive = false
    }
    
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        self.searchActive = false
    }
    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        filtered = events!.filter({
            return $0.EventTitle.range(of: searchText, options: .caseInsensitive) != nil
        })
        
        if(filtered.count == 0){
            self.searchActive = false
        }
        else
        {
            self.searchActive = true
        }
        self.tableView.reloadData()
    }
    
    @objc func getEvents()
    {
        // To make the activity indicator appear:
        self.activityIndicator.startAnimating()
        
        if let viewWithTag = self.view.viewWithTag(7575) {
            viewWithTag.removeFromSuperview()
        }
        
        let schoolid = getSchoolId()
        let alertView = SCLAlertView(appearance: self.appearance)
        
        let formatter = DateFormatter()
        formatter.dateFormat = "dd-MM-yyyy"
        
        let currentDateString = formatter.string(from: Date())
        
        if var urlComponents = URLComponents(string: Constants.baseUrl + "getEvents") {
            
            urlComponents.query = "schoolid=" + schoolid + "&currentdate=" + currentDateString
            //urlComponents.query = "schoolid=" + schoolid + "&currentdate=" + currentDateString
            // 3
            guard let url = urlComponents.url else { return }
            
            //print(url)
            
            getData(from: url) { data, response, error in
                if error != nil {
                    DispatchQueue.main.async {
                        
                        self.activityIndicator.stopAnimating()
                        alertView.showInfo("OurSchoolZone", subTitle: self.defaultLocalizer.stringForKey(key: "allertMessageFetchdataError"), closeButtonTitle: self.defaultLocalizer.stringForKey(key: "actionSheetTitleOK"))
                    }
                    print(error!.localizedDescription)
                }
                guard let data = data else { return }
                //Implement JSON decoding and parsing
                do {
                    //Decode retrived data with JSONDecoder and assing type of Article object
                    let eventsData = try JSONDecoder().decode(Result.self, from: data)
                    
                    self.events = eventsData.Events
                    self.response = eventsData.Response
                    
                    self.activityIndicator.stopAnimating()
                    
                    if(self.response?.ResponseVal == 0)
                    {
                        //Get back to the main queue
                        DispatchQueue.main.async {
                            self.displayAlertMessage()
                            self.searchBar.isHidden = true
                        }
                    }
                    else{
                        if let viewWithTag = self.view.viewWithTag(7575) {
                            viewWithTag.removeFromSuperview()
                        }
                        //Get back to the main queue
                        DispatchQueue.main.async {
                            
                            self.tableView.reloadData()
                        }
                    }
                    
                } catch let jsonError {
                    self.activityIndicator.stopAnimating()
                    print(jsonError)
                }
                
                
            }
        }
    }
    
    @objc func refreshTable()
    {
        refreshControl.endRefreshing()
        self.getEvents()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "vcEvenDetails") as! EventDetailsViewController;()
        vc.modalPresentationStyle = .fullScreen
        let eventModel = events?[indexPath.row]
        
        vc.eventID = eventModel?.id
        vc.eventTitle = eventModel?.EventTitle
        vc.eventStartDate = (eventModel?.EventStartDate)!
        vc.eventEndDate = (eventModel?.EventEndDate)!
        vc.imagePath = eventModel?.EventThumbnail
        vc.eventDesc = eventModel?.EventDescription
        vc.eventLocation = eventModel?.EventLocation
        
        self.navigationController?.pushViewController(vc, animated: false)
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "EventsCell") as! EventsTableViewCell
        
        var eventModel:Event?
        if(searchActive == true && filtered.count > 0){
            eventModel = filtered[indexPath.row]
        } else {
            eventModel = events?[indexPath.row]
        }
        
        cell.labelEvents?.text = eventModel?.EventTitle
        cell.labelStartDate?.text = self.defaultLocalizer.stringForKey(key: "labelStartDate") + ": " + (eventModel?.EventStartDate)!
        cell.labelEndDate?.text = self.defaultLocalizer.stringForKey(key: "labelEndDate") + ": " + (eventModel?.EventEndDate)!
        
        /*let inputFormatter = DateFormatter()
        inputFormatter.dateFormat = "dd-MM-yyyy h:mm:ss a"
        
        if let startDate = inputFormatter.date(from: (eventModel?.EventStartDate)!) {
            let outputFormatter = DateFormatter()
            outputFormatter.dateFormat = "dd-MM-yyyy h:mm a"
            outputFormatter.amSymbol = "AM"
            outputFormatter.pmSymbol = "PM"
            cell.labelStartDate?.text = "Start: " + outputFormatter.string(from: startDate)
        }
        
        if let endDate = inputFormatter.date(from: (eventModel?.EventEndDate)!) {
            let outputFormatter = DateFormatter()
            outputFormatter.dateFormat = "dd-MM-yyyy h:mm a"
            outputFormatter.amSymbol = "AM"
            outputFormatter.pmSymbol = "PM"
            cell.labelEndDate?.text = "End: " + outputFormatter.string(from: endDate)
        }*/
        
        cell.EventThumbnail.image = nil
        let id = eventModel?.id
        cell.tag = indexPath.row
            
        if((eventModel?.EventThumbnail)!.count > 0){
            if(cell.tag == indexPath.row) {
                if let dataFromCache = dataCache.object(forKey: id as AnyObject) as? Data{
                    
                    cell.EventThumbnail.image = UIImage(data: dataFromCache)
                }
                else
                {
                    Alamofire.request((eventModel?.EventThumbnail)!, method: .get).response { (responseData) in
                        if let data = responseData.data {
                            DispatchQueue.main.async {
                                self.dataCache.setObject(data as AnyObject, forKey: id as AnyObject)
                                cell.EventThumbnail.image = UIImage(data: data)
                            }
                        }
                    }
                }
            }
        }
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        var count = 0
        if(searchActive) {
            return filtered.count
        }
        count = events?.count ?? 0
        
        return count
    }
    
    func removeSubView()
    {
        
        if let viewWithTag = self.view.viewWithTag(100) {
            viewWithTag.removeFromSuperview()
        }
        if let viewWithTag = self.view.viewWithTag(7575) {
            viewWithTag.removeFromSuperview()
        }
    }
    
    func displayAlertMessage()
    {
        let imageview = UIImageView(frame: CGRect(x: ((self.view.frame.size.width / 2) - 50), y: ((self.view.frame.size.height / 2) - 74), width: 100, height: 100))
        imageview.image = UIImage(named: "norecordfound")
        imageview.contentMode = UIView.ContentMode.scaleAspectFit
        imageview.layer.masksToBounds = true
        imageview.tag = 7575
        self.view.addSubview(imageview)
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
