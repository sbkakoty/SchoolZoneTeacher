//
//  NewsViewController.swift
//  SchoolZoneTeacher
//
//  Created by Apple on 14/12/18.
//  Copyright © 2018 ClearWin Technologies. All rights reserved.
//

import UIKit
import MaterialComponents
import iOSDropDown
import SCLAlertView
import Alamofire

class NewsViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    let defaultLocalizer = AMPLocalizeUtils.defaultLocalizer
    let activityIndicator = MDCActivityIndicator()
    var result:Result?
    var news:[News]?
    var response:Response?
    var sections = [Section]()
    
    var tableView = UITableView()
    var refreshControl = UIRefreshControl()
    
    var dataCache = NSCache<AnyObject, AnyObject>()
    
    let appearance = SCLAlertView.SCLAppearance(
        kTitleFont: UIFont(name: "HelveticaNeue", size: 20)!,
        kTextFont: UIFont(name: "HelveticaNeue", size: 14)!,
        kButtonFont: UIFont(name: "HelveticaNeue-Bold", size: 14)!
    )
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        self.getNews()
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        
        if(getLanguage().count > 0)
        {
            defaultLocalizer.setSelectedLanguage(lang: getLanguage())
        }
        else
        {
            defaultLocalizer.setSelectedLanguage(lang: "en")
        }
        
        self.setNavigationBar()
        self.loadNewsView()
    }
    
    func setNavigationBar() {
        let navigationFont = UIFont(name: "Helvetica", size: getTitleFontSize())
        
        let button = UIButton.init(type: .custom)
        button.setTitle(self.defaultLocalizer.stringForKey(key: "navBarButtonBack"), for: UIControl.State.normal)
        var image = UIImage.init(named: "back")
        let templateImage = image?.withRenderingMode(UIImage.RenderingMode.alwaysTemplate)
        image = templateImage
        button.setImage(image, for: UIControl.State.normal)
        button.addTarget(self, action:#selector(back), for:.touchUpInside)
        button.addTarget(self, action:#selector(back), for:.touchUpOutside)
        button.frame = CGRect.init(x: 0, y: 0, width: 20, height: 20) //CGRectMake(0, 0, 30, 30)
        let doneItem = UIBarButtonItem.init(customView: button)
        self.navigationItem.leftBarButtonItem = doneItem
        
        let width = self.view.frame.width - 60
        let height = CGFloat(44)
        
        let titleLabel = UILabel(frame: CGRect.init(x: 0, y: 0, width: width, height: height))
        titleLabel.text = self.defaultLocalizer.stringForKey(key: "navBarTitleNews")
        titleLabel.textAlignment = .center
        titleLabel.font = navigationFont
        titleLabel.textColor = .white
        titleLabel.sizeToFit()
        self.navigationItem.titleView = titleLabel
    }
    
    @objc func back() { // remove @objc for Swift 3
        AppLoadingStatus.appLoadingStatus.status = "Redirect"
        
        let vcLandingPage = self.storyboard!.instantiateViewController(withIdentifier: "vcRoot") as! RootViewController
        
        vcLandingPage.statusBarShouldBeHidden = false
        self.setNeedsStatusBarAppearanceUpdate()
        
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        appDelegate.window?.rootViewController = vcLandingPage
    }
    
    func position(for bar: UIBarPositioning) -> UIBarPosition {
        return .topAttached
    }
    
    func calculateTopDistance () -> CGFloat{
        if(self.navigationController != nil && !self.navigationController!.navigationBar.isTranslucent){
            return 0
        }else{
            let barHeight=self.navigationController?.navigationBar.frame.height ?? 0
            let statusBarHeight = UIApplication.shared.isStatusBarHidden ? CGFloat(0) : UIApplication.shared.statusBarFrame.height
            return barHeight + statusBarHeight
        }
    }
    
    func loadNewsView() {
        //Set wanted position and size (frame)
        let tabbarHeight = getTabbarHeight()
        var scroolHeight = self.view.frame.size.height - (self.calculateTopDistance() + tabbarHeight) - 65
        
        if(tabbarHeight == 83){
            scroolHeight = self.view.frame.size.height - (self.calculateTopDistance() + tabbarHeight) - 92
        }
        
        let newsView = UIView(frame: CGRect(x: 0, y: self.calculateTopDistance() + 5, width: self.view.frame.size.width, height: scroolHeight))
        newsView.tag = 100
        
        self.tableView = UITableView(frame: CGRect(x: 0, y: 0, width: self.view.frame.size.width, height: scroolHeight), style: UITableView.Style.plain)
        self.tableView.dataSource = self
        self.tableView.delegate = self
        let headerNib = UINib.init(nibName: "NewsHeaderFooterView", bundle: Bundle.main)
        tableView.register(headerNib, forHeaderFooterViewReuseIdentifier: "NewsHeaderView")
        self.tableView.register(UINib(nibName: "NewsTableViewCell", bundle: nil), forCellReuseIdentifier: "NewsCell")
        self.tableView.rowHeight = 65.0// UITableView.automaticDimension
        self.tableView.estimatedRowHeight = 65.0
        self.tableView.separatorStyle = .none
        //self.tableView.rowHeight = UITableView.automaticDimension
        
        self.refreshControl.addTarget(self, action: #selector(refreshTable), for: .valueChanged)
        
        //Setup pull to refresh
        if #available(iOS 10.0, *) {
            self.tableView.refreshControl = refreshControl
        } else {
            // Fallback on earlier versions
            self.tableView.addSubview(refreshControl)
        }
        
        self.removeSubView()
        newsView.addSubview(tableView)
        
        //Add the view
        self.view.addSubview(newsView)
        
        //self.view.addSubview(scrollView)
        self.activityIndicator.sizeToFit()
        self.activityIndicator.center.x = super.view.center.x
        self.activityIndicator.center.y = (super.view.center.y - 50)
        self.view.addSubview(activityIndicator)
    }
    
    @objc func getNews()
    {
        // To make the activity indicator appear:
        self.activityIndicator.startAnimating()
        
        if let viewWithTag = self.view.viewWithTag(7575) {
            viewWithTag.removeFromSuperview()
        }
        
        let schoolid = getSchoolId()
        let teacherid = getTeacherId()
        
        let alertView = SCLAlertView(appearance: self.appearance)
        
        if var urlComponents = URLComponents(string: Constants.baseUrl + "getNewsTeacher") {
            urlComponents.query = "schoolid=\(schoolid)&teacherid=\(teacherid)"
            // 3
            guard let url = urlComponents.url else { return }
            
            getData(from: url) { data, response, error in
                if error != nil {
                    DispatchQueue.main.async {
                        
                        self.activityIndicator.stopAnimating()
                        alertView.showInfo("OurSchoolZone", subTitle: self.defaultLocalizer.stringForKey(key: "allertMessageFetchdataError"), closeButtonTitle: self.defaultLocalizer.stringForKey(key: "actionSheetTitleOK"))
                    }
                    print(error!.localizedDescription)
                }
                guard let data = data else { return }
                //Implement JSON decoding and parsing
                do {
                    //Decode retrived data with JSONDecoder and assing type of Article object
                    let newsData = try JSONDecoder().decode(Result.self, from: data)
                    
                    self.activityIndicator.stopAnimating()
                    self.response = newsData.Response
                    if(self.response?.ResponseVal == 0)
                    {
                        
                        //Get back to the main queue
                        DispatchQueue.main.async {
                            self.displayAlertMessage()
                        }
                    }
                    else{
                        if let viewWithTag = self.view.viewWithTag(7575) {
                            viewWithTag.removeFromSuperview()
                        }
                        //Get back to the main queue
                        DispatchQueue.main.async {
                            self.sections.removeAll()
                            self.news?.removeAll()
                            
                            self.news = newsData.News
                            
                            var newsToday = [News]()
                            var newsYesterday = [News]()
                            var newsEarlier = [News]()
                            
                            for newsObject in self.news! {
                                let inputFormatter = DateFormatter()
                                inputFormatter.dateFormat = "yyyy-MM-dd"
                                let newDate = formateDateFromString(dateString: newsObject.NewsStartDate, withFormat: "yyyy-MM-dd")!
                                
                                let formatedNewsDate = inputFormatter.date(from: newDate)
                                
                                let currentDate = Date()
                                
                                let difference =  currentDate.timeIntervalSince(formatedNewsDate!)
                                let differenceInDays = Int(difference/(60 * 60 * 24 ))
                                
                                if(differenceInDays == 0)
                                {
                                    newsToday.append(newsObject as News)
                                }
                                
                                if(differenceInDays > 0 && differenceInDays <= 7)
                                {
                                    newsYesterday.append(newsObject as News)
                                }
                                
                                if(differenceInDays > 7)
                                {
                                    newsEarlier.append(newsObject as News)
                                }
                            }
                            
                            if(newsToday.count > 0)
                            {
                                self.sections.append(Section(name: self.defaultLocalizer.stringForKey(key: "labelToday"), items: newsToday, collapsed: false))
                            }
                            
                            if(newsYesterday.count > 0 && newsToday.count == 0)
                            {
                                self.sections.append(Section(name: self.defaultLocalizer.stringForKey(key: "labelYesterday"), items: newsYesterday, collapsed: false))
                            }
                            
                            if(newsYesterday.count > 0 && newsToday.count > 0)
                            {
                                self.sections.append(Section(name: self.defaultLocalizer.stringForKey(key: "labelYesterday"), items: newsYesterday, collapsed: true))
                            }
                            
                            if(newsEarlier.count > 0 && newsYesterday.count == 0 && newsToday.count == 0)
                            {
                                self.sections.append(Section(name: self.defaultLocalizer.stringForKey(key: "labelEarlier"), items: newsEarlier, collapsed: false))
                            }
                            
                            if(newsEarlier.count > 0 && newsYesterday.count == 0 && newsToday.count > 0)
                            {
                                self.sections.append(Section(name: self.defaultLocalizer.stringForKey(key: "labelEarlier"), items: newsEarlier, collapsed: true))
                            }
                            
                            if(newsEarlier.count > 0 && newsYesterday.count > 0 && newsToday.count == 0)
                            {
                                self.sections.append(Section(name: self.defaultLocalizer.stringForKey(key: "labelEarlier"), items: newsEarlier, collapsed: true))
                            }
                            
                            //dump(self.sections)
                            self.tableView.reloadData()
                        }
                    }
                    
                } catch let jsonError {
                    DispatchQueue.main.async {
                        self.activityIndicator.stopAnimating()
                    }
                    print(jsonError)
                }
                
                
            }
        }
    }
    
    @objc func refreshTable()
    {
        refreshControl.endRefreshing()
        self.getNews()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "NewsCell") as! NewsTableViewCell
        
        var newsModel:News?
        newsModel = self.sections[indexPath.section].items[indexPath.row]
        cell.labelNews?.text = newsModel?.NewsTitle
        cell.labelDate?.text = formateDateFromString(dateString: (newsModel?.NewsStartDate)!, withFormat: "dd-MM-yyyy")!
        
        cell.NewsThumbnail.image = nil
        let id = newsModel?.id
        cell.tag = indexPath.row
        
        if((newsModel?.NewsThumbnail)!.count > 0){
            if(cell.tag == indexPath.row) {
                if let dataFromCache = dataCache.object(forKey: id as AnyObject) as? Data{
                    
                    cell.NewsThumbnail.image = UIImage(data: dataFromCache)
                }
                else
                {
                    Alamofire.request((newsModel?.NewsThumbnail)!, method: .get).response { (responseData) in
                        if let data = responseData.data {
                            DispatchQueue.main.async {
                                self.dataCache.setObject(data as AnyObject, forKey: id as AnyObject)
                                cell.NewsThumbnail.image = UIImage(data: data)
                            }
                        }
                    }
                }
            }
        }
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return sections[section].collapsed ? 0 : sections[section].items.count
    }
    
    private func tableView(_ tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        return 65.0// UITableView.automaticDimension
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView?
    {
        let headerView = tableView.dequeueReusableHeaderFooterView(withIdentifier: "NewsHeaderView") as! NewsHeaderFooterView
        headerView.labelSectionTitle.text = sections[section].name
        headerView.buttonToggle.addTarget(self, action: #selector(sectionArrowTapped), for: UIControl.Event.touchUpInside)
        headerView.buttonToggle.tag = section + 100
        if(self.sections[section].collapsed == false){
            //headerView.buttonToggle.transform = headerView.buttonToggle.transform.rotated(by: CGFloat(Double.pi/2))
            headerView.buttonToggle.setImage(UIImage(named: "collapse"), for: .normal)
        }
        //headerView.contentView.backgroundColor = colorWithHexString(hex: "#DDDDDD")
        //headerView.tag = section + 101
        //let tapgesture = UITapGestureRecognizer(target: self , action: #selector(sectionHeaderTapped))
        //headerView.addGestureRecognizer(tapgesture)
        
        return headerView
    }
    
    @objc func sectionArrowTapped(_ sender: UIButton){
        if(self.sections[(sender.tag) - 100].collapsed == false){
            self.sections[(sender.tag) - 100].collapsed = true
        }else{
            self.sections[(sender.tag) - 100].collapsed = false
        }
        //sender.transform = sender.transform.rotated(by: CGFloat(Double.pi))
        sender.setImage(UIImage(named: "collapse"), for: .normal)
        self.tableView.reloadSections(IndexSet(integer: (sender.tag) - 100), with: .automatic)
    }
    
    @objc func sectionHeaderTapped(_ sender: UITapGestureRecognizer) {
        let headerView = sender.view as! UITableViewHeaderFooterView
        if(self.sections[(headerView.tag) - 101].collapsed == false){
            self.sections[(headerView.tag) - 101].collapsed = true
        }else{
            self.sections[(headerView.tag) - 101].collapsed = false
        }
        
        //headerView.buttonToggle.transform = headerView.buttonToggle.transform.rotated(by: CGFloat(Double.pi))
        self.tableView.reloadSections(IndexSet(integer: (headerView.tag) - 101), with: .automatic)
    }
    
    /*func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return sections[section].name
    }*/
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return sections.count
    }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "vcNewsDetails") as! NewsDetailsViewController
        vc.modalPresentationStyle = .fullScreen
        let news = sections[indexPath.section].items[indexPath.row]
        
        vc.newsID = news.id
        vc.newsTitle = news.NewsTitle
        vc.newsDate = formateDateFromString(dateString: (news.NewsStartDate), withFormat: "dd-MMM-yyyy")!
        vc.newsEndDate = formateDateFromString(dateString: (news.NewsEndDate), withFormat: "dd-MMM-yyyy")!
        vc.newsDesc = news.NewsDescription
        vc.imagePath = (news.NewsThumbnail)
        
        //self.present(vc, animated: false, completion: nil)
        //CFRunLoopWakeUp(CFRunLoopGetCurrent())
        self.navigationController?.pushViewController(vc, animated: false)
    }
    
    func removeSubView()
    {
        
        if let viewWithTag = self.view.viewWithTag(100) {
            viewWithTag.removeFromSuperview()
        }
        if let viewWithTag = self.view.viewWithTag(7575) {
            viewWithTag.removeFromSuperview()
        }
    }
    
    func displayAlertMessage()
    {
        let imageview = UIImageView(frame: CGRect(x: ((self.view.frame.size.width / 2) - 50), y: ((self.view.frame.size.height / 2) - 74), width: 100, height: 100))
        imageview.image = UIImage(named: "norecordfound")
        imageview.contentMode = UIView.ContentMode.scaleAspectFit
        imageview.layer.masksToBounds = true
        imageview.tag = 7575
        self.view.addSubview(imageview)
    }
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destination.
     // Pass the selected object to the new view controller.
     }
     */
    
}

struct Section {
    var name: String
    var items: [News]
    var collapsed: Bool
    
    init(name: String, items: [News], collapsed: Bool = false) {
        self.name = name
        self.items = items
        self.collapsed = collapsed
    }
}
