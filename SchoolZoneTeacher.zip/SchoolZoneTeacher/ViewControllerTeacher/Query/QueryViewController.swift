//
//  QueryViewController.swift
//  SchoolZoneTeacher
//
//  Created by Apple on 21/01/20.
//  Copyright © 2020 ClearWin Technologies. All rights reserved.
//

import UIKit
import Alamofire
import MaterialComponents
import SCLAlertView

class QueryViewController: UIViewController, UITextFieldDelegate, UITextViewDelegate, UINavigationControllerDelegate, UIActionSheetDelegate {

    let defaultLocalizer = AMPLocalizeUtils.defaultLocalizer
    let activityIndicator = MDCActivityIndicator()
    var containerView = UIView()
    var txtDesc = UITextView()
    
    var buttonSubmit = UIButton()
    var adjustY = CGFloat()
    
    var schoolid = Int()
    var teacherid = Int()
    var parentid = Int()
    
    let appearance = SCLAlertView.SCLAppearance(
        kTitleFont: UIFont(name: "HelveticaNeue", size: 20)!,
        kTextFont: UIFont(name: "HelveticaNeue", size: 14)!,
        kButtonFont: UIFont(name: "HelveticaNeue-Bold", size: 14)!
    )
    
    func textViewShouldBeginEditing(_ txtDesc: UITextView) -> Bool {
        let globalPoints = txtDesc.superview?.convert(txtDesc.frame.origin, to: nil)
        adjustY = ((globalPoints?.y)! - self.calculateTopDistance()) + 80
        
        return true
    }
    
    func textViewDidBeginEditing(_ txtDesc: UITextView) {
        if txtDesc.textColor == UIColor.lightGray {
            txtDesc.text = nil
            txtDesc.textColor = UIColor.black
        }
        txtDesc.tintColor = UIColor.gray
    }
    
    func textViewDidEndEditing(_ txtDesc: UITextView) {
        if txtDesc.text.isEmpty {
            //txtDesc.text = "Description_Text".localized()
            txtDesc.textColor = UIColor.lightGray
        }
    }
    
    func textView(_ textView: UITextView, shouldChangeTextIn range: NSRange, replacementText text: String) -> Bool {
        
        let newText = (txtDesc.text as NSString).replacingCharacters(in: range, with: text)
        let numberOfChars = newText.count
        return numberOfChars <= 200    // 10 Limit Value
    }
    
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {
        let globalPoints = textField.superview?.convert(textField.frame.origin, to: nil)
        adjustY = ((globalPoints?.y)! - self.calculateTopDistance()) + 50
        
        
        return true
    }
    
    @objc func keyboardWillShow(notification: NSNotification) {
        
        //print("adjustY: \(adjustY)")
        
        let info = notification.userInfo!
        let keyboardFrame: CGRect = (info[UIResponder.keyboardFrameEndUserInfoKey] as! NSValue).cgRectValue
        if self.containerView.frame.origin.y == self.calculateTopDistance() {
            //print(adjustY)
            let bottomSpace = (self.containerView.frame.size.height - adjustY) // calculate space below the control
            if(bottomSpace < keyboardFrame.size.height) // not enogh space for keboard display
            {
                let orginY = keyboardFrame.size.height - bottomSpace
                self.containerView.frame.origin.y -= orginY
            }
        }
    }
    
    @objc func keyboardWillHide(notification: NSNotification) {
        if self.containerView.frame.origin.y != self.calculateTopDistance() {
            self.containerView.frame.origin.y = self.calculateTopDistance()
        }
    }
    
    func calculateTopDistance () -> CGFloat{
        let statusBarHeight = UIApplication.shared.isStatusBarHidden ? CGFloat(0) : UIApplication.shared.statusBarFrame.height
        return statusBarHeight + 45
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        if(getLanguage().count > 0)
        {
            defaultLocalizer.setSelectedLanguage(lang: getLanguage())
        }
        else
        {
            defaultLocalizer.setSelectedLanguage(lang: "en")
        }
        
        self.setNavigationBar()
        
        self.setQueryView()
    }
    
    func setNavigationBar() {
        let navigationFont = UIFont(name: "Helvetica", size: getTitleFontSize())
        
        let button = UIButton.init(type: .custom)
        button.setTitle(self.defaultLocalizer.stringForKey(key: "navBarButtonBack"), for: UIControl.State.normal)
        var image = UIImage.init(named: "back")
        let templateImage = image?.withRenderingMode(UIImage.RenderingMode.alwaysTemplate)
        image = templateImage
        button.setImage(image, for: UIControl.State.normal)
        button.addTarget(self, action:#selector(back), for:.touchUpInside)
        button.addTarget(self, action:#selector(back), for:.touchUpOutside)
        button.frame = CGRect.init(x: 0, y: 0, width: 20, height: 20) //CGRectMake(0, 0, 30, 30)
        let doneItem = UIBarButtonItem.init(customView: button)
        self.navigationItem.leftBarButtonItem = doneItem
        
        let width = self.view.frame.width - 60
        let height = CGFloat(44)
        
        let titleLabel = UILabel(frame: CGRect.init(x: 0, y: 0, width: width, height: height))
        titleLabel.text = self.defaultLocalizer.stringForKey(key: "menuTitleQuery")
        titleLabel.textAlignment = .center
        titleLabel.font = navigationFont
        titleLabel.textColor = .white
        titleLabel.sizeToFit()
        
        self.navigationItem.titleView = titleLabel
    }
    
    @objc func doneButtonAction() {
        self.view.endEditing(true)
    }
    
    func setQueryView()
    {
        let tabbarHeight = getTabbarHeight()
        let scroolHeight = self.view.frame.size.height - (self.calculateTopDistance() + tabbarHeight)
        
        containerView = UIView(frame: CGRect(x: 5, y: 5, width: self.view.frame.size.width - 10, height: scroolHeight - 10))
        
        txtDesc = UITextView(frame: CGRect(x: 10, y: 10, width: (containerView.frame.size.width - 20), height: 250))
        txtDesc.text = self.defaultLocalizer.stringForKey(key: "placeHolderDesc")
        txtDesc.font = UIFont(name:"Helvetica", size: 16.0)
        txtDesc.layer.borderColor = colorWithHexString(hex: "#DDDDDD").cgColor;
        txtDesc.layer.borderWidth = 1.0;
        txtDesc.layer.cornerRadius = 5.0;
        txtDesc.isEditable = true;
        txtDesc.textColor = UIColor.lightGray
        txtDesc.delegate = self
        
        //init toolbar
        let toolbar:UIToolbar = UIToolbar(frame: CGRect(x: 0, y: 0,  width: self.view.frame.size.width, height: 30))
        //create left side empty space so that done button set on right side
        let flexSpace = UIBarButtonItem(barButtonSystemItem:    .flexibleSpace, target: nil, action: nil)
        let doneBtn: UIBarButtonItem = UIBarButtonItem(title: self.defaultLocalizer.stringForKey(key: "toolBarButtonTitleDone"), style: .done, target: self, action: #selector(doneButtonAction))
        toolbar.setItems([flexSpace, doneBtn], animated: false)
        toolbar.sizeToFit()
        
        txtDesc.inputAccessoryView = toolbar
        
        self.buttonSubmit = UIButton(frame: CGRect(x: ((self.containerView.frame.size.width / 2) + 5), y: 280, width: ((self.containerView.frame.size.width / 2) - 15), height: 50))
        self.setSubmitButtonAppearence(buttonSubmit: buttonSubmit, buttonText: self.defaultLocalizer.stringForKey(key: "buttonLabelSubmit"))
        buttonSubmit.addTarget(self, action: #selector(submitQuery), for:.touchUpInside)
        buttonSubmit.addTarget(self, action: #selector(submitQuery), for:.touchUpOutside)
        self.containerView.addSubview(txtDesc)
        self.containerView.addSubview(self.buttonSubmit)
        self.view.addSubview(containerView)
        
        self.activityIndicator.sizeToFit()
        self.activityIndicator.center.x = super.view.center.x
        self.activityIndicator.center.y = (super.view.center.y - 50)
        self.view.addSubview(activityIndicator)
    }
    
    @objc func submitQuery(_sender: UIButton)
    {
        
        let alertView = SCLAlertView(appearance: self.appearance)
        
        if(txtDesc.text?.count == 0 || txtDesc.text == self.defaultLocalizer.stringForKey(key: "placeHolderDesc"))
        {
            alertView.showInfo("OurSchoolZone", subTitle: self.defaultLocalizer.stringForKey(key: "submitErrorEnterTopicDesc"), closeButtonTitle: self.defaultLocalizer.stringForKey(key: "buttonAlertOK"))
            
            return
        }
        self.activityIndicator.startAnimating()
        
        self.buttonSubmit.isEnabled = false
        
        let schoolid = getSchoolId()
        let teacherid = getTeacherId()
        let desc = txtDesc.text!
        
        let queryString = "schoolid=\(schoolid)&parentid=&teacherid=\(teacherid)&query=\(desc)"
        
        if var urlComponents = URLComponents(string: Constants.baseUrl + "AddQuery") {
            urlComponents.query = queryString
            // 3
            guard let url = urlComponents.url else { return }
            
            print(url)
            
            var request = URLRequest(url: url)
            request.setValue("application/x-www-form-urlencoded", forHTTPHeaderField: "Content-Type")
            request.httpMethod = "POST"
            
            Alamofire.request(request).responseJSON{response in
                
                if let httpStatus = response.response, httpStatus.statusCode != 200 {
                    //let responseMessage = String(describing: response.response)
                    
                    //Get back to the main queue
                    DispatchQueue.main.async {
                        self.activityIndicator.stopAnimating()
                        let alert = UIAlertController(title: "OurSchoolZone", message: self.defaultLocalizer.stringForKey(key: "submitErrorQueryNotPosted"), preferredStyle: .alert)
                        alert.addAction(UIAlertAction(title: self.defaultLocalizer.stringForKey(key: "actionSheetTitleOK"), style: .default, handler: { action in
                        }))
                        self.present(alert, animated: true, completion: nil)
                    }
                }
                guard let data = response.data else { return }
                
                do {
                    //Decode retrived data with JSONDecoder and assing type of Article object
                    
                    let responseData = try JSONDecoder().decode(Result.self, from: data)
                    
                    //dump("responseData: \(responseData.Response.ResponseVal)")
                    
                    //Get back to the main queue
                    DispatchQueue.main.async {
                        self.activityIndicator.stopAnimating()
                        if(responseData.Response.ResponseVal == 1)
                        {
                            self.txtDesc.text = String()
                            if let viewWithTag = self.view.viewWithTag(11) {
                                viewWithTag.removeFromSuperview()
                            }
                            if let viewWithTag = self.view.viewWithTag(1100) {
                                viewWithTag.removeFromSuperview()
                            }
                            
                            let alert = UIAlertController(title: "OurSchoolZone", message: self.defaultLocalizer.stringForKey(key: "submitSuccessQueryPosted"), preferredStyle: .alert)
                            alert.addAction(UIAlertAction(title: self.defaultLocalizer.stringForKey(key: "actionSheetTitleOK"), style: .default, handler: { action in
                                self.navigationController?.popViewController(animated: false)
                            }))
                            self.present(alert, animated: true, completion: nil)
                        }
                        else
                        {
                            let alert = UIAlertController(title: "OurSchoolZone", message: responseData.Response.Reason, preferredStyle: .alert)
                            alert.addAction(UIAlertAction(title: self.defaultLocalizer.stringForKey(key: "actionSheetTitleOK"), style: .default, handler: { action in
                            }))
                            self.present(alert, animated: true, completion: nil)
                        }
                    }
                    
                } catch {
                    //let responseMessage = String(describing: jsonError)
                    //Get back to the main queue
                    DispatchQueue.main.async {
                        self.activityIndicator.stopAnimating()
                    }
                }
            }
        }
    }
    
    @objc func back() {
        AppLoadingStatus.appLoadingStatus.status = "Redirect"
        self.navigationController?.popViewController(animated: false)
    }
    
    func setSubmitButtonAppearence(buttonSubmit: UIButton, buttonText: String){
        
        buttonSubmit.tintColor = UIColor.white
        buttonSubmit.backgroundColor = colorWithHexString(hex: "#00FFCC")
        buttonSubmit.layer.masksToBounds = false
        buttonSubmit.layer.borderColor = colorWithHexString(hex: "#DDDDDD").cgColor
        buttonSubmit.layer.shadowColor = UIColor(red: 0, green: 0, blue: 0, alpha: 0.25).cgColor
        buttonSubmit.layer.shadowOffset = CGSize(width: 1.0, height: 5.0)
        buttonSubmit.layer.shadowOpacity = 1.0
        buttonSubmit.layer.shadowRadius = 5.0
        buttonSubmit.layer.masksToBounds = false
        buttonSubmit.layer.cornerRadius = 3.0
        buttonSubmit.isMultipleTouchEnabled = false
        
        let imageView = UIImageView(frame: CGRect(x: 5, y: 5, width: 40, height: 40))
        imageView.image = UIImage(named: "ok")
        
        let buttonLabel = UILabel(frame: CGRect(x: 40, y: 0, width: buttonSubmit.frame.width - 40, height: 50))
        
        buttonLabel.textColor = UIColor.white
        buttonLabel.font = UIFont(name:"HelveticaNeue-Bold", size: 16.0)
        buttonLabel.textAlignment = .left
        buttonLabel.text = buttonText
        
        buttonSubmit.addSubview(imageView)
        buttonSubmit.addSubview(buttonLabel)
    }
    
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destination.
     // Pass the selected object to the new view controller.
     }
     */
    
}
