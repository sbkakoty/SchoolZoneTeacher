//
//  RemarksDetailsViewController.swift
//  SchoolZoneTeacher
//
//  Created by Apple on 20/02/19.
//  Copyright © 2019 ClearWin Technologies. All rights reserved.
//

import UIKit
import SCLAlertView
import MaterialComponents

class RemarksDetailsViewController: UIViewController, UITextViewDelegate {
    
    let defaultLocalizer = AMPLocalizeUtils.defaultLocalizer
    let activityIndicator = MDCActivityIndicator();
    var result:Result?
    var remarksReplies:[RemarksReply]?
    var response:Response?
    
    let appearance = SCLAlertView.SCLAppearance(
        kTitleFont: UIFont(name: "HelveticaNeue", size: 20)!,
        kTextFont: UIFont(name: "HelveticaNeue", size: 14)!,
        kButtonFont: UIFont(name: "HelveticaNeue-Bold", size: 14)!
    )
    
    @IBOutlet weak var containerView: UIView!
    @IBOutlet weak var labelClass: UILabel!
    @IBOutlet weak var textClass: UILabel!
    @IBOutlet weak var labelSubject: UILabel!
    @IBOutlet weak var textSubject: UILabel!
    @IBOutlet weak var textDate: UILabel!
    @IBOutlet weak var labelTeacher: UILabel!
    @IBOutlet weak var textTeacherName: UILabel!
    @IBOutlet weak var textRemarks: UITextView!
    @IBOutlet weak var textReply: UITextView!
    @IBOutlet weak var butonSend: UIButton!
    
    @IBOutlet weak var containerViewReplies: UIScrollView!
    @IBOutlet var labelDesc: UILabel!
    @IBOutlet var labelStatus: UILabel!
    @IBOutlet var txtStatus: UILabel!
    
    var varRemarkId:Int!
    var varClassName:String!
    var varSubjectName:String!
    var varDate:String!
    var varTeacherName:String!
    var varRemarks:String!
    var varStatus:String!
    
    var offsetY:CGFloat = 0
    
    override func viewDidAppear(_ animated: Bool) {
        DispatchQueue.main.async {
            self.textRemarks.scrollRangeToVisible(NSMakeRange(0, 0))
        }
        
        containerViewReplies.contentSize = CGSize(width: containerViewReplies.frame.width, height: UIScreen.main.bounds.height + 3000)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardFrameChangeNotification(notification:)), name: UIResponder.keyboardWillChangeFrameNotification, object: nil)
    }
    
    @objc func keyboardFrameChangeNotification(notification: Notification) {
        if let userInfo = notification.userInfo {
            let endFrame = userInfo[UIResponder.keyboardFrameEndUserInfoKey] as? CGRect
            let animationDuration = userInfo[UIResponder.keyboardAnimationDurationUserInfoKey] as? Double ?? 0
            let animationCurveRawValue = (userInfo[UIResponder.keyboardAnimationCurveUserInfoKey] as? Int) ?? Int(UIView.AnimationOptions.curveEaseInOut.rawValue)
            let animationCurve = UIView.AnimationOptions(rawValue: UInt(animationCurveRawValue))
            
            var navBarHeight = self.calculateTopDistance()
            if(textReply.isFirstResponder){
                if(UIScreen.main.nativeBounds.height >= 2436){
                    navBarHeight -= (65 + 89)
                }
                else
                {
                    navBarHeight -= (65 + 55)
                }
                if let _ = endFrame, endFrame!.intersects(self.containerView.frame) {
                    self.offsetY = (self.containerView.frame.maxY - endFrame!.minY) - navBarHeight
                    print(self.offsetY)
                    UIView.animate(withDuration: animationDuration, delay: TimeInterval(0), options: animationCurve, animations: {
                        self.containerView.frame.origin.y = self.containerView.frame.origin.y - self.offsetY
                    }, completion: nil)
                } else {
                    if self.offsetY != 0 {
                        UIView.animate(withDuration: animationDuration, delay: TimeInterval(0), options: animationCurve, animations: {
                            self.containerView.frame.origin.y = self.containerView.frame.origin.y + self.offsetY
                            self.offsetY = 0
                        }, completion: nil)
                    }
                }
            }
        }
    }
    
    func calculateTopDistance () -> CGFloat{
        let statusBarHeight = UIApplication.shared.isStatusBarHidden ? CGFloat(0) : UIApplication.shared.statusBarFrame.height
        return statusBarHeight + 45
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        self.containerViewReplies.isUserInteractionEnabled = true
        self.containerViewReplies.showsVerticalScrollIndicator = true
        self.containerViewReplies.isScrollEnabled = true
        self.containerViewReplies.setContentOffset(CGPoint(x: 0, y: 0), animated: false)
        
        if(getLanguage().count > 0)
        {
            defaultLocalizer.setSelectedLanguage(lang: getLanguage())
        }
        else
        {
            defaultLocalizer.setSelectedLanguage(lang: "en")
        }
        
        self.setNavigationBar()
        
        self.labelClass.text = self.defaultLocalizer.stringForKey(key: "labelClass")
        self.labelSubject.text = self.defaultLocalizer.stringForKey(key: "labelSubject")
        self.labelTeacher.text = self.defaultLocalizer.stringForKey(key: "labelUserType")
        self.labelDesc.text = self.defaultLocalizer.stringForKey(key: "labelDesc")
        self.labelStatus.text = self.defaultLocalizer.stringForKey(key: "labelStatus")
        
        //let contentsHeight = UIApplication.shared.isStatusBarHidden ? CGFloat(0) : UIApplication.shared.statusBarFrame.height + 275
        //self.containerViewReplies.isScrollEnabled = true
        //containerViewReplies.contentSize = CGSize(width: self.view.frame.width - 20, height: self.view.frame.height - contentsHeight)
        containerView.layer.borderWidth = 0.5
        containerView.layer.cornerRadius = 3.0
        containerView.layer.borderColor = colorWithHexString(hex: "#DDDDDD").cgColor
        containerView.layer.shadowColor = UIColor.lightGray.cgColor
        containerView.layer.shadowOffset = CGSize(width: 3, height: 3)
        containerView.layer.shadowOpacity = 0.5
        
        textClass.text = varClassName
        textSubject.text = varSubjectName
        textDate.text = varDate
        textTeacherName.text = varTeacherName
        textRemarks.text = varRemarks
        if(varStatus == "1"){
            txtStatus.text = "Read"
        }else{
            txtStatus.text = "Unread"
        }
        
        textReply.text = self.defaultLocalizer.stringForKey(key: "placeHolderReply")
        textReply.font = UIFont(name:"Helvetica", size: 16.0)
        textReply.layer.borderColor = colorWithHexString(hex: "#DDDDDD").cgColor;
        textReply.layer.borderWidth = 1.0;
        textReply.layer.cornerRadius = 5.0;
        textReply.isEditable = true;
        textReply.textColor = UIColor.lightGray
        textReply.delegate = self
        
        butonSend.addTarget(self, action: #selector(submitReply), for:.touchUpInside)
        
        //init toolbar
        let toolbar:UIToolbar = UIToolbar(frame: CGRect(x: 0, y: 0,  width: self.view.frame.size.width, height: 30))
        //create left side empty space so that done button set on right side
        let flexSpace = UIBarButtonItem(barButtonSystemItem:    .flexibleSpace, target: nil, action: nil)
        let doneBtn: UIBarButtonItem = UIBarButtonItem(title: self.defaultLocalizer.stringForKey(key: "toolBarButtonTitleDone"), style: .done, target: self, action: #selector(doneButtonAction))
        toolbar.setItems([flexSpace, doneBtn], animated: false)
        toolbar.sizeToFit()
        //setting toolbar as inputAccessoryView
        self.textReply.inputAccessoryView = toolbar
        
        self.activityIndicator.sizeToFit()
        self.activityIndicator.center.x = super.view.center.x
        self.activityIndicator.center.y = (super.view.center.y - 50)
        self.view.addSubview(activityIndicator)
        
        if let viewWithTag = self.view.viewWithTag(100) {
            viewWithTag.removeFromSuperview()
        }
        
        /*replySubView = UIScrollView(frame: CGRect(x: 0, y: 0, width: self.containerViewReplies.frame.width, height: self.containerViewReplies.frame.height))
        replySubView.tag = 100
        
        self.containerViewReplies.addSubview(replySubView)
        replySubView.isScrollEnabled = true
        replySubView.isUserInteractionEnabled = true*/
        
        self.getRemarksReplies()
    }
    
    @objc func doneButtonAction() {
        self.view.endEditing(true)
    }
    
    func textViewDidBeginEditing(_ textReply: UITextView) {
        if textReply.textColor == UIColor.lightGray {
            textReply.text = nil
            textReply.textColor = UIColor.black
        }
        textReply.tintColor = UIColor.gray
    }
    
    func textViewDidEndEditing(_ textReply: UITextView) {
        if textReply.text.isEmpty {
            textReply.text = self.defaultLocalizer.stringForKey(key: "placeHolderReply")
            textReply.textColor = UIColor.lightGray
        }
    }
    
    func removeView(tag: Int)
    {
        if let viewWithTag = self.view.viewWithTag(tag) {
            print(tag)
            viewWithTag.removeFromSuperview()
        }
    }
    
    func getRemarksReplies()
    {
        removeView(tag: 1111)
        removeView(tag: 1112)
        removeView(tag: 1113)
        removeView(tag: 1114)
        removeView(tag: 1115)
        removeView(tag: 1116)
        
        // To make the activity indicator appear:
        self.activityIndicator.startAnimating()
        
        let alertView = SCLAlertView(appearance: self.appearance)
        
        let schoolid = getSchoolId()
        
        if var urlComponents = URLComponents(string: Constants.baseUrl + "GetRemarksRepliesV2") {
            urlComponents.query = "schoolid=" + schoolid + "&remarkid=" + String(varRemarkId!)
            // 3
            guard let url = urlComponents.url else { return }
            
            getData(from: url) { data, response, error in
                if error != nil {
                    DispatchQueue.main.async {
                        alertView.showInfo("OurSchoolZone", subTitle: self.defaultLocalizer.stringForKey(key: "allertMessageFetchdataError"), closeButtonTitle: self.defaultLocalizer.stringForKey(key: "actionSheetTitleOK"))
                    }
                    print(error!.localizedDescription)
                }
                guard let data = data else { return }
                //Implement JSON decoding and parsing
                do {
                    //Decode retrived data with JSONDecoder and assing type of Article object
                    let remarksReplyData = try JSONDecoder().decode(Result.self, from: data)
                    
                    //Get back to the main queue
                    DispatchQueue.main.async {
                        self.remarksReplies = remarksReplyData.RemarksReplies
                        //dump(self.remarksReplies)
                        self.response = remarksReplyData.Response
                        
                        self.activityIndicator.stopAnimating()
                        
                        if(self.response?.ResponseVal != 0)
                        {
                            var yposition = CGFloat(0)
                            for replyObject in self.remarksReplies! {
                                var labelUser = UILabel()
                                var labelReplyDate = UILabel()
                                var labelRemarksReply = UILabel()
                                if(replyObject.RepliedByType! == "Teacher")
                                {
                                    labelUser = UILabel(frame: CGRect(x:(self.containerViewReplies.frame.width / 2) + 5, y: yposition, width: (self.containerViewReplies.frame.width / 2) - 15, height:15))
                                    labelUser.text = replyObject.RepliedBy!
                                    labelUser.font = UIFont.systemFont(ofSize: 12)
                                    labelUser.tag = 1111
                                    
                                    yposition += 20
                                    labelReplyDate = UILabel(frame: CGRect(x:(self.containerViewReplies.frame.width / 2) + 5, y: yposition, width: (self.containerViewReplies.frame.width / 2), height:15))
                                    labelReplyDate.text = replyObject.ReplyDate!
                                    labelReplyDate.font = UIFont.systemFont(ofSize: 10)
                                    labelReplyDate.tag = 1115
                                    
                                    yposition += 20
                                    
                                    labelRemarksReply = UILabel(frame: CGRect(x:(self.containerViewReplies.frame.width / 2) + 5, y: yposition, width: (self.containerViewReplies.frame.width / 2) + 5, height:15))
                                    labelRemarksReply.layer.backgroundColor = colorWithHexString(hex: "#CCFFCC").cgColor
                                    labelRemarksReply.layer.borderWidth = 1.0
                                    labelRemarksReply.layer.cornerRadius = 3.0
                                    labelRemarksReply.layer.borderColor = UIColor.clear.cgColor
                                    labelRemarksReply.font = UIFont.systemFont(ofSize: 12, weight: UIFont.Weight.regular)
                                    labelRemarksReply.text = replyObject.RemarksReply!
                                    yposition += 20
                                    labelRemarksReply.tag = 1113
                                    
                                    self.containerViewReplies.addSubview(labelUser)
                                    self.containerViewReplies.addSubview(labelRemarksReply)
                                    self.containerViewReplies.addSubview(labelReplyDate)
                                }
                                else
                                {
                                    labelUser = UILabel(frame: CGRect(x:0, y: yposition, width: (self.containerViewReplies.frame.width / 2) - 15, height:15))
                                    labelUser.font = UIFont.systemFont(ofSize: 12)
                                    labelUser.text = replyObject.RepliedBy!
                                    labelUser.tag = 1114
                                    
                                    yposition += 20
                                    labelReplyDate = UILabel(frame: CGRect(x:0, y: yposition, width: (self.containerViewReplies.frame.width / 2), height:15))
                                    labelReplyDate.text = replyObject.ReplyDate!
                                    labelReplyDate.font = UIFont.systemFont(ofSize: 10)
                                    labelReplyDate.tag = 1115
                                    
                                    yposition += 20
                                    
                                    labelRemarksReply = UILabel(frame: CGRect(x:0, y: yposition, width: (self.containerViewReplies.frame.width / 2) - 15, height:15))
                                    labelRemarksReply.layer.backgroundColor = colorWithHexString(hex: "#F6F6F6").cgColor
                                    labelRemarksReply.layer.borderWidth = 1.0
                                    labelRemarksReply.layer.cornerRadius = 3.0
                                    labelRemarksReply.layer.borderColor = UIColor.clear.cgColor
                                    labelRemarksReply.font = UIFont.systemFont(ofSize: 12, weight: UIFont.Weight.regular)
                                    labelRemarksReply.text = replyObject.RemarksReply!
                                    labelRemarksReply.tag = 1116
                                    
                                    yposition += 20
                                    
                                    self.containerViewReplies.addSubview(labelUser)
                                    self.containerViewReplies.addSubview(labelRemarksReply)
                                    self.containerViewReplies.addSubview(labelReplyDate)
                                }
                            }
                        }
                    }
                    
                } catch let jsonError {
                    self.activityIndicator.stopAnimating()
                    print(jsonError)
                }
            }
        }
        
        var offset = CGPoint(
            x: containerViewReplies.contentInset.left,
            y: -containerViewReplies.contentInset.top)
        
        if #available(iOS 11.0, *) {
            offset = CGPoint(
                x: containerViewReplies.adjustedContentInset.left,
                y: -containerViewReplies.adjustedContentInset.top)
        }
        
        containerViewReplies.setContentOffset(offset, animated: false)
    }
    
    @objc func submitReply(_sender: UIButton)
    {
        let alertView = SCLAlertView(appearance: self.appearance)
        
        if(textReply.text?.count == 0 || textReply.text == self.defaultLocalizer.stringForKey(key: "placeHolderReply"))
        {
            alertView.showInfo("OurSchoolZone", subTitle: self.defaultLocalizer.stringForKey(key: "allertMessageEnterReply"), closeButtonTitle: self.defaultLocalizer.stringForKey(key: "actionSheetTitleOK"))
            return
        }
        // To make the activity indicator appear:
        self.activityIndicator.startAnimating()
        
        let currentDate = Date()
        let formatter = DateFormatter()
        formatter.dateFormat = "dd-MM-yyyy HH:mm:ss"
        let schoolid = getSchoolId()
        let teacherid = getTeacherId()
        let reply = textReply.text
        
        let queryString = "schoolid=" + "\(schoolid)" + "&parentid=&teacherid=" + "\(teacherid)" + "&remarkid=" + "\(varRemarkId!)&date=" + formatter.string(from: currentDate) + "&reply=" + "\(reply!)&actualdatetime=" + formatter.string(from: currentDate)
        
        if var urlComponents = URLComponents(string: Constants.baseUrl + "AddRemarksReplyV2") {
            urlComponents.query = queryString
            // 3
            guard let url = urlComponents.url else { return }
            
            var request = URLRequest(url: url)
            request.setValue("application/x-www-form-urlencoded", forHTTPHeaderField: "Content-Type")
            request.httpMethod = "POST"
            let postString = queryString
            request.httpBody = postString.data(using: .utf8)
            
            postData(from: request) { data, response, error in
                
                if let httpStatus = response as? HTTPURLResponse, httpStatus.statusCode != 200 {
                    //let responseMessage = String(describing: response)
                    
                    //Get back to the main queue
                    DispatchQueue.main.async {
                        self.activityIndicator.stopAnimating()
                        alertView.showError("OurSchoolZone", subTitle: self.defaultLocalizer.stringForKey(key: "allertMessageRemarkReplySubmitError"), closeButtonTitle: self.defaultLocalizer.stringForKey(key: "actionSheetTitleOK"))
                    }
                }
                guard let data = data else { return }
                
                do {
                    //Decode retrived data with JSONDecoder and assing type of Article object
                    _ = try JSONDecoder().decode(Result.self, from: data)
                    
                    //Get back to the main queue
                    DispatchQueue.main.async {
                        self.activityIndicator.stopAnimating()
                        self.textReply.text = String()
                        
                        //self.response = remarkData.Response
                        
                        //let responseMessage = self.response!.Reason
                        
                        //alertView.showSuccess("OurSchoolZone", subTitle: self.defaultLocalizer.stringForKey(key: "allertMessageRemarkReplySubmitSuccess"), closeButtonTitle: self.defaultLocalizer.stringForKey(key: "actionSheetTitleOK"))
                        self.getRemarksReplies()
                    }
                    
                } catch {
                    //let responseMessage = String(describing: jsonError)
                    //Get back to the main queue
                    DispatchQueue.main.async {
                        self.activityIndicator.stopAnimating()
                    }
                }
            }
        }
    }
    
    func setNavigationBar() {
        let navigationFont = UIFont(name: "Helvetica", size: getTitleFontSize())
        
        let button = UIButton.init(type: .custom)
        button.setTitle(self.defaultLocalizer.stringForKey(key: "navBarButtonBack"), for: UIControl.State.normal)
        var image = UIImage.init(named: "back")
        let templateImage = image?.withRenderingMode(UIImage.RenderingMode.alwaysTemplate)
        image = templateImage
        button.setImage(image, for: UIControl.State.normal)
        button.addTarget(self, action:#selector(back), for:.touchUpInside)
        button.addTarget(self, action:#selector(back), for:.touchUpOutside)
        button.frame = CGRect.init(x: 0, y: 0, width: 20, height: 20) //CGRectMake(0, 0, 30, 30)
        let doneItem = UIBarButtonItem.init(customView: button)
        self.navigationItem.leftBarButtonItem = doneItem
        
        let width = self.view.frame.width - 60
        let height = CGFloat(44)
        
        let titleLabel = UILabel(frame: CGRect.init(x: 0, y: 0, width: width, height: height))
        titleLabel.text = self.defaultLocalizer.stringForKey(key: "navBarTitleRemarksDetails")
        titleLabel.textAlignment = .center
        titleLabel.font = navigationFont
        titleLabel.textColor = .white
        titleLabel.sizeToFit()
        self.navigationItem.titleView = titleLabel
    }
    
    @objc func back() {
        self.navigationController?.popViewController(animated: false)
    }
    
    func position(for bar: UIBarPositioning) -> UIBarPosition {
        return .topAttached
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
