//
//  SettingsViewController.swift
//  SchoolZoneTeacher
//
//  Created by Apple on 16/12/18.
//  Copyright © 2018 ClearWin Technologies. All rights reserved.
//

import UIKit

class SettingsViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    let defaultLocalizer = AMPLocalizeUtils.defaultLocalizer
    var popoverVC: UIViewController!
    var menuItems = [MenuItem]()
    var tableView = UITableView()
    
    var buttonActionSheet = UIButton()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        if(popoverVC != nil)
        {
            popoverVC.dismiss(animated: false, completion: nil)
        }
        
        if(getLanguage().count > 0)
        {
            defaultLocalizer.setSelectedLanguage(lang: getLanguage())
        }
        else
        {
            defaultLocalizer.setSelectedLanguage(lang: "en")
        }
        
        menuItems.append(MenuItem(menuIcon: "user-profile", menuText: self.defaultLocalizer.stringForKey(key: "menuTitleViewProfile")))
        menuItems.append(MenuItem(menuIcon: "language", menuText: self.defaultLocalizer.stringForKey(key: "menuTitleLanguage")))
        menuItems.append(MenuItem(menuIcon: "info", menuText: self.defaultLocalizer.stringForKey(key: "menuTitleWhatIsNew")))
        menuItems.append(MenuItem(menuIcon: "logout", menuText: self.defaultLocalizer.stringForKey(key: "menuTitleLogout")))
        
        self.setNavigationBar()
        self.loadSettingsView()
        
        self.buttonActionSheet = UIButton(frame: CGRect(x: 0, y: self.calculateTopDistance() + 225, width: self.view.frame.size.width, height: 50))
        self.buttonActionSheet.setTitle("", for: .normal)
        
        self.view.addSubview(buttonActionSheet)
    }
    
    func loadSettingsView() {
        //Set wanted position and size (frame)
        let tabbarHeight = getTabbarHeight()
        let scroolHeight = self.view.frame.size.height - (self.calculateTopDistance() + tabbarHeight)
        
        let settingsView = UIView(frame: CGRect(x: 0, y: self.calculateTopDistance() + 5, width: self.view.frame.size.width, height: scroolHeight))
        settingsView.tag = 100
        
        self.tableView = UITableView(frame: CGRect(x: 0, y: 0, width: self.view.frame.size.width, height: scroolHeight), style: UITableView.Style.plain)
        self.tableView.register(UINib(nibName: "SettingsTableViewCell", bundle: nil), forCellReuseIdentifier: "settingsCell")
        self.tableView.dataSource = self
        self.tableView.delegate = self
        self.tableView.allowsSelection = true
        self.tableView.rowHeight = 85.0
        self.tableView.estimatedRowHeight = 85.0
        self.tableView.separatorStyle = .none
        settingsView.addSubview(tableView)
        
        //Add the view
        self.view.addSubview(settingsView)
    }
    
    func setNavigationBar() {
        let navigationFont = UIFont(name: "Helvetica", size: getTitleFontSize())
        
        let button = UIButton.init(type: .custom)
        button.setTitle(self.defaultLocalizer.stringForKey(key: "navBarButtonBack"), for: UIControl.State.normal)
        var image = UIImage.init(named: "back")
        let templateImage = image?.withRenderingMode(UIImage.RenderingMode.alwaysTemplate)
        image = templateImage
        button.setImage(image, for: UIControl.State.normal)
        button.addTarget(self, action:#selector(back), for:.touchUpInside)
        button.addTarget(self, action:#selector(back), for:.touchUpOutside)
        button.frame = CGRect.init(x: 0, y: 0, width: 20, height: 20) //CGRectMake(0, 0, 30, 30)
        let doneItem = UIBarButtonItem.init(customView: button)
        self.navigationItem.leftBarButtonItem = doneItem
        
        let width = self.view.frame.width - 60
        let height = CGFloat(44)
        
        let titleLabel = UILabel(frame: CGRect.init(x: 0, y: 0, width: width, height: height))
        titleLabel.text = self.defaultLocalizer.stringForKey(key: "navBarTitleSettings")
        titleLabel.textAlignment = .center
        titleLabel.font = navigationFont
        titleLabel.textColor = .white
        titleLabel.sizeToFit()
        self.navigationItem.titleView = titleLabel
    }
    
    @objc func back() {
        
        self.navigationController?.popToRootViewController(animated: false)
    }
    
    func position(for bar: UIBarPositioning) -> UIBarPosition {
        return .topAttached
    }
    
    func calculateTopDistance () -> CGFloat{
        if(self.navigationController != nil && !self.navigationController!.navigationBar.isTranslucent){
            return 0
        }else{
            let barHeight=self.navigationController?.navigationBar.frame.height ?? 0
            let statusBarHeight = UIApplication.shared.isStatusBarHidden ? CGFloat(0) : UIApplication.shared.statusBarFrame.height
            return barHeight + statusBarHeight
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "settingsCell") as! SettingsTableViewCell
        
        let menuItem = menuItems[indexPath.row]
        
        cell.menuIcon.image = UIImage(named: menuItem.menuIcon)
        cell.menuIcon.tintColor = colorWithHexString(hex: "#00CCFF")
        cell.menuOption.text = menuItem.menuText
        
        cell.contentView.isUserInteractionEnabled = true
        cell.containerView.isUserInteractionEnabled = true
        cell.menuOption.isUserInteractionEnabled = true
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return menuItems.count
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat
    {
        return 85.0
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        if(indexPath.row == 0){
            if(getFirstName().trimmingCharacters(in: .whitespaces).count > 0){
                let vc = self.storyboard?.instantiateViewController(withIdentifier: "vcProfileView") as! ProfileViewController
                vc.modalPresentationStyle = .fullScreen
                vc.modalPresentationStyle = .fullScreen
                vc.modalPresentationStyle = .fullScreen
                vc.schoolName = getSchoolName()
                let fname = getFirstName() + " "
                let mname = getMiddleName().count > 0 ? getMiddleName() + " " : ""
                let lname = getLastName()
                let fullname = fname + mname + lname
                vc.teacherName = fullname
                vc.email = getEmail()
                vc.mobile = getMobile()
                vc.dob = getDOB()
                vc.gender = getGender()
                vc.imagePath = getProfileImage()
                vc.schoolIds.append(Int(getSchoolId())!)
                vc.schoolNames.append(getSchoolName())
                
                vcShared.vcshared.vcName = "ViewProfile"
                
                self.present(vc, animated: false, completion: nil)
                CFRunLoopWakeUp(CFRunLoopGetCurrent())
            }
            else
            {
                let vc = self.storyboard?.instantiateViewController(withIdentifier: "vcTerms") as! TermsViewController
                vc.modalPresentationStyle = .fullScreen
                self.present(vc, animated: false, completion: nil)
                CFRunLoopWakeUp(CFRunLoopGetCurrent())
            }
        }
        if(indexPath.row == 1){
            
            let actionsheet = UIAlertController(title: nil, message: nil, preferredStyle: UIAlertController.Style.actionSheet)
            
            actionsheet.addAction(UIAlertAction(title: self.defaultLocalizer.stringForKey(key: "actionSheetTitleEnglishIndia"), style: UIAlertAction.Style.default, handler: { (action) -> Void in
                
                let alertView = UIAlertController(title: "OurSchoolZone", message: self.defaultLocalizer.stringForKey(key: "allertMessageLanguage"), preferredStyle: UIAlertController.Style.alert)
                
                alertView.addAction(UIAlertAction(title: self.defaultLocalizer.stringForKey(key: "actionSheetTitleYes"), style: UIAlertAction.Style.default, handler: { (action) -> Void in
                    
                    //UserDefaults.standard.set(["en"], forKey: "AppleLanguages")
                    //UserDefaults.standard.synchronize()
                    
                    setLanguage(languageCode: "en")
                    setCountryCode(countryCode: "IN")
                    
                    self.dismiss(animated: false, completion: nil)
                    
                    AppLoadingStatus.appLoadingStatus.status = "Redirect"
                    
                    let vcLandingPage = self.storyboard!.instantiateViewController(withIdentifier: "vcRoot") as! RootViewController
                    
                    vcLandingPage.statusBarShouldBeHidden = false
                    self.setNeedsStatusBarAppearanceUpdate()
                    
                    let appDelegate = UIApplication.shared.delegate as! AppDelegate
                    appDelegate.window?.rootViewController = vcLandingPage
                }))
                
                alertView.addAction(UIAlertAction(title: self.defaultLocalizer.stringForKey(key: "actionSheetTitleCancel"), style: UIAlertAction.Style.destructive, handler: { (action) -> Void in
                    
                }))
                
                // Restyle the view of the Alert
                alertView.view.tintColor = colorWithHexString (hex: "#333333")  // change text color of the buttons
                alertView.view.backgroundColor = colorWithHexString (hex: "#00CCFF")  // change background color
                alertView.view.layer.cornerRadius = 25
                
                self.present(alertView, animated: true, completion: nil)
                CFRunLoopWakeUp(CFRunLoopGetCurrent())
            }))
            
            actionsheet.addAction(UIAlertAction(title: self.defaultLocalizer.stringForKey(key: "actionSheetTitleThai"), style: UIAlertAction.Style.default, handler: { (action) -> Void in
                
                let alertView = UIAlertController(title: "OurSchoolZone", message: self.defaultLocalizer.stringForKey(key: "allertMessageLanguage"), preferredStyle: UIAlertController.Style.alert)
                
                alertView.addAction(UIAlertAction(title: self.defaultLocalizer.stringForKey(key: "actionSheetTitleYes"), style: UIAlertAction.Style.default, handler: { (action) -> Void in
                    
                    //UserDefaults.standard.set(["th"], forKey: "AppleLanguages")
                    //UserDefaults.standard.synchronize()
                    
                    setLanguage(languageCode: "th")
                    setCountryCode(countryCode: "TH")
                    
                    self.dismiss(animated: false, completion: nil)
                    
                    AppLoadingStatus.appLoadingStatus.status = "Redirect"
                    
                    let vcLandingPage = self.storyboard!.instantiateViewController(withIdentifier: "vcRoot") as! RootViewController
                    
                    vcLandingPage.statusBarShouldBeHidden = false
                    self.setNeedsStatusBarAppearanceUpdate()
                    
                    let appDelegate = UIApplication.shared.delegate as! AppDelegate
                    appDelegate.window?.rootViewController = vcLandingPage
                }))
                
                alertView.addAction(UIAlertAction(title: self.defaultLocalizer.stringForKey(key: "actionSheetTitleCancel"), style: UIAlertAction.Style.destructive, handler: { (action) -> Void in
                    
                }))
                
                // Restyle the view of the Alert
                alertView.view.tintColor = colorWithHexString (hex: "#333333")  // change text color of the buttons
                alertView.view.backgroundColor = colorWithHexString (hex: "#00CCFF")  // change background color
                alertView.view.layer.cornerRadius = 25
                
                self.present(alertView, animated: true, completion: nil)
            }))
            
            actionsheet.addAction(UIAlertAction(title: self.defaultLocalizer.stringForKey(key: "actionSheetTitleAssameseIndia"), style: UIAlertAction.Style.default, handler: { (action) -> Void in
                
                let alertView = UIAlertController(title: "OurSchoolZone", message: self.defaultLocalizer.stringForKey(key: "allertMessageLanguage"), preferredStyle: UIAlertController.Style.alert)
                
                alertView.addAction(UIAlertAction(title: self.defaultLocalizer.stringForKey(key: "actionSheetTitleYes"), style: UIAlertAction.Style.default, handler: { (action) -> Void in
                    
                    //UserDefaults.standard.set(["en"], forKey: "AppleLanguages")
                    //UserDefaults.standard.synchronize()
                    
                    setLanguage(languageCode: "as-IN")
                    setCountryCode(countryCode: "IN")
                    
                    self.dismiss(animated: false, completion: nil)
                    
                    AppLoadingStatus.appLoadingStatus.status = "Redirect"
                    
                    let vcLandingPage = self.storyboard!.instantiateViewController(withIdentifier: "vcRoot") as! RootViewController
                    
                    vcLandingPage.statusBarShouldBeHidden = false
                    self.setNeedsStatusBarAppearanceUpdate()
                    
                    let appDelegate = UIApplication.shared.delegate as! AppDelegate
                    appDelegate.window?.rootViewController = vcLandingPage
                }))
                
                alertView.addAction(UIAlertAction(title: self.defaultLocalizer.stringForKey(key: "actionSheetTitleCancel"), style: UIAlertAction.Style.destructive, handler: { (action) -> Void in
                    
                }))
                
                // Restyle the view of the Alert
                alertView.view.tintColor = colorWithHexString (hex: "#333333")  // change text color of the buttons
                alertView.view.backgroundColor = colorWithHexString (hex: "#00CCFF")  // change background color
                alertView.view.layer.cornerRadius = 25
                
                self.present(alertView, animated: true, completion: nil)
                CFRunLoopWakeUp(CFRunLoopGetCurrent())
            }))
            
            actionsheet.addAction(UIAlertAction(title: self.defaultLocalizer.stringForKey(key: "actionSheetTitleCancel"), style: UIAlertAction.Style.cancel, handler: { (action) -> Void in
                
            }))
            
            /*If you want work actionsheet on ipad
             then you have to use popoverPresentationController to present the actionsheet,
             otherwise app will crash on iPad */
            switch UIDevice.current.userInterfaceIdiom {
            case .pad:
                actionsheet.popoverPresentationController?.sourceView = buttonActionSheet
                actionsheet.popoverPresentationController?.sourceRect = buttonActionSheet.bounds
                actionsheet.popoverPresentationController?.permittedArrowDirections = .up
            default:
                break
            }
            
            // Restyle the view of the Alert
            actionsheet.view.tintColor = colorWithHexString (hex: "#333333")  // change text color of the buttons
            actionsheet.view.backgroundColor = colorWithHexString (hex: "#00CCFF")  // change background color
            actionsheet.view.layer.cornerRadius = 25
            
            self.present(actionsheet, animated: true, completion: nil)
            CFRunLoopWakeUp(CFRunLoopGetCurrent())
        }
        
        if(indexPath.row == 2){
            let vc = self.storyboard?.instantiateViewController(withIdentifier: "vcWhatIsNew") as! WhatIsNewViewController
            vc.modalPresentationStyle = .fullScreen
            self.navigationController?.pushViewController(vc, animated: false)
        }
        
        if(indexPath.row == 3){
            
            let actionsheet = UIAlertController(title: "OurSchoolZone", message: self.defaultLocalizer.stringForKey(key: "allertMessageLogout"), preferredStyle: UIAlertController.Style.alert)
            
            actionsheet.addAction(UIAlertAction(title: self.defaultLocalizer.stringForKey(key: "actionSheetTitleYes"), style: UIAlertAction.Style.default, handler: { (action) -> Void in
                
                setSchoolId(schoolId: "")
                setTeacherId(teacherId: "")
                setSchoolName(schoolName: "")
                setFirstName(firstName: "")
                setMiddleName(middleName: "")
                setLastName(lastName: "")
                setEmail(email: "")
                setMobile(mobile: "")
                setDOB(dob: "")
                setGender(gender: "")
                setLang(lang: "")
                setProfileImage(profileImage: "")
                setSchoolLogo(logoImage: "")
                setSchoolAddress(address: "")
                AppLoginStatus.appLoginStatus.status = 0
                AppLoadingStatus.appLoadingStatus.status = "Fresh"
                
                let vc = self.storyboard?.instantiateViewController(withIdentifier: "vcSetLanguage") as! SetLanguageViewController
                vc.modalPresentationStyle = .fullScreen
                self.present(vc, animated: false, completion: nil)
                CFRunLoopWakeUp(CFRunLoopGetCurrent())
            }))
            
            actionsheet.addAction(UIAlertAction(title: self.defaultLocalizer.stringForKey(key: "actionSheetTitleCancel"), style: UIAlertAction.Style.destructive, handler: { (action) -> Void in
                
            }))
            
            // Restyle the view of the Alert
            actionsheet.view.tintColor = colorWithHexString (hex: "#333333")  // change text color of the buttons
            actionsheet.view.backgroundColor = colorWithHexString (hex: "#00CCFF")  // change background color
            actionsheet.view.layer.cornerRadius = 25
            
            self.present(actionsheet, animated: true, completion: nil)
            CFRunLoopWakeUp(CFRunLoopGetCurrent())
        }
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
