//
//  AssignmentDetailsViewController.swift
//  SchoolZoneTeacher
//
//  Created by Apple on 19/12/18.
//  Copyright © 2018 ClearWin Technologies. All rights reserved.
//

import UIKit
import MaterialComponents
import iOSDropDown
import SCLAlertView
import Lightbox

class AssignmentDetailsViewController: UIViewController, LightboxControllerPageDelegate, LightboxControllerDismissalDelegate {
    
    let defaultLocalizer = AMPLocalizeUtils.defaultLocalizer
    @IBOutlet weak var containerView: UIView!
    @IBOutlet weak var textSubject: UILabel!
    @IBOutlet weak var textClass: UILabel!
    @IBOutlet weak var textDate: UILabel!
    @IBOutlet weak var textRemarks: UITextView!
    @IBOutlet weak var buttonAttachment: UIButton!
    
    @IBOutlet weak var labelClass: UILabel!
    @IBOutlet weak var labelSubject: UILabel!
    @IBOutlet var labelDesc: UILabel!
    
    var className: String!
    var subjectName: String!
    var date: String!
    var remarks: String!
    var Doc_path: String!
    var Doc_path2: String!
    var Doc_path3: String!
    
    override func viewDidAppear(_ animated: Bool) {
        DispatchQueue.main.async {
            self.textRemarks.scrollRangeToVisible(NSMakeRange(0, 0))
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        
        self.setNavigationBar()
        
        containerView.layer.borderWidth = 0.5
        containerView.layer.cornerRadius = 3.0
        containerView.layer.borderColor = colorWithHexString(hex: "#DDDDDD").cgColor
        containerView.layer.shadowColor = UIColor.lightGray.cgColor
        containerView.layer.shadowOffset = CGSize(width: 3, height: 3)
        containerView.layer.shadowOpacity = 0.5
        
        labelClass.text = defaultLocalizer.stringForKey(key: "labelClass")
        labelSubject.text = defaultLocalizer.stringForKey(key: "labelSubject")
        buttonAttachment.setTitle(defaultLocalizer.stringForKey(key: "buttonLabelViewAttachment"), for: .normal)
        self.labelDesc.text = self.defaultLocalizer.stringForKey(key: "labelDesc")
        textClass?.text = className
        textSubject?.text = subjectName
        textDate?.text = date
        textRemarks?.text = remarks
        buttonAttachment.isHidden = true
        
        if(Doc_path.count > 0 || Doc_path2.count > 0 || Doc_path3.count > 0)
        {
            buttonAttachment.isHidden = false
            buttonAttachment.addTarget(self, action:#selector(buttonAssignmentAttachmentTap), for:.touchUpInside)
        }
    }
    
    func setNavigationBar() {
        let navigationFont = UIFont(name: "Helvetica", size: getTitleFontSize())
        
        let button = UIButton.init(type: .custom)
        button.setTitle(self.defaultLocalizer.stringForKey(key: "navBarButtonBack"), for: UIControl.State.normal)
        var image = UIImage.init(named: "back")
        let templateImage = image?.withRenderingMode(UIImage.RenderingMode.alwaysTemplate)
        image = templateImage
        button.setImage(image, for: UIControl.State.normal)
        button.addTarget(self, action:#selector(back), for:.touchUpInside)
        button.addTarget(self, action:#selector(back), for:.touchUpOutside)
        button.frame = CGRect.init(x: 0, y: 0, width: 20, height: 20) //CGRectMake(0, 0, 30, 30)
        let doneItem = UIBarButtonItem.init(customView: button)
        self.navigationItem.leftBarButtonItem = doneItem
        
        let width = self.view.frame.width - 60
        let height = CGFloat(44)
        
        let titleLabel = UILabel(frame: CGRect.init(x: 0, y: 0, width: width, height: height))
        titleLabel.text = self.defaultLocalizer.stringForKey(key: "navBarTitleAssignmentDetails")
        titleLabel.textAlignment = .center
        titleLabel.font = navigationFont
        titleLabel.textColor = .white
        titleLabel.sizeToFit()
        self.navigationItem.titleView = titleLabel
    }
    
    @objc func back() {
        self.navigationController?.popViewController(animated: false)
    }
    
    @objc func buttonAssignmentAttachmentTap(sender: UIButton)
    {
        
        var images = [LightboxImage(imageURL: URL(string: Doc_path!)!)]
        
        if(Doc_path2!.count > 0)
        {
            images.append(LightboxImage(imageURL: URL(string: Doc_path2!)!))
        }
        
        if(Doc_path3!.count > 0)
        {
            images.append(LightboxImage(imageURL: URL(string: Doc_path3!)!))
        }
        
        // Create an instance of LightboxController.
        let controller = LightboxController(images: images)
        
        // Set delegates.
        controller.pageDelegate = self
        controller.dismissalDelegate = self
        
        // Use dynamic background.
        controller.dynamicBackground = true
        controller.modalPresentationStyle = .fullScreen
        // Present your controller.
        present(controller, animated: true, completion: nil)
    }
    
    func lightboxControllerWillDismiss(_ controller: LightboxController) {
        
    }
    
    func lightboxController(_ controller: LightboxController, didMoveToPage page: Int) {
        
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
