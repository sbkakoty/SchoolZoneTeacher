//
//  TermsViewController.swift
//  SchoolZoneTeacher
//
//  Created by Apple on 21/01/19.
//  Copyright © 2019 ClearWin Technologies. All rights reserved.
//

import UIKit
import SCLAlertView
import WebKit
import MaterialComponents

class TermsViewController: UIViewController, WKNavigationDelegate, UIGestureRecognizerDelegate {

    var opQueue = OperationQueue()
    @IBOutlet weak var containerView: UIScrollView!
    @IBOutlet weak var labelHeader: UILabel!
    @IBOutlet weak var buttonAgree: UIButton!
    @IBOutlet weak var labelButtonAgree: UILabel!
    @IBOutlet weak var cbAgree: UIButton!
    
    var langCode = String()
    var termsURL = String()
    
    let activityIndicator = MDCActivityIndicator()
    let defaultLocalizer = AMPLocalizeUtils.defaultLocalizer
    
    let appearance = SCLAlertView.SCLAppearance(
        kTitleFont: UIFont(name: "HelveticaNeue", size: 20)!,
        kTextFont: UIFont(name: "HelveticaNeue", size: 14)!,
        kButtonFont: UIFont(name: "HelveticaNeue-Bold", size: 14)!
    )
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        if(getLanguage().count > 0)
        {
            defaultLocalizer.setSelectedLanguage(lang: getLanguage())
            langCode = getLanguage()
            if(langCode == "as-IN")
            {
                termsURL = "https://www.ourschoolzone.org/terms/en.html"
            }else{
                termsURL = "https://www.ourschoolzone.org/terms/" + langCode + ".html"
            }
        }
        else
        {
            defaultLocalizer.setSelectedLanguage(lang: "en")
            langCode = "en"
            termsURL = "https://www.ourschoolzone.org/terms/en.html"
        }
        
        buttonAgree.addTarget(self, action: #selector(buttonAgreeTap), for:.touchUpInside)
        cbAgree.setBackgroundImage(UIImage(named: "unchecked"), for: .normal)
        cbAgree.setBackgroundImage(UIImage(named: "checked"), for: .selected)
        cbAgree.addTarget(self, action: #selector(cbAgreeTap), for:.touchUpInside)
        
        //labelHeader.text = defaultLocalizer.stringForKey(key: "labelTermsHeader")
        
        labelButtonAgree.text = defaultLocalizer.stringForKey(key: "labelTermsCBAgree")
        labelButtonAgree.isUserInteractionEnabled = true
        let tap = UITapGestureRecognizer(target: self, action: #selector(labelAgreeTap))
        //tap.delegate = self // This is not required
        labelButtonAgree.addGestureRecognizer(tap)
        buttonAgree.setTitle(defaultLocalizer.stringForKey(key: "labelTermsButtonContinue"), for: .normal)
        
        self.containerView.frame = CGRect(x: 0, y: self.calculateTopDistance(), width: self.view.frame.size.width, height: (self.view.frame.height - 163))
        let webview = WKWebView(frame: CGRect(x: 0, y: 5, width: self.view.frame.size.width, height: (self.view.frame.height - 163)))
        webview.navigationDelegate = self
        
        self.containerView.addSubview(webview)
        
        self.activityIndicator.sizeToFit()
        self.activityIndicator.center.x = self.view.center.x
        self.activityIndicator.center.y = self.view.center.y - 100
        webview.addSubview(activityIndicator)
        
        if let urlComponents = URLComponents(string: termsURL.addingPercentEncoding(withAllowedCharacters:NSCharacterSet.urlQueryAllowed)!) {
            guard let url = urlComponents.url else { return }
            
            getData(from: url) { data, response, error in
                let httpStatus = response as? HTTPURLResponse
                //print(httpStatus?.statusCode)
                
                if httpStatus?.statusCode != 404 {
                    DispatchQueue.main.async {
                        let urlString =  self.termsURL.addingPercentEncoding(withAllowedCharacters:NSCharacterSet.urlQueryAllowed)!
                        if let webViewURL = URL(string: urlString) {
                            let webViewURLRequest = URLRequest(url: webViewURL)
                            //webview.loadRequest(webViewURLRequest)
                            webview.load(webViewURLRequest)
                            if(webview.isLoading)
                            {
                                self.activityIndicator.startAnimating()
                            }
                        }
                    }
                }
                else
                {
                    DispatchQueue.main.async {
                        self.activityIndicator.stopAnimating()
                        let alertView = SCLAlertView(appearance: self.appearance)
                        alertView.showError("OurSchoolZone", subTitle: self.defaultLocalizer.stringForKey(key: "allertMessageNoResourceFound"), closeButtonTitle: self.defaultLocalizer.stringForKey(key: "actionSheetTitleOK"))
                    }
                }
            }
        }
    }
    
    @objc func buttonAgreeTap()
    {
        if(cbAgree.isSelected){
            let vc = self.storyboard?.instantiateViewController(withIdentifier: "vcSignin") as! SigninViewController;()
            vc.modalPresentationStyle = .fullScreen
            self.opQueue.addOperation {
                // Put queue to the main thread which will update the UI
                OperationQueue.main.addOperation({
                    self.present(vc, animated: false, completion: nil)
                })
            }
        }
        else
        {
            let alertView = SCLAlertView(appearance: self.appearance)
            
            alertView.showInfo("OurSchoolZone", subTitle: "OOps! Please accept the Terms & Conditions.", closeButtonTitle: "OK")
        }
    }
    
    @objc func labelAgreeTap(sender: UILabel) {
        cbAgree.isSelected = !cbAgree.isSelected
        if(cbAgree.isSelected)
        {
            buttonAgree.isUserInteractionEnabled = true
        }
    }
    
    @objc func cbAgreeTap(sender: UIButton) {
        sender.isSelected = !sender.isSelected
        if(cbAgree.isSelected)
        {
            buttonAgree.isUserInteractionEnabled = true
        }
    }
    
    func webView(_ webView: WKWebView, didFailProvisionalNavigation navigation: WKNavigation!, withError error: Error) {
        print(error.localizedDescription)
    }
    func webView(_ webView: WKWebView, didStartProvisionalNavigation navigation: WKNavigation!) {
        self.activityIndicator.startAnimating()
    }
    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        self.activityIndicator.stopAnimating()
    }
    
    func calculateTopDistance () -> CGFloat{
        if(self.navigationController != nil && !self.navigationController!.navigationBar.isTranslucent){
            return 0
        }else{
            
            let barHeight = self.navigationController?.navigationBar.frame.height ?? 0
            var statusBarHeight:CGFloat = 0
            
            if #available(iOS 13.0, *) {
                
                let sharedApplication = UIApplication.shared
                statusBarHeight = (sharedApplication.delegate?.window??.windowScene?.statusBarManager?.statusBarFrame)!.height

            } else {
                
                statusBarHeight = UIApplication.shared.isStatusBarHidden ? CGFloat(0) : UIApplication.shared.statusBarFrame.height
                
                if let statusBar = UIApplication.shared.value(forKey: "statusBar") as? UIView {
                    statusBar.backgroundColor = colorWithHexString(hex: "#00CCFF")
                }
            }
            
            return barHeight + statusBarHeight
        }
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
