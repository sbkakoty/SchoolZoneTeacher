//
//  NewsDetailsViewController.swift
//  SchoolZoneTeacher
//
//  Created by Apple on 23/01/19.
//  Copyright © 2019 ClearWin Technologies. All rights reserved.
//

import UIKit
import Lightbox
import WebKit

class NewsDetailsViewController: UIViewController, LightboxControllerPageDelegate, LightboxControllerDismissalDelegate, WKNavigationDelegate {

    @IBOutlet weak var containerView: UIView!
    @IBOutlet var imageView: UIImageView!
    @IBOutlet weak var textTitle: UILabel!
    @IBOutlet weak var txtDate: UILabel!
    @IBOutlet var iWebView: WKWebView!
    @IBOutlet var labelTitle: UILabel!
    @IBOutlet var labelDate: UILabel!
    @IBOutlet var labelDesc: UILabel!
    
    var newsID:Int!
    var imagePath:String!
    var newsTitle:String!
    var newsDate:String!
    var newsEndDate:String!
    var newsDesc:String!
    
    let defaultLocalizer = AMPLocalizeUtils.defaultLocalizer
    
    var activityView: UIActivityIndicatorView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        containerView.layer.borderWidth = 0.5
        containerView.layer.cornerRadius = 3.0
        containerView.layer.borderColor = colorWithHexString(hex: "#DDDDDD").cgColor
        containerView.layer.shadowColor = UIColor.lightGray.cgColor
        containerView.layer.shadowOffset = CGSize(width: 3, height: 3)
        containerView.layer.shadowOpacity = 0.5
        
        imageView.layer.borderWidth = 0.5
        imageView.layer.cornerRadius = 0.0
        imageView.layer.borderColor = colorWithHexString(hex: "#DDDDDD").cgColor
        imageView.layer.shadowColor = UIColor.lightGray.cgColor
        imageView.layer.shadowOffset = CGSize(width: 1, height: 1)
        imageView.layer.shadowOpacity = 0.5
        self.imageView.isUserInteractionEnabled = true
        let tapgesture = UITapGestureRecognizer(target: self , action: #selector(self.zoomImage))
        self.imageView.addGestureRecognizer(tapgesture)
        
        if(getLanguage().count > 0)
        {
            defaultLocalizer.setSelectedLanguage(lang: getLanguage())
        }
        else
        {
            defaultLocalizer.setSelectedLanguage(lang: "en")
        }
        
        let dateFormatterGet = DateFormatter()
        dateFormatterGet.dateFormat = "dd-MM-yyyy"

        self.setNavigationBar()
        
        self.labelTitle.text = self.defaultLocalizer.stringForKey(key: "placeHolderSubject")
        self.labelDate.text = self.defaultLocalizer.stringForKey(key: "placeHolderDate")
        self.labelDesc.text = self.defaultLocalizer.stringForKey(key: "labelDesc")
        
        self.textTitle.text = newsTitle
        let dateStart = dateFormatterGet.date(from: newsDate)
        self.txtDate.text = dateFormatterGet.string(from: dateStart!)
        
        if let url = URL(string: imagePath!) {
            getImageData(from: url) { data, response, error in
                guard let data = data, error == nil else {
                    return
                }
                DispatchQueue.main.async() {
                    self.imageView.image = UIImage(data: data)
                }
            }
        }
        
        var headerString = "<header><meta name='viewport' content='width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0'></header>"
        headerString.append(newsDesc)
        iWebView.loadHTMLString(updateDataWithFont(data:headerString), baseURL: nil)
        iWebView.navigationDelegate = self
        // add activity
        activityView = UIActivityIndicatorView(style: .gray)
        activityView.center = self.iWebView.center
        activityView.startAnimating()
        self.view.addSubview(activityView)
        activityView.hidesWhenStopped = true
        
        self.addReadNews()
    }
    
    func addReadNews(){
        
        let teacherid = getTeacherId()
        let schoolid = getSchoolId()
        
        let queryString = "school_id=\(schoolid)&news_id=\(self.newsID!)&teacher_id=\(teacherid)"
        
        //print("newasread URL: \(queryString)")
        
        if var urlComponents = URLComponents(string: Constants.baseUrl + "AddNewsReadTeacher") {
            urlComponents.query = queryString
            // 3
            guard let url = urlComponents.url else { return}
            
            //print("\nnewasread URL: \(url)")
            
            var request = URLRequest(url: url)
            request.httpMethod = "POST"
            
            postData(from: request) { data, response, error in
                if let httpStatus = response as? HTTPURLResponse, httpStatus.statusCode != 200 {
                    //let responseMessage = String(describing: response)
                    return
                }
            }
        }
    }
    
    @objc func zoomImage(_ sender: UITapGestureRecognizer)
    {
        //print("zoomImageTap")
        let images = [LightboxImage(imageURL: URL(string: imagePath)!)]
        
        // Create an instance of LightboxController.
        let controller = LightboxController(images: images)
        
        // Set delegates.
        controller.pageDelegate = self
        controller.dismissalDelegate = self
        
        // Use dynamic background.
        controller.dynamicBackground = true
        controller.modalPresentationStyle = .fullScreen
        // Present your controller.
        present(controller, animated: true, completion: nil)
    }
    
    func setNavigationBar() {
        let navigationFont = UIFont(name: "Helvetica", size: getTitleFontSize())
        
        let button = UIButton.init(type: .custom)
        button.setTitle(self.defaultLocalizer.stringForKey(key: "navBarButtonBack"), for: UIControl.State.normal)
        var image = UIImage.init(named: "back")
        let templateImage = image?.withRenderingMode(UIImage.RenderingMode.alwaysTemplate)
        image = templateImage
        button.setImage(image, for: UIControl.State.normal)
        button.addTarget(self, action:#selector(back), for:.touchUpInside)
        button.addTarget(self, action:#selector(back), for:.touchUpOutside)
        button.frame = CGRect.init(x: 0, y: 0, width: 20, height: 20) //CGRectMake(0, 0, 30, 30)
        let doneItem = UIBarButtonItem.init(customView: button)
        self.navigationItem.leftBarButtonItem = doneItem
        
        let width = self.view.frame.width - 60
        let height = CGFloat(44)
        
        let titleLabel = UILabel(frame: CGRect.init(x: 0, y: 0, width: width, height: height))
        titleLabel.text = self.defaultLocalizer.stringForKey(key: "navBarTitleNewsDetails")
        titleLabel.textAlignment = .center
        titleLabel.font = navigationFont
        titleLabel.textColor = .white
        titleLabel.sizeToFit()
        self.navigationItem.titleView = titleLabel
    }
    
    @objc func back() { // remove @objc for Swift 3
        self.navigationController?.popViewController(animated: false)
    }
    
    func position(for bar: UIBarPositioning) -> UIBarPosition {
        return .topAttached
    }
    
    func lightboxControllerWillDismiss(_ controller: LightboxController) {
        
    }
    
    func lightboxController(_ controller: LightboxController, didMoveToPage page: Int) {
        
    }
    
    func webView(_ webView: WKWebView, didFinish navigation:
        WKNavigation!) {
        self.activityView.stopAnimating()
    }
    
    func webView(_ webView: WKWebView, didStartProvisionalNavigation
        navigation: WKNavigation!) {
        self.activityView.startAnimating()
    }
    
    func webView(_ webView: WKWebView, didFail navigation:
        WKNavigation!, withError error: Error) {
        self.activityView.stopAnimating()
    }
    
    func updateDataWithFont(data:String)->String{
        return String(format: "<html><body><span style=\"font-family:%@;font-size:%@;text-align:justify\">%@</span></body></html>","Helvetica","12px",data)
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
