//
//  ExamReportCardViewController.swift
//  SchoolZoneTeacher
//
//  Created by Apple on 04/03/19.
//  Copyright © 2019 ClearWin Technologies. All rights reserved.
//

import UIKit

class ExamReportCardViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {

    @IBOutlet weak var containerView: UIView!
    @IBOutlet weak var profileImageView: UIImageView!
    @IBOutlet weak var labelStudentName: UILabel!
    @IBOutlet weak var labelClass: UILabel!
    @IBOutlet weak var tableViewMarkContainer: UIScrollView!
    @IBOutlet weak var labelGrandTotal: UILabel!
    @IBOutlet weak var labelGrandTotalMarksSecured: UILabel!
    @IBOutlet weak var labelExamName: UILabel!
    @IBOutlet weak var labelType: UILabel!
    @IBOutlet var staticLabelSubject: UILabel!
    @IBOutlet var staticLabelTotalMarks: UILabel!
    @IBOutlet var staticLabelMarksSecured: UILabel!
    @IBOutlet var staticLabelGrandTotal: UILabel!
    @IBOutlet var staticLabelExamName: UILabel!
    @IBOutlet var staticLabelExamType: UILabel!
    @IBOutlet var staticLabelClass: UILabel!
    
    let defaultLocalizer = AMPLocalizeUtils.defaultLocalizer
    
    var tableView = UITableView()
    var imagePath = String()
    var studentName = String()
    var className = String()
    var rollNumber = String()
    var examName = String()
    var examType = String()
    var ExamMarks:[ExamMark]?
    var GrandTotalMarks = 0
    var GrandTotalMarksSecured = 0
    
    override func viewDidAppear(_ animated: Bool) {

        if #available(iOS 13, *)
        {
            let statusBar = UIView(frame: (UIApplication.shared.keyWindow?.windowScene?.statusBarManager?.statusBarFrame)!)
            statusBar.backgroundColor = colorWithHexString(hex: "#00CCFF")
            UIApplication.shared.keyWindow?.addSubview(statusBar)
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        if(getLanguage().count > 0)
        {
            defaultLocalizer.setSelectedLanguage(lang: getLanguage())
        }
        else
        {
            defaultLocalizer.setSelectedLanguage(lang: "en")
        }
        
        self.setNavigationBar()
        
        if let url = URL(string: imagePath) {
            getData(from: url) { data, response, error in
                guard let data = data, error == nil else { return }
                
                DispatchQueue.main.async() {
                    self.profileImageView.image = UIImage(data: data)
                    self.profileImageView.contentMode = UIView.ContentMode.scaleAspectFit
                    self.profileImageView.backgroundColor = UIColor.white
                    self.profileImageView.layer.cornerRadius = 40
                    self.profileImageView.tintColor = colorWithHexString(hex: "#00CCFF")
                    self.profileImageView.layer.masksToBounds = true
                }
            }
        }
        
        self.staticLabelSubject.text = self.defaultLocalizer.stringForKey(key: "labelSubject")
        self.staticLabelTotalMarks.text = self.defaultLocalizer.stringForKey(key: "labelMaximumMarks")
        self.staticLabelMarksSecured.text = self.defaultLocalizer.stringForKey(key: "labelMarksSecured")
        self.staticLabelGrandTotal.text = self.defaultLocalizer.stringForKey(key: "labelTotalMarks")
        self.staticLabelExamName.text = self.defaultLocalizer.stringForKey(key: "labelExamName")
        self.staticLabelExamType.text = self.defaultLocalizer.stringForKey(key: "labelExamType")
        self.labelStudentName.text = self.studentName
        self.staticLabelClass.text = self.defaultLocalizer.stringForKey(key: "labelClass")
        self.labelClass.text = " \(self.className)"
        
        self.tableView = UITableView(frame: CGRect(x: 0, y: 0, width: self.view.frame.size.width, height: self.tableViewMarkContainer.frame.size.height), style: UITableView.Style.plain)
        self.tableView.dataSource = self
        self.tableView.delegate = self
        self.tableView.register(UINib(nibName: "ExamSubjectWiseMarksTableViewCell", bundle: nil), forCellReuseIdentifier: "ExamSubjectMarksCell")
        self.tableView.rowHeight = 34.0// UITableView.automaticDimension
        self.tableView.estimatedRowHeight = 34.0
        self.tableView.separatorStyle = .none
        self.tableView.backgroundColor = UIColor.white
        self.tableViewMarkContainer.addSubview(self.tableView)
        
        for varObject in self.ExamMarks! {
            if(varObject.max_marks!.count > 0)
            {
                GrandTotalMarks += Int(varObject.max_marks!)!
            }
            if(varObject.marks!.count > 0)
            {
                GrandTotalMarksSecured += Int(varObject.marks!)!
            }
        }
        
        labelGrandTotal.text = String(GrandTotalMarks)
        labelGrandTotalMarksSecured.text = String(GrandTotalMarksSecured)
        
        labelExamName.text = examName
        labelType.text = examType
    }
    
    func setNavigationBar() {
        let navigationFont = UIFont(name: "Helvetica", size: getTitleFontSize())
        let screenSize: CGRect = UIScreen.main.bounds
        let statusBarHeight = UIApplication.shared.isStatusBarHidden ? CGFloat(0) : UIApplication.shared.statusBarFrame.height
        let navBar: UINavigationBar = UINavigationBar(frame: CGRect(x: 0, y: statusBarHeight, width: screenSize.width, height: 44))
        self.view.addSubview(navBar)
        
        let navItem = UINavigationItem(title: self.defaultLocalizer.stringForKey(key: "navBarTitleExamMarksheet"))
        let button = UIButton.init(type: .custom)
        button.setTitle(self.defaultLocalizer.stringForKey(key: "navBarButtonBack"), for: UIControl.State.normal)
        var image = UIImage.init(named: "back")
        let templateImage = image?.withRenderingMode(UIImage.RenderingMode.alwaysTemplate)
        image = templateImage
        button.setImage(image, for: UIControl.State.normal)
        button.addTarget(self, action:#selector(back), for:.touchUpInside)
        button.addTarget(self, action:#selector(back), for:.touchUpOutside)
        button.frame = CGRect.init(x: 0, y: 0, width: 20, height: 20) //CGRectMake(0, 0, 30, 30)
        let doneItem = UIBarButtonItem.init(customView: button)
        
        //let doneItem = UIBarButtonItem(title: self.defaultLocalizer.stringForKey(key: "navBarButtonBack"), style: .plain, target: self, action: #selector(back))
        navItem.leftBarButtonItem = doneItem
        
        navBar.setItems([navItem], animated: false)
        navBar.backgroundColor = colorWithHexString(hex: "#00CCFF")
        navBar.isTranslucent = false
        navBar.titleTextAttributes = [
            NSAttributedString.Key.foregroundColor : UIColor.white, NSAttributedString.Key.font: navigationFont!, NSAttributedString.Key.shadow: setNavBarTitleShadow()
        ]
        
        if #available(iOS 11, *){
            navBar.titleTextAttributes = [NSAttributedString.Key.foregroundColor: UIColor.white, NSAttributedString.Key.font: navigationFont!, NSAttributedString.Key.shadow: setNavBarTitleShadow()]
        }
    }
    
    @objc func back() { // remove @objc for Swift 3
        self.dismiss(animated: false, completion: nil)
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "ExamSubjectMarksCell") as! ExamSubjectWiseMarksTableViewCell
        
        let examMarksModel: ExamMark?
        examMarksModel = self.ExamMarks?[indexPath.row]
        cell.textSubjectName?.text = examMarksModel?.subject_name
        cell.textTotalMarks?.text = examMarksModel?.max_marks
        cell.textSubjectMarks?.text = examMarksModel?.marks
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return ExamMarks?.count ?? 0
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
}
