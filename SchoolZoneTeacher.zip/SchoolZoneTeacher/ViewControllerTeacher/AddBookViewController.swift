//
//  AddBookViewController.swift
//  SchoolZoneTeacher
//
//  Created by Apple on 24/02/19.
//  Copyright © 2019 ClearWin Technologies. All rights reserved.
//

import UIKit
import SCLAlertView
import iOSDropDown
import MaterialComponents

class AddBookViewController: UIViewController, UITextFieldDelegate {

    let defaultLocalizer = AMPLocalizeUtils.defaultLocalizer
    let activityIndicator = MDCActivityIndicator()
    var containerView = UIView()
    var response:Response?
    var classsections:[Classsection]?
    var subjects:[Subject]?
    var classIds = [Int]()
    var classNames = [String]()
    var subjectIds = [Int]()
    var subjectNames = [String]()

    var dropDownClass = DropDown()
    var dropDownSubject = DropDown()
    var txtBookName = UITextField()
    var txtBookChapterName = UITextField()
    var txtChapterIndex = UITextField()
    var schoolid = Int()
    var classId = Int()
    var subjectId = Int()
    var bookId = Int()
    var buttonSubmit = UIButton()
    
    let appearance = SCLAlertView.SCLAppearance(
        kTitleFont: UIFont(name: "HelveticaNeue", size: 20)!,
        kTextFont: UIFont(name: "HelveticaNeue", size: 14)!,
        kButtonFont: UIFont(name: "HelveticaNeue-Bold", size: 14)!
    )
    
    func textFieldDidBeginEditing(_ textField: UITextField)  {
        textField.tintColor = UIColor.gray
    }
    
    override func viewDidAppear(_ animated: Bool) {

        if #available(iOS 13, *)
        {
            let statusBar = UIView(frame: (UIApplication.shared.keyWindow?.windowScene?.statusBarManager?.statusBarFrame)!)
            statusBar.backgroundColor = colorWithHexString(hex: "#00CCFF")
            UIApplication.shared.keyWindow?.addSubview(statusBar)
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        dropDownClassShared.dropdownClassShared.isShown = 0
        dropDownSubjectShared.dropdownSubjectShared.isShown = 0
        dropDownBookShared.dropdownBookShared.isShown = 0
        dropDownBookChapterShared.dropdownBookChapterShared.isShown = 0
        
        if(getLanguage().count > 0)
        {
            defaultLocalizer.setSelectedLanguage(lang: getLanguage())
        }
        else
        {
            defaultLocalizer.setSelectedLanguage(lang: "en")
        }
        
        self.setNavigationBar()
        self.loadAddBookView()
    }
    
    func setNavigationBar() {
        let navigationFont = UIFont(name: "Helvetica", size: getTitleFontSize())
        let screenSize: CGRect = UIScreen.main.bounds
        let statusBarHeight = UIApplication.shared.isStatusBarHidden ? CGFloat(0) : UIApplication.shared.statusBarFrame.height
        let navBar: UINavigationBar = UINavigationBar(frame: CGRect(x: 0, y: statusBarHeight, width: screenSize.width, height: 44))
        self.view.addSubview(navBar)
        
        let navItem = UINavigationItem(title: self.defaultLocalizer.stringForKey(key: "navBarTitleNewBook"))
        let button = UIButton.init(type: .custom)
        button.setTitle(self.defaultLocalizer.stringForKey(key: "navBarButtonBack"), for: UIControl.State.normal)
        var image = UIImage.init(named: "back")
        let templateImage = image?.withRenderingMode(UIImage.RenderingMode.alwaysTemplate)
        image = templateImage
        button.setImage(image, for: UIControl.State.normal)
        button.addTarget(self, action:#selector(back), for:.touchUpInside)
        button.addTarget(self, action:#selector(back), for:.touchUpOutside)
        button.frame = CGRect.init(x: 0, y: 0, width: 60, height: 44) //CGRectMake(0, 0, 30, 30)
        let doneItem = UIBarButtonItem.init(customView: button)
        
        //let doneItem = UIBarButtonItem(title: "Back", style: .plain, target: self, action: #selector(back))
        navItem.leftBarButtonItem = doneItem
        
        navBar.setItems([navItem], animated: false)
        navBar.backgroundColor = colorWithHexString(hex: "#00CCFF")
        navBar.isTranslucent = false
        navBar.titleTextAttributes = [
            NSAttributedString.Key.foregroundColor : UIColor.white, NSAttributedString.Key.font: navigationFont!, NSAttributedString.Key.shadow: setNavBarTitleShadow()
        ]
        
        if #available(iOS 11, *){
            navBar.titleTextAttributes = [NSAttributedString.Key.foregroundColor: UIColor.white, NSAttributedString.Key.font: navigationFont!, NSAttributedString.Key.shadow: setNavBarTitleShadow()]
        }
    }
    
    @objc func back() { // remove @objc for Swift 3
        
        self.dismiss(animated: false, completion: nil)
    }
    
    func position(for bar: UIBarPositioning) -> UIBarPosition {
        return .topAttached
    }
    
    func calculateTopDistance () -> CGFloat{
        if(self.navigationController != nil && !self.navigationController!.navigationBar.isTranslucent){
            return 0
        }else{
            let barHeight=self.navigationController?.navigationBar.frame.height ?? 0
            let statusBarHeight = UIApplication.shared.isStatusBarHidden ? CGFloat(0) : UIApplication.shared.statusBarFrame.height
            return barHeight + statusBarHeight
        }
    }
    
    func loadAddBookView() {
        let scroolHeight = self.view.frame.size.height - (self.calculateTopDistance() + 48)
        self.containerView = UIView(frame: CGRect(x: 0, y: self.calculateTopDistance() + 48, width: self.view.frame.size.width, height: scroolHeight))
        
        self.removeSubView()
        
        self.dropDownClass = DropDown(frame: CGRect(x: 10, y: 10, width: ((containerView.frame.size.width / 2) - 15), height: 50))
        self.setDropdown(height: scroolHeight - 76, dropDown: self.dropDownClass, text: self.defaultLocalizer.stringForKey(key: "dropDownLabelClass"), optionNames: classNames, optionIds: classIds)
        
        self.dropDownClass.listWillAppear {
            //You can Do anything when iOS DropDown listDidAppear
            dropDownClassShared.dropdownClassShared.isShown = 1
        }
        
        // The the Closure returns Selected Index and String
        self.dropDownClass.didSelect{(selectedText , index ,id) in
            self.dropDownClass.textColor = UIColor.black
            self.classId = id
            
            self.dropDownSubject.text = String()
            
            self.loadSubjects(classId: self.classId)
        }
        
        self.dropDownSubject = DropDown(frame: CGRect(x: ((containerView.frame.size.width / 2) + 5), y: 10, width: ((containerView.frame.size.width / 2) - 15), height: 50))
        self.setDropdown(height: scroolHeight - 60, dropDown: self.dropDownSubject, text: self.defaultLocalizer.stringForKey(key: "dropDownLabelSubject"), optionNames: subjectNames, optionIds: subjectIds)
        
        self.dropDownSubject.listWillAppear {
            //You can Do anything when iOS DropDown listDidAppear
            dropDownSubjectShared.dropdownSubjectShared.isShown = 1
        }
        
        // The the Closure returns Selected Index and String
        self.dropDownSubject.didSelect{(selectedText , index ,id) in
            self.dropDownSubject.textColor = UIColor.black
            self.subjectId = id
        }
        
        txtBookName = UITextField(frame: CGRect(x: 10, y: 70, width: containerView.frame.size.width - 20, height: 50))
        txtBookName.borderStyle = .roundedRect
        txtBookName.attributedPlaceholder = NSAttributedString(string: self.defaultLocalizer.stringForKey(key: "placeHolderBookName"),
                                                               attributes: [NSAttributedString.Key.foregroundColor: UIColor.lightGray])
        txtBookName.delegate = self
        
        //init toolbar
        let toolbar:UIToolbar = UIToolbar(frame: CGRect(x: 0, y: 0,  width: self.view.frame.size.width, height: 30))
        //create left side empty space so that done button set on right side
        let flexSpace = UIBarButtonItem(barButtonSystemItem:    .flexibleSpace, target: nil, action: nil)
        let doneBtn: UIBarButtonItem = UIBarButtonItem(title: self.defaultLocalizer.stringForKey(key: "toolBarButtonTitleDone"), style: .done, target: self, action: #selector(doneButtonAction))
        toolbar.setItems([flexSpace, doneBtn], animated: false)
        toolbar.sizeToFit()
        //setting toolbar as inputAccessoryView
        self.txtBookName.inputAccessoryView = toolbar
        
        self.buttonSubmit = UIButton(frame: CGRect(x: ((containerView.frame.size.width / 2) + 5), y: 130, width: ((containerView.frame.size.width / 2) - 15), height: 50))
        self.setSubmitButtonAppearence(buttonSubmit: buttonSubmit, buttonText: self.defaultLocalizer.stringForKey(key: "buttonLabelSubmit"))
        buttonSubmit.addTarget(self, action: #selector(addBook), for:.touchUpInside)
        buttonSubmit.addTarget(self, action: #selector(addBook), for:.touchUpOutside)
        
        containerView.insertSubview(buttonSubmit, at: 0)
        containerView.insertSubview(txtBookName, at: 1)
        containerView.insertSubview(self.dropDownClass, at: 2)
        containerView.insertSubview(self.dropDownSubject, at: 3)
        
        self.view.addSubview(containerView)
        
        self.activityIndicator.sizeToFit()
        self.activityIndicator.center.x = super.view.center.x
        self.activityIndicator.center.y = (super.view.center.y - 50)
        self.view.addSubview(activityIndicator)
        
        self.loadClass()
    }
    
    @objc func doneButtonAction() {
        self.view.endEditing(true)
    }
    
    func loadClass() {
        
        let alertView = SCLAlertView(appearance: self.appearance)
        
        if(dropDownSubjectShared.dropdownSubjectShared.isShown == 1)
        {
            dropDownSubjectShared.dropdownSubjectShared.isShown = 0
            self.dropDownSubject.hideList()
        }
        
        self.activityIndicator.startAnimating()
        let schoolid = getSchoolId()
        self.dropDownSubject.delegate = self
        
        self.classIds.removeAll()
        self.classNames.removeAll()
        let teacherid = getTeacherId()
        if var urlComponents = URLComponents(string: Constants.baseUrl + "ClassV2") {
            urlComponents.query = "schoolid=" + schoolid + "&teacherid=" + teacherid
            // 3
            guard let url = urlComponents.url else { return}
            
            getData(from: url) { data, response, error in
                if error != nil {
                    self.activityIndicator.stopAnimating()
                    print(error!.localizedDescription)
                    DispatchQueue.main.async {
                        alertView.showInfo("OurSchoolZone", subTitle: self.defaultLocalizer.stringForKey(key: "allertMessageFetchdataError"), closeButtonTitle: self.defaultLocalizer.stringForKey(key: "actionSheetTitleOK"))
                    }
                }
                
                guard let data = data else { return}
                //Implement JSON decoding and parsing
                do {
                    //Decode retrived data with JSONDecoder and assing type of Article object
                    let classData = try JSONDecoder().decode(Result.self, from: data)
                    
                    //Get back to the main queue
                    DispatchQueue.main.async {
                        self.activityIndicator.stopAnimating()
                        self.classsections = classData.ClassList
                        self.response = classData.Response
                        if(self.response?.ResponseVal == 1){
                            for classsection in self.classsections!
                            {
                                self.classIds.append(classsection.id)
                                self.classNames.append("   " + classsection.Classsecname)
                            }
                            
                            if(self.classIds.count > 0 && self.classNames.count > 0){
                                // The list of array to display. Can be changed dynamically
                                self.dropDownClass.optionArray = self.classNames
                                // Its Id Values and its optional
                                self.dropDownClass.optionIds = self.classIds
                            }
                        }
                    }
                } catch let jsonError {
                    self.activityIndicator.stopAnimating()
                    print(jsonError)
                }
            }
        }
    }
    
    func loadSubjects(classId: Int) {
        
        let alertView = SCLAlertView(appearance: self.appearance)
        
        if(dropDownSubjectShared.dropdownSubjectShared.isShown == 1)
        {
            dropDownSubjectShared.dropdownSubjectShared.isShown = 0
            self.dropDownSubject.hideList()
        }
        
        self.subjectIds.removeAll()
        self.subjectNames.removeAll()
        // The list of array to display. Can be changed dynamically
        self.dropDownSubject.optionArray = self.subjectNames
        // Its Id Values and its optional
        self.dropDownSubject.optionIds = self.subjectIds
        let schoolid = getSchoolId()
        let teacherid = getTeacherId()
        
        if var urlComponents = URLComponents(string: Constants.baseUrl + "SubjectV2") {
            urlComponents.query = "schoolid=" + schoolid + "&classid=" + "\(classId)" + "&teacherid=" + teacherid
            // 3
            guard let url = urlComponents.url else { return}
            
            getData(from: url) { data, response, error in
                if error != nil {
                    print(error!.localizedDescription)
                    DispatchQueue.main.async {
                        alertView.showInfo("OurSchoolZone", subTitle: self.defaultLocalizer.stringForKey(key: "allertMessageFetchdataError"), closeButtonTitle: self.defaultLocalizer.stringForKey(key: "actionSheetTitleOK"))
                    }
                }
                
                guard let data = data else { return}
                //Implement JSON decoding and parsing
                do {
                    //Decode retrived data with JSONDecoder and assing type of Article object
                    let subjectData = try JSONDecoder().decode(Result.self, from: data)
                    
                    //Get back to the main queue
                    DispatchQueue.main.async {
                        self.subjects = subjectData.SubjectList
                        
                        self.response = subjectData.Response
                        if(self.response?.ResponseVal == 1){
                            for subject in self.subjects!
                            {
                                self.subjectIds.append(subject.id)
                                self.subjectNames.append("   " + subject.Subjectname)
                            }
                            
                            if(self.subjectIds.count > 0 && self.subjectNames.count > 0){
                                // The list of array to display. Can be changed dynamically
                                self.dropDownSubject.optionArray = self.subjectNames
                                // Its Id Values and its optional
                                self.dropDownSubject.optionIds = self.subjectIds
                            }
                        }
                    }
                } catch let jsonError {
                    print(jsonError)
                    alertView.showInfo("OurSchoolZone", subTitle: self.defaultLocalizer.stringForKey(key: "allertMessageFetchdataError"), closeButtonTitle: self.defaultLocalizer.stringForKey(key: "actionSheetTitleOK"))
                }
            }
        }
    }
    
    func setSubmitButtonAppearence(buttonSubmit: UIButton, buttonText: String){
        
        buttonSubmit.tintColor = UIColor.white
        buttonSubmit.backgroundColor = colorWithHexString(hex: "#00FFCC")
        buttonSubmit.layer.masksToBounds = false
        buttonSubmit.layer.borderColor = colorWithHexString(hex: "#DDDDDD").cgColor
        buttonSubmit.layer.shadowColor = UIColor(red: 0, green: 0, blue: 0, alpha: 0.25).cgColor
        buttonSubmit.layer.shadowOffset = CGSize(width: 1.0, height: 5.0)
        buttonSubmit.layer.shadowOpacity = 1.0
        buttonSubmit.layer.shadowRadius = 5.0
        buttonSubmit.layer.masksToBounds = false
        buttonSubmit.layer.cornerRadius = 3.0
        buttonSubmit.isMultipleTouchEnabled = false
        
        let imageView = UIImageView(frame: CGRect(x: 5, y: 5, width: 40, height: 40))
        imageView.image = UIImage(named: "ok")
        
        let buttonLabel = UILabel(frame: CGRect(x: 40, y: 0, width: buttonSubmit.frame.width - 40, height: 50))
        buttonLabel.textColor = UIColor.white
        buttonLabel.font = UIFont(name:"HelveticaNeue-Bold", size: 16.0)
        buttonLabel.textAlignment = .left
        buttonLabel.text = buttonText
        
        buttonSubmit.addSubview(imageView)
        buttonSubmit.addSubview(buttonLabel)
    }
    
    func setDropdown(height: CGFloat, dropDown: DropDown, text: String, optionNames: [String], optionIds: [Int])
    {
        dropDown.placeholder = text
        //dropDown.font = UIFont.systemFont(ofSize: 14.00)
        dropDown.textColor = UIColor.lightGray
        dropDown.backgroundColor = UIColor.white
        dropDown.rowBackgroundColor = UIColor.white
        dropDown.borderWidth = 0.5
        dropDown.borderColor = colorWithHexString(hex: "#DDDDDD")
        dropDown.cornerRadius = 3
        dropDown.selectedRowColor = colorWithHexString(hex: "#DDDDDD")
        dropDown.arrowSize = 10
        dropDown.isSearchEnable = false
        // The list of array to display. Can be changed dynamically
        dropDown.optionArray = optionNames
        // Its Id Values and its optional
        dropDown.optionIds = optionIds
        dropDown.rowHeight = CGFloat(50)
        dropDown.listHeight = height
    }
    
    func removeSubView()
    {
        if let viewWithTag = self.view.viewWithTag(100) {
            viewWithTag.removeFromSuperview()
        }
        if let viewWithTag = self.view.viewWithTag(201) {
            viewWithTag.removeFromSuperview()
        }
        if let viewWithTag = self.view.viewWithTag(202) {
            viewWithTag.removeFromSuperview()
        }
        if let viewWithTag = self.view.viewWithTag(7575) {
            viewWithTag.removeFromSuperview()
        }
    }
    
    @objc func addBook()
    {
        self.schoolid = Int(getSchoolId())!
        
        let alertView = SCLAlertView(appearance: self.appearance)
        
        if(self.classId == 0)
        {
            alertView.showInfo("OurSchoolZone", subTitle: self.defaultLocalizer.stringForKey(key: "allertMessageSelectClass"), closeButtonTitle: self.defaultLocalizer.stringForKey(key: "actionSheetTitleOK"))
            return
        }
        
        if(self.subjectId == 0)
        {
            alertView.showInfo("OurSchoolZone", subTitle: self.defaultLocalizer.stringForKey(key: "allertMessageSelectSubject"), closeButtonTitle: self.defaultLocalizer.stringForKey(key: "actionSheetTitleOK"))
            return
        }
        
        if(self.txtBookName.text!.count == 0)
        {
            alertView.showInfo("OurSchoolZone", subTitle: self.defaultLocalizer.stringForKey(key: "allertMessageEnterBook"), closeButtonTitle: self.defaultLocalizer.stringForKey(key: "actionSheetTitleOK"))
            return
        }
        
        let bookName = self.txtBookName.text!
        
        self.buttonSubmit.isUserInteractionEnabled = false;
        
        let queryString = "schoolid=" + "\(self.schoolid)" + "&classid=" + "\(self.classId)" + "&subjectid=" + "\(self.subjectId)" + "&bookname=" + "\(bookName)"
        
        // To make the activity indicator appear:
        self.activityIndicator.startAnimating()
        
        if var urlComponents = URLComponents(string: Constants.baseUrl + "AddBook") {
            urlComponents.query = queryString
            // 3
            guard let url = urlComponents.url else { return}
            
            var request = URLRequest(url: url)
            request.httpMethod = "POST"
            
            postData(from: request) { data, response, error in
                
                if let httpStatus = response as? HTTPURLResponse, httpStatus.statusCode != 200 {
                    //let responseMessage = String(describing: response)
                    
                    //Get back to the main queue
                    DispatchQueue.main.async {
                        self.activityIndicator.stopAnimating()
                        
                        alertView.showError("OurSchoolZone", subTitle: self.defaultLocalizer.stringForKey(key: "allertMessageBookSubmitError"), closeButtonTitle: self.defaultLocalizer.stringForKey(key: "actionSheetTitleOK"))
                        
                        self.buttonSubmit.isUserInteractionEnabled = true;
                    }
                    return
                }
                else
                {
                    //Get back to the main queue
                    DispatchQueue.main.async {
                        self.activityIndicator.stopAnimating()
                        
                        self.resetInputFileds()
                        alertView.showSuccess("OurSchoolZone", subTitle: self.defaultLocalizer.stringForKey(key: "allertMessageBookSubmitSuccess"), closeButtonTitle: self.defaultLocalizer.stringForKey(key: "actionSheetTitleOK"))
                    }
                }
            }
        }
    }
    
    func resetInputFileds()
    {
        self.dropDownClass.text = String()
        self.dropDownSubject.text = String()
        self.dropDownClass.placeholder = self.defaultLocalizer.stringForKey(key: "dropDownLabelClass")
        self.dropDownSubject.placeholder = self.defaultLocalizer.stringForKey(key: "dropDownLabelSubject")
        self.dropDownClass.isSelected = false
        self.dropDownSubject.isSelected = false
        self.txtBookName.text = String()
        
        self.buttonSubmit.isUserInteractionEnabled = true;
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
