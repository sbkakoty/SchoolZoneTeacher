//
//  PopOverViewController.swift
//  SchoolZoneTeacher
//
//  Created by Apple on 16/12/18.
//  Copyright © 2018 ClearWin Technologies. All rights reserved.
//

import UIKit

class PopOverViewController: UIViewController {
    
    let defaultLocalizer = AMPLocalizeUtils.defaultLocalizer
    
    @IBOutlet weak var menuAnnouncement: UIButton!
    @IBOutlet weak var menuRemarks: UIButton!
    @IBOutlet weak var menuAbsentReport: UIButton!
    @IBOutlet weak var menuBooks: UIButton!
    @IBOutlet weak var menuClassTimeTable: UIButton!
    @IBOutlet weak var menuExam: UIButton!
    @IBOutlet weak var menuHolidayList: UIButton!
    @IBOutlet weak var menuEvents: UIButton!
    @IBOutlet weak var menuSettings: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        if(getLanguage().count > 0)
        {
            defaultLocalizer.setSelectedLanguage(lang: getLanguage())
        }
        else
        {
            defaultLocalizer.setSelectedLanguage(lang: "en")
        }
        
        menuAnnouncement.setTitle(self.defaultLocalizer.stringForKey(key: "menuTitleAnnouncement"), for: .normal)
        menuRemarks.setTitle(self.defaultLocalizer.stringForKey(key: "menuTitleRemarks"), for: .normal)
        menuAbsentReport.setTitle(self.defaultLocalizer.stringForKey(key: "menuTitleAbsentReport"), for: .normal)
        menuBooks.setTitle(self.defaultLocalizer.stringForKey(key: "menuTitleBooks"), for: .normal)
        menuClassTimeTable.setTitle(self.defaultLocalizer.stringForKey(key: "menuTitleClassTimetable"), for: .normal)
        menuExam.setTitle(self.defaultLocalizer.stringForKey(key: "menuTitleExamination"), for: .normal)
        menuHolidayList.setTitle(self.defaultLocalizer.stringForKey(key: "menuTitleHolidayList"), for: .normal)
        menuEvents.setTitle(self.defaultLocalizer.stringForKey(key: "menuTitleEvents"), for: .normal)
        menuSettings.setTitle(self.defaultLocalizer.stringForKey(key: "menuTitleSettings"), for: .normal)
    }
    
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
        if segue.identifier == "segueAnnouncement" {
            let vc = self.storyboard?.instantiateViewController(withIdentifier: "vcAnnouncement") as! AnnouncementViewController
            vc.modalPresentationStyle = .fullScreen
            vc.popoverVC = self
            self.present(vc, animated: true, completion: nil)
        }
        if segue.identifier == "segueRemarks" {
            let vc = self.storyboard?.instantiateViewController(withIdentifier: "vcRemarks") as! RemarksViewController
            vc.modalPresentationStyle = .fullScreen
            vc.popoverVC = self
            self.present(vc, animated: true, completion: nil)
        }
        if segue.identifier == "segueAR" {
            let vc = self.storyboard?.instantiateViewController(withIdentifier: "vcAR") as! AbsentReportViewController
            vc.modalPresentationStyle = .fullScreen
            vc.popoverVC = self
            self.present(vc, animated: true, completion: nil)
        }
        if segue.identifier == "segueBooks" {
            let vc = self.storyboard?.instantiateViewController(withIdentifier: "vcBooks") as! BooksViewController
            vc.modalPresentationStyle = .fullScreen
            vc.popoverVC = self
            self.present(vc, animated: true, completion: nil)
        }
        if segue.identifier == "segueCTT" {
            let vc = self.storyboard?.instantiateViewController(withIdentifier: "vcCTT") as! ClassTimeTableViewController
            vc.modalPresentationStyle = .fullScreen
            vc.popoverVC = self
            self.present(vc, animated: true, completion: nil)
        }
        if segue.identifier == "segueExam" {
            let vc = self.storyboard?.instantiateViewController(withIdentifier: "vcExam") as! ExamViewController
            vc.modalPresentationStyle = .fullScreen
            vc.popoverVC = self
            self.present(vc, animated: true, completion: nil)
        }
        if segue.identifier == "segueHolidayList" {
            let vc = self.storyboard?.instantiateViewController(withIdentifier: "vcHolidayList") as! HolidayListViewController
            vc.modalPresentationStyle = .fullScreen
            vc.popoverVC = self
            self.present(vc, animated: true, completion: nil)
        }
        if segue.identifier == "segueEvents" {
            let vc = self.storyboard?.instantiateViewController(withIdentifier: "vcEvents") as! EventsViewController
            vc.modalPresentationStyle = .fullScreen
            vc.popoverVC = self
            self.present(vc, animated: true, completion: nil)
        }
        if segue.identifier == "segueSettings" {
            let vc = self.storyboard?.instantiateViewController(withIdentifier: "vcSettings") as! SettingsViewController
            vc.modalPresentationStyle = .fullScreen
            vc.popoverVC = self
            self.present(vc, animated: true, completion: nil)
        }
    }
}
