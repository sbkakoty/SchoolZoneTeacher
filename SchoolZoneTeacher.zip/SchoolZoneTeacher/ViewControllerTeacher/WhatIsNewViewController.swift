//
//  WhatIsNewViewController.swift
//  SchoolZoneTeacher
//
//  Created by Apple on 01/12/19.
//  Copyright © 2019 ClearWin Technologies. All rights reserved.
//

import UIKit
import MaterialComponents
import SCLAlertView
import WebKit

class WhatIsNewViewController: UIViewController, WKNavigationDelegate {
    
    @IBOutlet var containerView: UIView!
    @IBOutlet var labelVersion: UILabel!
    @IBOutlet var txtVersion: UILabel!
    @IBOutlet var labelDesc: UILabel!
    @IBOutlet var wkWeViewDesc: WKWebView!
    
    let defaultLocalizer = AMPLocalizeUtils.defaultLocalizer
    var activityIndicator: UIActivityIndicatorView!
    
    let appearance = SCLAlertView.SCLAppearance(
        kTitleFont: UIFont(name: "HelveticaNeue", size: 20)!,
        kTextFont: UIFont(name: "HelveticaNeue", size: 14)!,
        kButtonFont: UIFont(name: "HelveticaNeue-Bold", size: 14)!
    )
    
    var result:Result?
    var versionInf:[VersionInf]?
    var response:Response?
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        if(getLanguage().count > 0)
        {
            defaultLocalizer.setSelectedLanguage(lang: getLanguage())
        }
        else
        {
            defaultLocalizer.setSelectedLanguage(lang: "en")
        }
        
        labelVersion.text  = defaultLocalizer.stringForKey(key: "labelVersion")
        labelDesc.text = defaultLocalizer.stringForKey(key: "labelVersionDesc")
        
        self.setNavigationBar()
        self.getVersionInf()
        
        //self.view.addSubview(scrollView)
        self.activityIndicator = UIActivityIndicatorView(style: .gray)
        self.activityIndicator.center = self.wkWeViewDesc.center
        self.activityIndicator.startAnimating()
        self.view.addSubview(self.activityIndicator)
        self.activityIndicator.hidesWhenStopped = true
    }
    
    func setNavigationBar() {
        let navigationFont = UIFont(name: "Helvetica", size: getTitleFontSize())
        
        let button = UIButton.init(type: .custom)
        button.setTitle(self.defaultLocalizer.stringForKey(key: "navBarButtonBack"), for: UIControl.State.normal)
        var image = UIImage.init(named: "back")
        let templateImage = image?.withRenderingMode(UIImage.RenderingMode.alwaysTemplate)
        image = templateImage
        button.setImage(image, for: UIControl.State.normal)
        button.addTarget(self, action:#selector(back), for:.touchUpInside)
        button.addTarget(self, action:#selector(back), for:.touchUpOutside)
        button.frame = CGRect.init(x: 0, y: 0, width: 20, height: 20) //CGRectMake(0, 0, 30, 30)
        let doneItem = UIBarButtonItem.init(customView: button)
        self.navigationItem.leftBarButtonItem = doneItem
        
        let width = self.view.frame.width - 60
        let height = CGFloat(44)
        
        let titleLabel = UILabel(frame: CGRect.init(x: 0, y: 0, width: width, height: height))
        titleLabel.text = self.defaultLocalizer.stringForKey(key: "menuTitleWhatIsNew")
        titleLabel.textAlignment = .center
        titleLabel.font = navigationFont
        titleLabel.textColor = .white
        titleLabel.sizeToFit()
        self.navigationItem.titleView = titleLabel
    }
    
    @objc func back() { // remove @objc for Swift 3
        
        self.navigationController?.popViewController(animated: false)
    }
    
    func position(for bar: UIBarPositioning) -> UIBarPosition {
        return .topAttached
    }
    
    func getVersionInf()
    {
        guard let info = Bundle.main.infoDictionary,
            //let currentVersion = info["CFBundleShortVersionString"] as? String,
            let identifier = info["CFBundleIdentifier"] as? String,
            let url = URL(string: "http://itunes.apple.com/lookup?bundleId=\(identifier)") else {
                return
        }
        
        do {
           let data = try Data(contentsOf: url)
           
            guard let json = try JSONSerialization.jsonObject(with: data, options: [.allowFragments]) as? [String: Any] else {
                return
            }
            if let result = (json["results"] as? [Any])?.first as? [String: Any], let version = result["version"] as? String, let releaseNotes = result["releaseNotes"] as? String {
                dump(result)
                self.txtVersion.text = version
                var headerString = "<header><meta name='viewport' content='width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0'></header>"
                headerString.append(releaseNotes)
                self.wkWeViewDesc.loadHTMLString(self.updateDataWithFont(data:headerString), baseURL: nil)
                self.wkWeViewDesc.navigationDelegate = self
            }
        } catch {
            //handle error
            print(error)
        }
    }
    
    func webView(_ webView: WKWebView, didFinish navigation:
        WKNavigation!) {
        self.activityIndicator.stopAnimating()
    }
    
    func webView(_ webView: WKWebView, didStartProvisionalNavigation
        navigation: WKNavigation!) {
        self.activityIndicator.startAnimating()
    }
    
    func webView(_ webView: WKWebView, didFail navigation:
        WKNavigation!, withError error: Error) {
        self.activityIndicator.stopAnimating()
    }
    
    func updateDataWithFont(data:String)->String{
        return String(format: "<html><body><span style=\"font-family:%@;font-size:%@;text-align:justify\">%@</span></body></html>","Helvetica","12px",data)
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
