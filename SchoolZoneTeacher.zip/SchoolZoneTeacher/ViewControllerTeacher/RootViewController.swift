//
//  RootViewController.swift
//  SchoolZoneTeacher
//
//  Created by Apple on 19/01/19.
//  Copyright © 2019 ClearWin Technologies. All rights reserved.
//

import UIKit
import SCLAlertView
import AVFoundation
import NMAnimatedTabBarItem
import Alamofire

class RootViewController: UINavigationController, UICollectionViewDelegate, UICollectionViewDataSource {
    
    let defaultLocalizer = AMPLocalizeUtils.defaultLocalizer
    var logoView = UIView()
    
    var statusBarShouldBeHidden = false
    var animatedTabBar = NMAnimateTabBarItem()
    ///  Options for animating. Default transitionFlipFromRight
    open var transitionOptions: UIView.AnimationOptions = UIView.AnimationOptions.transitionFlipFromRight
    
    /// The duration of the animation. Default 0.5
    open var duration: CGFloat = 2.5
    
    /// Animation direction (left, right).
    open var direction: NMRotationDirection?
    
    /// Frame Animation array list
    @nonobjc open var animationImages: Array<CGImage> = Array()
    
    // MARK: NMAnimationKey constants
    
    struct NMAnimationKeys {
        static let Scale = "transform.scale"
        static let Rotation = "transform.rotation"
        static let KeyFrame = "contents"
    }
    
    var collectionView: UICollectionView!
    var customTabUIView: UIView!
    //@IBOutlet weak var tabUIScrollView: UIScrollView!
    var homeButtonView: UIView!
    
    var buttonHome: UIButton!
    var labelHome: UILabel!
    
    let cellIdentifier = "tabItemCell"
    var moduleNameArray = Array<String>()
    @objc public var selectedCell  : IndexPath = []
    var selectedIndex:Int = 0
    
    let appearance = SCLAlertView.SCLAppearance(
        kTitleFont: UIFont(name: "HelveticaNeue", size: 20)!,
        kTextFont: UIFont(name: "HelveticaNeue", size: 14)!,
        kButtonFont: UIFont(name: "HelveticaNeue-Bold", size: 14)!
    )
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        self.setUpTabBar()
        
        if(AppLoadingStatus.appLoadingStatus.status == "Redirect"){
            self.statusBarShouldBeHidden = false
            self.setNeedsStatusBarAppearanceUpdate()
        }
        
        if(AppLoadingStatus.appLoadingStatus.status == "Fresh"){
            var schoolNameContainerView = UIView()
            logoView = UIView(frame: UIScreen.main.bounds)
            let logoBG = UIImageView(frame: UIScreen.main.bounds)
            logoBG.image = UIImage(named: "launchscreen")
            
            logoView.addSubview(logoBG)
            
            let copyrightContainerView = UIView(frame: CGRect(x: 10, y: self.calculateTopDistance(), width:self.view.frame.width - 50, height:60))
            
            let copyrightText = UILabel(frame: CGRect(x: 0, y: 0, width: copyrightContainerView.frame.width - 30, height:60))
            copyrightText.text = "Powered by"
            copyrightText.textAlignment = .right
            copyrightText.font = UIFont(name: "Helvetica", size: 16.0)
            copyrightText.textColor = UIColor.white //colorWithHexString(hex: "#003366")
            
            let copyrightLogoView = UIImageView(frame: CGRect(x: copyrightText.frame.width + 5, y: 0, width: 50, height:60))
            copyrightLogoView.contentMode = UIView.ContentMode.scaleAspectFit
            let copyrightLogoImage = UIImage(named: "logosmall")
            copyrightLogoView.image = copyrightLogoImage
            copyrightContainerView.addSubview(copyrightText)
            copyrightContainerView.addSubview(copyrightLogoView)
            
            let logoImageView = UIImageView(frame: CGRect(x: (self.view.frame.width / 2) - 125, y: (self.view.frame.height / 2) - 75, width:250, height:150))
            
            ///let id = getSchoolId()
            let logoPath = getSchoolLogo()
            
            if(logoPath.count > 0){
                let dataFromUserDefaults = UserDefaults.standard.object(forKey: logoPath)
                
                if dataFromUserDefaults != nil{
                    print("Loading From Cache: \(logoPath)")
                    let sourceImage = UIImage(data: dataFromUserDefaults as! Data)
                    let shadowImage = sourceImage!.addShadow()
                    logoImageView.contentMode = UIView.ContentMode.scaleAspectFit
                    
                    UIView.transition(with: logoImageView,
                                      duration: 1,
                                      options: UIView.AnimationOptions.transitionCurlUp,
                                      animations: {
                                        logoImageView.image = shadowImage
                    },
                                      completion: nil)
                    self.logoView.addSubview(logoImageView)
                }
                else
                {
                    print("Loading From URL:  \(logoPath)")
                    Alamofire.request(logoPath, method: .get).response { (responseData) in
                        if let data = responseData.data {
                            UserDefaults.standard.set(data, forKey: logoPath)
                            UserDefaults.standard.synchronize()
                            DispatchQueue.main.async {
                                let sourceImage = UIImage(data: data)
                                let shadowImage = sourceImage!.addShadow()
                                logoImageView.contentMode = UIView.ContentMode.scaleAspectFit
                                
                                UIView.transition(with: logoImageView,
                                                  duration: 1,
                                                  options: UIView.AnimationOptions.transitionCurlUp,
                                                  animations: {
                                                    logoImageView.image = shadowImage
                                },
                                                  completion: nil)
                                self.logoView.addSubview(logoImageView)
                            }
                        }
                    }
                }
            }
            else
            {
                let sourceImage = UIImage(named: "sz_logo")
                let shadowImage = sourceImage!.addShadow()
                logoImageView.contentMode = UIView.ContentMode.scaleAspectFit
                
                UIView.transition(with: logoImageView,
                                  duration: 1,
                                  options: UIView.AnimationOptions.transitionCurlUp,
                                  animations: {
                                    logoImageView.image = shadowImage
                },
                                  completion: nil)
                logoView.addSubview(logoImageView)
            }
            
            self.view.addSubview(logoView)
            
            schoolNameContainerView = UIView(frame: CGRect(x: 10, y: (self.view.frame.height / 2) + 45, width:self.view.frame.width - 20, height:100))
            let schoolName = UILabel(frame: CGRect(x: 0, y: 0, width: schoolNameContainerView.frame.width, height:100))
            
            let titleParameters = [NSAttributedString.Key.foregroundColor : UIColor.white,
                                   NSAttributedString.Key.font : UIFont(name: "Helvetica", size: 22.0)!, NSAttributedString.Key.shadow: setNavBarTitleShadow()] as [NSAttributedString.Key : Any]
            
            let title:NSMutableAttributedString = NSMutableAttributedString(string: getSchoolName().uppercased(), attributes: titleParameters)
            
            schoolName.attributedText = title
            schoolName.numberOfLines = 3
            schoolName.textAlignment = .center
            schoolName.font = UIFont(name: "Helvetica", size: 22.0)
            schoolName.adjustsFontSizeToFitWidth = true
            schoolName.textColor = UIColor.white
            schoolNameContainerView.addSubview(schoolName)
            
            self.view.addSubview(schoolNameContainerView)
            self.view.addSubview(copyrightContainerView)
            
            UIView.animate(withDuration: 0.1,
                           delay: 2,
                           options: UIView.AnimationOptions.curveEaseIn,
                           animations: {
                            self.logoView.alpha = 0.0
                            schoolNameContainerView.alpha = 0.0
                            copyrightContainerView.alpha = 0.0
            },
                           completion: { finished in
                            
                            self.statusBarShouldBeHidden = false
                            self.setNeedsStatusBarAppearanceUpdate()
                            
                            self.logoView.removeFromSuperview()
                            schoolNameContainerView.removeFromSuperview()
                            copyrightContainerView.removeFromSuperview()
                            
                            if(AppLoginStatus.appLoginStatus.status == 1)
                            {
                                if(getTeacherId().count > 0){
                                    let fname = getFirstName() + " "
                                    let mname = getMiddleName().count > 0 ? getMiddleName() + " " : ""
                                    let lname = getLastName()
                                    let fullname = fname + mname + lname
                                    // the alert view
                                    let alert = UIAlertController(title: "OurSchoolZone", message: self.defaultLocalizer.stringForKey(key: "allertMessageWelcome") + fullname, preferredStyle: .alert)
                                    self.present(alert, animated: true, completion: nil)
                                    
                                    // change to desired number of seconds (in this case 5 seconds)
                                    let when = DispatchTime.now() + 3
                                    DispatchQueue.main.asyncAfter(deadline: when){
                                        // your code with delay
                                        alert.dismiss(animated: true, completion: nil)
                                    }
                                }
                            }
                            
                            /*let alertView = SCLAlertView(appearance: self.appearance)
                            
                            let when = (AppLoginStatus.appLoginStatus.status == 1) ? DispatchTime.now() + 3 : DispatchTime.now()
                            
                            DispatchQueue.main.asyncAfter(deadline: when){
                                // your code with delay
                                alertView.showInfo("OurSchoolZone", subTitle: getAcademicYear(), closeButtonTitle: self.defaultLocalizer.stringForKey(key: "buttonAlertOK"))
                            }*/
                                
            })
        }
    }
    
    func setUpTabBar()
    {
        let layout: UICollectionViewFlowLayout = UICollectionViewFlowLayout()
        layout.sectionInset = UIEdgeInsets(top: 0, left: 0, bottom: 0, right: 0)
        layout.minimumInteritemSpacing = 0
        layout.minimumLineSpacing = 0
        
        let modelName = UIDevice.modelName
        //print("modelName: \(modelName)")
        
        switch modelName {
            case "iPhone X", "iPhone XR", "iPhone XS", "iPhone XS Max", "Simulator iPhone X", "Simulator iPhone XR", "Simulator iPhone XS", "Simulator iPhone XS Max":
                self.customTabUIView = UIView(frame: CGRect(x: 0, y: self.view.frame.height - 83, width: self.view.frame.width, height: 83))
                
                self.homeButtonView = UIView(frame: CGRect(x: 0, y: 0, width: 80, height: 83))
                self.labelHome = UILabel(frame: CGRect(x: 0, y: 37, width: 80, height: 15))
                layout.itemSize = CGSize(width: 80, height: 83)
                layout.scrollDirection = .horizontal
                
                self.collectionView = UICollectionView(frame: CGRect(x: 80, y: 0, width: self.view.frame.width - 83, height: 83), collectionViewLayout: layout)
                break
            case "iPhone12,1", "iPhone12,3", "iPhone12,5", "Simulator iPhone12,1", "Simulator iPhone12,3", "Simulator iPhone12,5":
                self.customTabUIView = UIView(frame: CGRect(x: 0, y: self.view.frame.height - 83, width: self.view.frame.width, height: 83))
                
                self.homeButtonView = UIView(frame: CGRect(x: 0, y: 0, width: 80, height: 83))
                self.labelHome = UILabel(frame: CGRect(x: 0, y: 37, width: 80, height: 15))
                layout.itemSize = CGSize(width: 80, height: 83)
                layout.scrollDirection = .horizontal
                
                self.collectionView = UICollectionView(frame: CGRect(x: 80, y: 0, width: self.view.frame.width - 83, height: 83), collectionViewLayout: layout)
                break
            default:
                self.customTabUIView = UIView(frame: CGRect(x: 0, y: self.view.frame.height - 55, width: self.view.frame.width, height: 55))
                
                self.homeButtonView = UIView(frame: CGRect(x: 0, y: 0, width: 80, height: 55))
                self.labelHome = UILabel(frame: CGRect(x: 0, y: 37, width: 80, height: 15))
                layout.itemSize = CGSize(width: 80, height: 55)
                layout.scrollDirection = .horizontal
                
                self.collectionView = UICollectionView(frame: CGRect(x: 80, y: 0, width: self.view.frame.width - 55, height: 55), collectionViewLayout: layout)
                break
        }
        
        self.customTabUIView.backgroundColor = UIColor.white
        self.homeButtonView.backgroundColor = UIColor.white
        self.customTabUIView.layer.borderColor = colorWithHexString (hex: "#dddddd").cgColor
        self.customTabUIView.layer.borderWidth = 1
        
        self.collectionView.dataSource = self
        self.collectionView.delegate = self
        self.collectionView.register(UINib(nibName: "TabItemCollectionViewCell", bundle: nil), forCellWithReuseIdentifier: cellIdentifier)
        self.collectionView.backgroundColor = UIColor.white
        
        self.buttonHome = UIButton(frame: CGRect(x: 25, y: 9, width: 30, height: 30))
        self.buttonHome.setImage(UIImage(named: "home"), for: .normal)
        self.buttonHome.tintColor = colorWithHexString (hex: "#1fbed6")
        self.labelHome.textColor = colorWithHexString (hex: "#1fbed6")
        self.buttonHome.addTarget(self, action: #selector(didTapTabBarButton), for:.touchUpInside)
        self.labelHome.text = self.defaultLocalizer.stringForKey(key: "navBarTitleHome")
        self.labelHome.font = UIFont(name:"Helvetica-bold", size: 10.0)
        self.labelHome.textAlignment = .center
        //self.labelHome.textColor = colorWithHexString (hex: "#00CCFF")
        
        let tapgesture = UITapGestureRecognizer(target: self , action: #selector(didTapTabHomeButtonView))
        self.homeButtonView.addGestureRecognizer(tapgesture)
        self.homeButtonView.addSubview(self.buttonHome)
        self.homeButtonView.addSubview(self.labelHome)
        self.customTabUIView.addSubview(self.homeButtonView)
        self.customTabUIView.addSubview(self.collectionView)
        self.view.addSubview(self.customTabUIView)
        self.getTabItems()
    }
    
    open override var childForStatusBarHidden: UIViewController? {
        return nil
    }
    
    @objc func didTapTabHomeButtonView(_ sender: UITapGestureRecognizer)
    {
        selectedCell = []
        
        let bounce = CAKeyframeAnimation(keyPath: NMAnimationKeys.Scale)
        bounce.values = [1.0, 1.4, 0.9, 1.15, 0.95, 1.02, 1.0]
        bounce.duration = TimeInterval(duration)
        bounce.repeatCount = 1;
        bounce.calculationMode = CAAnimationCalculationMode.cubic
        self.buttonHome.tag = 0
        self.buttonHome.imageView?.layer.add(bounce, forKey: nil)
        
        self.collectionView.reloadData()
        self.homeButtonView.backgroundColor = UIColor(white: 1, alpha: 0.3)
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "vcLandingPage") as! ViewController
        vc.modalPresentationStyle = .fullScreen
        self.pushViewController(vc, animated: false)
    }
    
    func calculateTopDistance () -> CGFloat{
        if(self.navigationController != nil && !self.navigationController!.navigationBar.isTranslucent){
            return 0
        }else{
            
            let barHeight = self.navigationController?.navigationBar.frame.height ?? 0
            var statusBarHeight:CGFloat = 0
            
            if #available(iOS 13.0, *) {
                
                let sharedApplication = UIApplication.shared
                statusBarHeight = (sharedApplication.delegate?.window??.windowScene?.statusBarManager?.statusBarFrame)!.height

            } else {
                
                statusBarHeight = UIApplication.shared.isStatusBarHidden ? CGFloat(0) : UIApplication.shared.statusBarFrame.height
                
                if let statusBar = UIApplication.shared.value(forKey: "statusBar") as? UIView {
                    statusBar.backgroundColor = colorWithHexString(hex: "#00CCFF")
                }
            }
            
            return barHeight + statusBarHeight
        }
    }
    
    open override var prefersStatusBarHidden: Bool{
        return statusBarShouldBeHidden
    }
    
    func setCellBackground(indexPathRightBound: Int)
    {
        self.homeButtonView.backgroundColor = UIColor.white
        let indexPath  : IndexPath = [0, indexPathRightBound]
        selectedCell = indexPath
        self.collectionView.reloadData()
    }
    
    @objc func didTapTabBarButton(sender: UIButton)
    {
        if(sender.tag == 0)
        {
            selectedCell = []
            let bounce = CAKeyframeAnimation(keyPath: NMAnimationKeys.Scale)
            bounce.values = [1.0, 1.4, 0.9, 1.15, 0.95, 1.02, 1.0]
            bounce.duration = TimeInterval(duration)
            bounce.repeatCount = 1;
            bounce.calculationMode = CAAnimationCalculationMode.cubic
            self.buttonHome.imageView?.layer.add(bounce, forKey: nil)
            
            self.collectionView.reloadData()
            self.homeButtonView.backgroundColor = UIColor(white: 1, alpha: 0.3)
            let vc = self.storyboard?.instantiateViewController(withIdentifier: "vcLandingPage") as! ViewController
            vc.modalPresentationStyle = .fullScreen
            self.pushViewController(vc, animated: false)
        }
        else
        {
            switch (self.moduleNameArray[(sender.tag - 1)]) {
                case "Events":
                    setCellBackground(indexPathRightBound: (sender.tag - 1))
                    let vc = self.storyboard?.instantiateViewController(withIdentifier: "vcEvents") as! EventsViewController
                    vc.modalPresentationStyle = .fullScreen
                    self.pushViewController(vc, animated: false)
                    break
                case "Notice":
                    setCellBackground(indexPathRightBound: (sender.tag - 1))
                    let vc = self.storyboard?.instantiateViewController(withIdentifier: "vcNews") as! NewsViewController
                    vc.modalPresentationStyle = .fullScreen
                    self.pushViewController(vc, animated: false)
                    break
                case "Classroom":
                    setCellBackground(indexPathRightBound: (sender.tag - 1))
                    let vc = self.storyboard?.instantiateViewController(withIdentifier: "vcClassroom") as! ClassroomViewController
                    vc.modalPresentationStyle = .fullScreen
                    self.pushViewController(vc, animated: false)
                    break
                case "Announcement":
                    setCellBackground(indexPathRightBound: (sender.tag - 1))
                    let vc = self.storyboard?.instantiateViewController(withIdentifier: "vcAnnouncement") as! AnnouncementViewController
                    vc.modalPresentationStyle = .fullScreen
                    self.pushViewController(vc, animated: false)
                    break
                case "Schooldiary":
                    setCellBackground(indexPathRightBound: (sender.tag - 1))
                    let vc = self.storyboard?.instantiateViewController(withIdentifier: "dcSchoolDiary") as! SchoolDiaryViewController
                    vc.modalPresentationStyle = .fullScreen
                    self.pushViewController(vc, animated: false)
                    break
                case "AbsentReport":
                    setCellBackground(indexPathRightBound: (sender.tag - 1))
                    let vc = self.storyboard?.instantiateViewController(withIdentifier: "vcAR") as! AbsentReportViewController
                    vc.modalPresentationStyle = .fullScreen
                    self.pushViewController(vc, animated: false)
                    break
                case "Examination":
                    setCellBackground(indexPathRightBound: (sender.tag - 1))
                    let vc = self.storyboard?.instantiateViewController(withIdentifier: "vcExam") as! ExamViewController
                    vc.modalPresentationStyle = .fullScreen
                    self.pushViewController(vc, animated: false)
                    break
                case "Edubank":
                    setCellBackground(indexPathRightBound: (sender.tag - 1))
                    let vc = self.storyboard?.instantiateViewController(withIdentifier: "vcEduBank") as! EduBankViewController
                    vc.modalPresentationStyle = .fullScreen
                    self.pushViewController(vc, animated: false)
                    break
                case "Eduforum":
                    setCellBackground(indexPathRightBound: (sender.tag - 1))
                    let vc = self.storyboard?.instantiateViewController(withIdentifier: "vcTopics") as! TopicsViewController
                    vc.modalPresentationStyle = .fullScreen
                    self.pushViewController(vc, animated: false)
                    break
                case "Query":
                    setCellBackground(indexPathRightBound: (sender.tag - 1))
                    let vc = self.storyboard?.instantiateViewController(withIdentifier: "vcQuery") as! QueryViewController
                    vc.modalPresentationStyle = .fullScreen
                    self.pushViewController(vc, animated: false)
                    break
                case "Help":
                    setCellBackground(indexPathRightBound: (sender.tag - 1))
                    let vc = self.storyboard?.instantiateViewController(withIdentifier: "vcHelp") as! HelpViewController
                    vc.modalPresentationStyle = .fullScreen
                    self.pushViewController(vc, animated: false)
                    break
                case "Settings":
                    setCellBackground(indexPathRightBound: (sender.tag - 1))
                    let vc = self.storyboard?.instantiateViewController(withIdentifier: "vcSettings") as! SettingsViewController
                    vc.modalPresentationStyle = .fullScreen
                    self.pushViewController(vc, animated: false)
                    break
                default:
                    break
            }
        }
        //animatedTabBar.animateTabBarItem(self.tabBar, sender.tag, 2 , NMAnimationtype.Bounce)
    }
    
    func getTabItems(){
        self.moduleNameArray.append("Events")
        self.moduleNameArray.append("Notice")
        self.moduleNameArray.append("Classroom")
        self.moduleNameArray.append("Schooldiary")
        self.moduleNameArray.append("Announcement")
        self.moduleNameArray.append("Examination")
        self.moduleNameArray.append("AbsentReport")
        self.moduleNameArray.append("Edubank")
        self.moduleNameArray.append("Eduforum")
        //self.moduleNameArray.append("Query")
        self.moduleNameArray.append("Help")
        self.moduleNameArray.append("Settings")
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return self.moduleNameArray.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: cellIdentifier, for: indexPath) as! TabItemCollectionViewCell
        cell.backgroundColor = UIColor.white
        //cell.tabLabel.textColor = colorWithHexString (hex: "#00CCFF")
        
        switch (self.moduleNameArray[indexPath.item]) {
            case "Events":
                cell.tabButton.setImage(UIImage(named: "calendar"), for: UIControl.State.normal)
                cell.tabButton.tag = indexPath.item + 1
                cell.tabButton.addTarget(self, action: #selector(didTapTabBarButton), for:.touchUpInside)
                cell.tabLabel.text = self.defaultLocalizer.stringForKey(key: "menuTitleEvents")
                cell.tabButton.tintColor = colorWithHexString(hex: "#EC3136")
                cell.tabLabel.textColor = colorWithHexString(hex: "#EC3136")
                break
            case "Notice":
                cell.tabButton.setImage(UIImage(named: "notice"), for: UIControl.State.normal)
                cell.tabButton.tag = indexPath.item + 1
                cell.tabButton.addTarget(self, action: #selector(didTapTabBarButton), for:.touchUpInside)
                cell.tabLabel.text = self.defaultLocalizer.stringForKey(key: "navBarTitleNews")
                cell.tabButton.tintColor = colorWithHexString(hex: "#344A9B")
                cell.tabLabel.textColor = colorWithHexString(hex: "#344A9B")
                break
            case "Classroom":
                cell.tabButton.setImage(UIImage(named: "classroom-tab"), for: UIControl.State.normal)
                cell.tabButton.tag = indexPath.item + 1
                cell.tabButton.addTarget(self, action: #selector(didTapTabBarButton), for:.touchUpInside)
                cell.tabLabel.text = self.defaultLocalizer.stringForKey(key: "navBarTitleClassroom")
                cell.tabButton.tintColor = colorWithHexString(hex: "#f16136")
                cell.tabLabel.textColor = colorWithHexString(hex: "#f16136")
                break
            case "Schooldiary":
                cell.tabButton.setImage(UIImage(named: "schooldiary"), for: UIControl.State.normal)
                cell.tabButton.tag = indexPath.item + 1
                cell.tabButton.addTarget(self, action: #selector(didTapTabBarButton), for:.touchUpInside)
                cell.tabLabel.text = self.defaultLocalizer.stringForKey(key: "navBarTitleSchoolDiary")
                cell.tabButton.tintColor = colorWithHexString(hex: "#51A8B1")
                cell.tabLabel.textColor = colorWithHexString(hex: "#51A8B1")
                break
            case "Announcement":
                cell.tabButton.setImage(UIImage(named: "bell"), for: UIControl.State.normal)
                cell.tabButton.tag = indexPath.item + 1
                cell.tabButton.addTarget(self, action: #selector(didTapTabBarButton), for:.touchUpInside)
                cell.tabLabel.text = self.defaultLocalizer.stringForKey(key: "navBarTitleAnnouncements")
                cell.tabButton.tintColor = colorWithHexString(hex: "#EB258E")
                cell.tabLabel.textColor = colorWithHexString(hex: "#EB258E")
                break
            case "Examination":
                cell.tabButton.setImage(UIImage(named: "exam"), for: UIControl.State.normal)
                cell.tabButton.tag = indexPath.item + 1
                cell.tabButton.addTarget(self, action: #selector(didTapTabBarButton), for:.touchUpInside)
                cell.tabLabel.text = self.defaultLocalizer.stringForKey(key: "navBarTitleExam")
                cell.tabButton.tintColor = colorWithHexString(hex: "#00AD57")
                cell.tabLabel.textColor = colorWithHexString(hex: "#00AD57")
                break
            case "AbsentReport":
                cell.tabButton.setImage(UIImage(named: "absentreport"), for: UIControl.State.normal)
                cell.tabButton.tag = indexPath.item + 1
                cell.tabButton.addTarget(self, action: #selector(didTapTabBarButton), for:.touchUpInside)
                cell.tabLabel.text = self.defaultLocalizer.stringForKey(key: "navBarTitleAbsentReport")
                cell.tabButton.tintColor = colorWithHexString(hex: "#7C3A93")
                cell.tabLabel.textColor = colorWithHexString(hex: "#7C3A93")
                break
            case "Edubank":
                cell.tabButton.setImage(UIImage(named: "edubank"), for: UIControl.State.normal)
                cell.tabButton.tag = indexPath.item + 1
                cell.tabButton.addTarget(self, action: #selector(didTapTabBarButton), for:.touchUpInside)
                cell.tabLabel.text = self.defaultLocalizer.stringForKey(key: "menuTitleEduBank")
                cell.tabButton.tintColor = colorWithHexString(hex: "#26BEBE")
                cell.tabLabel.textColor = colorWithHexString(hex: "#26BEBE")
                break
            case "Eduforum":
                cell.tabButton.setImage(UIImage(named: "eduforum"), for: UIControl.State.normal)
                cell.tabButton.tag = indexPath.item + 1
                cell.tabButton.addTarget(self, action: #selector(didTapTabBarButton), for:.touchUpInside)
                cell.tabLabel.text = self.defaultLocalizer.stringForKey(key: "menuTitleEduForum")
                cell.tabButton.tintColor = colorWithHexString(hex: "#0078bf")
                cell.tabLabel.textColor = colorWithHexString(hex: "#0078bf")
                break
            case "Query":
                cell.tabButton.setImage(UIImage(named: "query-tab"), for: UIControl.State.normal)
                cell.tabButton.tag = indexPath.item + 1
                cell.tabButton.addTarget(self, action: #selector(didTapTabBarButton), for:.touchUpInside)
                cell.tabLabel.text = self.defaultLocalizer.stringForKey(key: "menuTitleQuery")
                cell.tabButton.tintColor = colorWithHexString(hex: "#0078bf")
                cell.tabLabel.textColor = colorWithHexString(hex: "#0078bf")
                break
            case "Help":
                cell.tabButton.setImage(UIImage(named: "help"), for: UIControl.State.normal)
                cell.tabButton.tag = indexPath.item + 1
                cell.tabButton.addTarget(self, action: #selector(didTapTabBarButton), for:.touchUpInside)
                cell.tabLabel.text = self.defaultLocalizer.stringForKey(key: "menuTitleHelp")
                cell.tabButton.tintColor = colorWithHexString(hex: "#7d3b94")
                cell.tabLabel.textColor = colorWithHexString(hex: "#7d3b94")
                break
            case "Settings":
                cell.tabButton.setImage(UIImage(named: "settings"), for: UIControl.State.normal)
                cell.tabButton.tag = indexPath.item + 1
                cell.tabButton.addTarget(self, action: #selector(didTapTabBarButton), for:.touchUpInside)
                cell.tabLabel.text = self.defaultLocalizer.stringForKey(key: "menuTitleSettings")
                cell.tabButton.tintColor = colorWithHexString(hex: "#267cb5")
                cell.tabLabel.textColor = colorWithHexString(hex: "#267cb5")
                break
            default:
                break
        }
        
        if selectedCell == indexPath {
            cell.contentView.backgroundColor = UIColor(white: 1, alpha: 0.3)
            
            let bounce = CAKeyframeAnimation(keyPath: NMAnimationKeys.Scale)
            bounce.values = [1.0, 1.4, 0.9, 1.15, 0.95, 1.02, 1.0]
            bounce.duration = TimeInterval(duration)
            bounce.repeatCount = 1;
            bounce.calculationMode = CAAnimationCalculationMode.cubic
            cell.tabButton.imageView?.layer.add(bounce, forKey: nil)
        }
        else {
            cell.contentView.backgroundColor = .white
        }
        
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        selectedCell = indexPath
        self.collectionView.reloadData()
        
        self.onCellSelect(itemIndex: indexPath.item)
    }
    
    func onCellSelect(itemIndex: Int)
    {
        self.homeButtonView.backgroundColor = .white
        
        switch (self.moduleNameArray[itemIndex]) {
            case "Events":
                setCellBackground(indexPathRightBound: itemIndex)
                let vc = self.storyboard?.instantiateViewController(withIdentifier: "vcEvents") as! EventsViewController
                vc.modalPresentationStyle = .fullScreen
                self.pushViewController(vc, animated: false)
                break
            case "Notice":
                setCellBackground(indexPathRightBound: itemIndex)
                let vc = self.storyboard?.instantiateViewController(withIdentifier: "vcNews") as! NewsViewController
                vc.modalPresentationStyle = .fullScreen
                self.pushViewController(vc, animated: false)
                break
            case "Classroom":
                setCellBackground(indexPathRightBound: itemIndex)
                let vc = self.storyboard?.instantiateViewController(withIdentifier: "vcClassroom") as! ClassroomViewController
                vc.modalPresentationStyle = .fullScreen
                self.pushViewController(vc, animated: false)
                break
            case "Schooldiary":
                setCellBackground(indexPathRightBound: itemIndex)
                let vc = self.storyboard?.instantiateViewController(withIdentifier: "dcSchoolDiary") as! SchoolDiaryViewController
                vc.modalPresentationStyle = .fullScreen
                self.pushViewController(vc, animated: false)
                break
            case "Announcement":
                setCellBackground(indexPathRightBound: itemIndex)
                let vc = self.storyboard?.instantiateViewController(withIdentifier: "vcAnnouncement") as! AnnouncementViewController
                vc.modalPresentationStyle = .fullScreen
                self.pushViewController(vc, animated: false)
                break
            case "Examination":
                setCellBackground(indexPathRightBound: itemIndex)
                let vc = self.storyboard?.instantiateViewController(withIdentifier: "vcExam") as! ExamViewController
                vc.modalPresentationStyle = .fullScreen
                self.pushViewController(vc, animated: false)
                break
            case "AbsentReport":
                setCellBackground(indexPathRightBound: itemIndex)
                let vc = self.storyboard?.instantiateViewController(withIdentifier: "vcAR") as! AbsentReportViewController
                vc.modalPresentationStyle = .fullScreen
                self.pushViewController(vc, animated: false)
                break
            case "Edubank":
                setCellBackground(indexPathRightBound: itemIndex)
                let vc = self.storyboard?.instantiateViewController(withIdentifier: "vcEduBank") as! EduBankViewController
                vc.modalPresentationStyle = .fullScreen
                self.pushViewController(vc, animated: false)
                break
            case "Eduforum":
                setCellBackground(indexPathRightBound: itemIndex)
                let vc = self.storyboard?.instantiateViewController(withIdentifier: "vcTopics") as! TopicsViewController
                vc.modalPresentationStyle = .fullScreen
                self.pushViewController(vc, animated: false)
                break
            case "Query":
                setCellBackground(indexPathRightBound: itemIndex)
                let vc = self.storyboard?.instantiateViewController(withIdentifier: "vcQuery") as! QueryViewController
                vc.modalPresentationStyle = .fullScreen
                self.pushViewController(vc, animated: false)
                break
            case "Help":
                setCellBackground(indexPathRightBound: itemIndex)
                let vc = self.storyboard?.instantiateViewController(withIdentifier: "vcHelp") as! HelpViewController
                vc.modalPresentationStyle = .fullScreen
                self.pushViewController(vc, animated: false)
            case "Settings":
                setCellBackground(indexPathRightBound: itemIndex)
                let vc = self.storyboard?.instantiateViewController(withIdentifier: "vcSettings") as! SettingsViewController
                vc.modalPresentationStyle = .fullScreen
                self.pushViewController(vc, animated: false)
                break
            default:
                break
        }
    }
    
    func setGradientBackground(colorTop: UIColor, colorBottom: UIColor) {
        let gradientLayer = CAGradientLayer()
        gradientLayer.colors = [colorBottom.cgColor, colorTop.cgColor]
        gradientLayer.startPoint = CGPoint(x: 0.5, y: 1.0)
        gradientLayer.endPoint = CGPoint(x: 0.5, y: 0.0)
        gradientLayer.locations = [0, 1]
        gradientLayer.frame = UIScreen.main.bounds
        
        //logoView.layer.insertSublayer(gradientLayer, at: 0)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
