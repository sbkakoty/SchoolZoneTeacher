//
//  SigninViewController.swift
//  SchoolZoneTeacher
//
//  Created by Apple on 19/01/19.
//  Copyright © 2019 ClearWin Technologies. All rights reserved.
//

import UIKit
import SCLAlertView
import MaterialComponents
import FlagPhoneNumber

class SigninViewController: UIViewController, UITextFieldDelegate {

    var opQueue = OperationQueue()
    let defaultLocalizer = AMPLocalizeUtils.defaultLocalizer
    var phoneNumberTextField: FPNTextField!
    var buttonSubmit = UIButton()
    var response:Response?
    let activityIndicator = MDCActivityIndicator()
    let appearance = SCLAlertView.SCLAppearance(
        kTitleFont: UIFont(name: "HelveticaNeue", size: 20)!,
        kTextFont: UIFont(name: "HelveticaNeue", size: 14)!,
        kButtonFont: UIFont(name: "HelveticaNeue-Bold", size: 14)!,
        showCloseButton: false
    )
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        
        var mobileNumberLength = 11
        
        //setCountryCode(countryCode: "US")
        if(getCountryCode() == "IN")
        {
            mobileNumberLength = 11
        }
        else
        {
            mobileNumberLength = 12
        }
        
        let currentCharacterCount = phoneNumberTextField.text?.count ?? 0
        if range.length + range.location > currentCharacterCount {
            return false
        }
        
        //print("getCountryCode(): \(getCountryCode())")
        
        let newLength = currentCharacterCount + string.count - range.length
        return newLength <= mobileNumberLength
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        if(getLanguage().count > 0)
        {
            defaultLocalizer.setSelectedLanguage(lang: getLanguage())
        }
        else
        {
            defaultLocalizer.setSelectedLanguage(lang: "en")
        }
        
        let schoolId = getSchoolId()
        AppLoadingStatus.appLoadingStatus.status = "Fresh"
        
        if(schoolId.count > 0)
        {
            AppLoadingStatus.appLoadingStatus.status = "Redirect"
            
            let vcLandingPage = self.storyboard!.instantiateViewController(withIdentifier: "vcRoot") as! RootViewController
            
            let appDelegate = UIApplication.shared.delegate as! AppDelegate
            appDelegate.window?.rootViewController = vcLandingPage
        }
        
        let imageViewBackground = UIImageView(frame: CGRect(x: 0, y: 0, width: self.view.frame.size.width, height: self.view.frame.size.height))
        imageViewBackground.image = UIImage(named: "landing_page")
        
        // you can change the content mode:
        imageViewBackground.contentMode = UIView.ContentMode.scaleToFill
        
        self.view.addSubview(imageViewBackground)
        
        phoneNumberTextField = FPNTextField(frame: CGRect(x: 10, y: 55, width: view.bounds.width - 16, height: 50))
        phoneNumberTextField.borderStyle = .roundedRect
        
        // Comment this line to not have access to the country list
        //phoneNumberTextField.parentViewController = self
        
        phoneNumberTextField.delegate = self
        phoneNumberTextField.keyboardType = .numberPad
        
        // Custom the size/edgeInsets of the flag button
        /*phoneNumberTextField.flagSize = CGSize(width: 35, height: 35)
        phoneNumberTextField.flagButtonEdgeInsets = UIEdgeInsets(top: 10, left: 10, bottom: 10, right: 10)*/
        
        phoneNumberTextField.hasPhoneNumberExample = false // true by default
        phoneNumberTextField.placeholder = "Mobile Number"
        
        /*let countryCode = NSLocale.current.regionCode!
        phoneNumberTextField.setFlag(for: FPNCountryCode(rawValue: countryCode)!)*/
        
        phoneNumberTextField.flagButton.isUserInteractionEnabled = false
        
        let toolbar:UIToolbar = UIToolbar(frame: CGRect(x: 0, y: 0,  width: self.view.frame.size.width, height: 30))
        //create left side empty space so that done button set on right side
        let flexSpace = UIBarButtonItem(barButtonSystemItem:    .flexibleSpace, target: nil, action: nil)
        let doneBtn: UIBarButtonItem = UIBarButtonItem(title: self.defaultLocalizer.stringForKey(key: "toolBarButtonTitleDone"), style: .done, target: self, action: #selector(doneButtonAction))
        toolbar.setItems([flexSpace, doneBtn], animated: false)
        toolbar.sizeToFit()
        //setting toolbar as inputAccessoryView
        self.phoneNumberTextField.textFieldInputAccessoryView = toolbar
        
        view.addSubview(phoneNumberTextField)
        
        phoneNumberTextField.center = view.center
        
        let logoImage = UIImageView(frame: CGRect(x: 40, y: view.center.y - 165, width: self.view.frame.size.width - 80, height: 70))
        logoImage.image = UIImage(named: "sz_logo")
        
        // you can change the content mode:
        logoImage.contentMode = UIView.ContentMode.scaleAspectFit
        
        self.view.addSubview(logoImage)
        
        let welcomeLabel = UILabel(frame: CGRect(x: 10, y: view.center.y - 95, width: self.view.frame.size.width - 20, height: 85))
        welcomeLabel.textColor = UIColor.white
        welcomeLabel.font = UIFont(name:"HelveticaNeue-Bold", size: 15.0)
        welcomeLabel.textAlignment = .left
        welcomeLabel.numberOfLines = 5
        welcomeLabel.lineBreakMode = .byWordWrapping
        welcomeLabel.text = self.defaultLocalizer.stringForKey(key: "labelHeaderSendOTP")
        
        self.view.addSubview(welcomeLabel)
        
        self.buttonSubmit = UIButton(frame: CGRect(x: 10, y: view.center.y + 35, width: self.view.frame.size.width - 20, height: 50))
        self.setSubmitButtonAppearence(buttonSubmit: buttonSubmit, buttonText: self.defaultLocalizer.stringForKey(key: "labelButtonSendOTP"))
        buttonSubmit.addTarget(self, action: #selector(submitForm), for:.touchUpInside)
        
        view.addSubview(buttonSubmit)
        self.activityIndicator.sizeToFit()
        self.activityIndicator.center.x = super.view.center.x
        self.activityIndicator.center.y = (super.view.center.y - 50)
        self.view.addSubview(activityIndicator)
        
        Reachability.isInternetAvailable(webSiteToPing: nil) { (isInternetAvailable) in
            guard isInternetAvailable else {
                // Inform user for example
                let alertView = SCLAlertView(appearance: self.appearance)
                alertView.addButton(self.defaultLocalizer.stringForKey(key: "actionSheetTitleOK")) {
                    alertView.dismiss(animated: true, completion: nil)
                }
                alertView.showError("OurSchoolZone", subTitle: "OOps! Internet Connection Appears To Be Offline.", closeButtonTitle: self.defaultLocalizer.stringForKey(key: "actionSheetTitleOK"))
                return
            }
            
            // Do some action if there is Internet
        }
    }
    
    @objc func doneButtonAction() {
        self.view.endEditing(true)
    }
    
    func getCountryCallingCode(countryRegionCode:String)->String{
        
        let prefixCodes = ["AF": "93", "AE": "971", "AL": "355", "AN": "599", "AS":"1", "AD": "376", "AO": "244", "AI": "1", "AG":"1", "AR": "54","AM": "374", "AW": "297", "AU":"61", "AT": "43","AZ": "994", "BS": "1", "BH":"973", "BF": "226","BI": "257", "BD": "880", "BB": "1", "BY": "375", "BE":"32","BZ": "501", "BJ": "229", "BM": "1", "BT":"975", "BA": "387", "BW": "267", "BR": "55", "BG": "359", "BO": "591", "BL": "590", "BN": "673", "CC": "61", "CD":"243","CI": "225", "KH":"855", "CM": "237", "CA": "1", "CV": "238", "KY":"345", "CF":"236", "CH": "41", "CL": "56", "CN":"86","CX": "61", "CO": "57", "KM": "269", "CG":"242", "CK": "682", "CR": "506", "CU":"53", "CY":"537","CZ": "420", "DE": "49", "DK": "45", "DJ":"253", "DM": "1", "DO": "1", "DZ": "213", "EC": "593", "EG":"20", "ER": "291", "EE":"372","ES": "34", "ET": "251", "FM": "691", "FK": "500", "FO": "298", "FJ": "679", "FI":"358", "FR": "33", "GB":"44", "GF": "594", "GA":"241", "GS": "500", "GM":"220", "GE":"995","GH":"233", "GI": "350", "GQ": "240", "GR": "30", "GG": "44", "GL": "299", "GD":"1", "GP": "590", "GU": "1", "GT": "502", "GN":"224","GW": "245", "GY": "595", "HT": "509", "HR": "385", "HN":"504", "HU": "36", "HK": "852", "IR": "98", "IM": "44", "IL": "972", "IO":"246", "IS": "354", "IN": "91", "ID":"62", "IQ":"964", "IE": "353","IT":"39", "JM":"1", "JP": "81", "JO": "962", "JE":"44", "KP": "850", "KR": "82","KZ":"77", "KE": "254", "KI": "686", "KW": "965", "KG":"996","KN":"1", "LC": "1", "LV": "371", "LB": "961", "LK":"94", "LS": "266", "LR":"231", "LI": "423", "LT": "370", "LU": "352", "LA": "856", "LY":"218", "MO": "853", "MK": "389", "MG":"261", "MW": "265", "MY": "60","MV": "960", "ML":"223", "MT": "356", "MH": "692", "MQ": "596", "MR":"222", "MU": "230", "MX": "52","MC": "377", "MN": "976", "ME": "382", "MP": "1", "MS": "1", "MA":"212", "MM": "95", "MF": "590", "MD":"373", "MZ": "258", "NA":"264", "NR":"674", "NP":"977", "NL": "31","NC": "687", "NZ":"64", "NI": "505", "NE": "227", "NG": "234", "NU":"683", "NF": "672", "NO": "47","OM": "968", "PK": "92", "PM": "508", "PW": "680", "PF": "689", "PA": "507", "PG":"675", "PY": "595", "PE": "51", "PH": "63", "PL":"48", "PN": "872","PT": "351", "PR": "1","PS": "970", "QA": "974", "RO":"40", "RE":"262", "RS": "381", "RU": "7", "RW": "250", "SM": "378", "SA":"966", "SN": "221", "SC": "248", "SL":"232","SG": "65", "SK": "421", "SI": "386", "SB":"677", "SH": "290", "SD": "249", "SR": "597","SZ": "268", "SE":"46", "SV": "503", "ST": "239","SO": "252", "SJ": "47", "SY":"963", "TW": "886", "TZ": "255", "TL": "670", "TD": "235", "TJ": "992", "TH": "66", "TG":"228", "TK": "690", "TO": "676", "TT": "1", "TN":"216","TR": "90", "TM": "993", "TC": "1", "TV":"688", "UG": "256", "UA": "380", "US": "1", "UY": "598","UZ": "998", "VA":"379", "VE":"58", "VN": "84", "VG": "1", "VI": "1","VC":"1", "VU":"678", "WS": "685", "WF": "681", "YE": "967", "YT": "262","ZA": "27" , "ZM": "260", "ZW":"263"]
        let countryDialingCode = prefixCodes[countryRegionCode]
        return countryDialingCode!
        
    }
    
    @objc func submitForm(sender: UIButton)
    {
        buttonSubmit.isUserInteractionEnabled = false
        
        let alertView = SCLAlertView(appearance: self.appearance)
        alertView.addButton(self.defaultLocalizer.stringForKey(key: "actionSheetTitleOK")) {
            alertView.dismiss(animated: true, completion: nil)
        }
        self.activityIndicator.startAnimating()
        
        //var mobile = phoneNumberTextField.getFormattedPhoneNumber(format: .E164)!
        var mobile = phoneNumberTextField.text!
        mobile = getCountryCallingCode(countryRegionCode: getCountryCode()) + mobile.replacingOccurrences(of: " ", with: "", options: NSString.CompareOptions.literal, range: nil)
        
        if(!mobile.isPhoneNumber)
        {
            alertView.showError("OurSchoolZone", subTitle: self.defaultLocalizer.stringForKey(key: "allertMessageInvalidMobileNumber"), closeButtonTitle: self.defaultLocalizer.stringForKey(key: "actionSheetTitleOK"))
            
            self.activityIndicator.stopAnimating()
            buttonSubmit.isUserInteractionEnabled = true
            return
        }
        else
        {
            MobileNumberShared.mobileNumberShared.MobileNumber = mobile
            
            if var urlComponents = URLComponents(string: Constants.baseUrl + "sendOTP") {
                urlComponents.query = "mobile_number=" + mobile
                // 3
                guard let url = urlComponents.url else { return }
                
                print("sendOTP URL: \(url)")
                
                getData(from: url) { data, response, error in
                    if error != nil {
                        DispatchQueue.main.async {
                            
                            self.activityIndicator.stopAnimating()
                            alertView.showError("OurSchoolZone", subTitle: self.defaultLocalizer.stringForKey(key: "allertMessageOTPNotSent"), closeButtonTitle: self.defaultLocalizer.stringForKey(key: "actionSheetTitleOK"))
                        }
                    }
                    guard let data = data else { return }
                    //Implement JSON decoding and parsing
                    do {
                        //Decode retrived data with JSONDecoder and assing type of Article object
                        let otpData = try JSONDecoder().decode(Result.self, from: data)
                        
                        //Get back to the main queue
                        DispatchQueue.main.async {
                            
                            self.response = otpData.Response
                            
                            self.activityIndicator.stopAnimating()
                            
                            if(self.response?.ResponseVal == 0)
                            {
                                self.buttonSubmit.isUserInteractionEnabled = true
                                alertView.showError("OurSchoolZone", subTitle: self.defaultLocalizer.stringForKey(key: "allertMessageOTPNotSent"), closeButtonTitle: self.defaultLocalizer.stringForKey(key: "actionSheetTitleOK"))
                            }
                            else{
                                let vc = self.storyboard?.instantiateViewController(withIdentifier: "vcVerifyOTP") as! VerifyOTPViewController
                                vc.modalPresentationStyle = .fullScreen
                                vc.mobileNumber = mobile
                                
                                self.opQueue.addOperation {
                                    // Put queue to the main thread which will update the UI
                                    OperationQueue.main.addOperation({
                                        self.present(vc, animated: false, completion: nil)
                                    })
                                }
                            }
                        }
                        
                    } catch {
                        self.activityIndicator.stopAnimating()
                        DispatchQueue.main.async {
                            self.buttonSubmit.isUserInteractionEnabled = true
                            alertView.showError("OurSchoolZone", subTitle: self.defaultLocalizer.stringForKey(key: "allertMessageMobileNumberNotRegistered"), closeButtonTitle: self.defaultLocalizer.stringForKey(key: "actionSheetTitleOK"))
                        }
                    }
                }
            }
        }
    }
    
    func calculateTopDistance () -> CGFloat{
        let barHeight = self.navigationController?.navigationBar.frame.height ?? 0
        var statusBarHeight:CGFloat = 0
        
        if #available(iOS 13.0, *) {
            
            let sharedApplication = UIApplication.shared
            statusBarHeight = (sharedApplication.delegate?.window??.windowScene?.statusBarManager?.statusBarFrame)!.height

        } else {
            
            statusBarHeight = UIApplication.shared.isStatusBarHidden ? CGFloat(0) : UIApplication.shared.statusBarFrame.height
            
            if let statusBar = UIApplication.shared.value(forKey: "statusBar") as? UIView {
                statusBar.backgroundColor = colorWithHexString(hex: "#00CCFF")
            }
        }
        
        return barHeight + statusBarHeight
    }
    
    func setSubmitButtonAppearence(buttonSubmit: UIButton, buttonText: String){
        
        buttonSubmit.tintColor = UIColor.white
        buttonSubmit.backgroundColor = colorWithHexString(hex: "#00CCFF")
        buttonSubmit.layer.masksToBounds = false
        buttonSubmit.layer.borderColor = colorWithHexString(hex: "#DDDDDD").cgColor
        buttonSubmit.layer.shadowColor = UIColor(red: 0, green: 0, blue: 0, alpha: 0.25).cgColor
        buttonSubmit.layer.shadowOffset = CGSize(width: 1.0, height: 5.0)
        buttonSubmit.layer.shadowOpacity = 1.0
        buttonSubmit.layer.shadowRadius = 5.0
        buttonSubmit.layer.masksToBounds = false
        buttonSubmit.layer.cornerRadius = 3.0
        buttonSubmit.isMultipleTouchEnabled = false
        
        let buttonLabel = UILabel(frame: CGRect(x: 0, y: 0, width: buttonSubmit.frame.width, height: 50))
        buttonLabel.textColor = UIColor.white
        buttonLabel.font = UIFont(name:"HelveticaNeue-Bold", size: 16.0)
        buttonLabel.textAlignment = .center
        buttonLabel.text = buttonText
        
        buttonSubmit.addSubview(buttonLabel)
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
}

